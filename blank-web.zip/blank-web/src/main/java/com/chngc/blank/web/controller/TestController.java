package com.chngc.blank.web.controller;

import com.chngc.blank.service.ITestBlankService;
import com.chngc.core.common.ServiceResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

/**
 * @FileName: TestController
 * @Version: 1.0
 * @Author: yanpeng
 * @Date: 2016/6/24 10:15
 */

@Controller
public class TestController {

    @Autowired
    private ITestBlankService testBlankService;


    @RequestMapping(value = "/blank.html", method = RequestMethod.GET)
    public String afterSaleOfOrderDetail(HttpServletRequest request, HttpServletResponse response,
                                         Map<String, Object> modelMap) {

        ServiceResult<List<String>> sr =  testBlankService.getTestData("WEB TEST");

        List<String> ll = sr.getResult();

        modelMap.put("S1", ll.get(0));
        modelMap.put("S2", ll.get(1));

        return "blank";
    }


}
