package com.wechat.exception;


/**
 * 网络访问异常
 * @author jiahuijie
 *
 */
public class WxNetException extends Exception {

	private static final long serialVersionUID = 7312060988977054762L;
	
	public WxNetException(String message) {
		super(message);
	}
	
	public WxNetException(String message, Throwable cause) {
		super(message, cause);
	}
}
