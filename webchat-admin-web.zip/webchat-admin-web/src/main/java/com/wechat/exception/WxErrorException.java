package com.wechat.exception;

import com.wechat.config.WeChatMsgConfig;

/**
 * 微信接口异常
 * @author jiahuijie
 *
 */
public class WxErrorException extends Exception {

	private static final long serialVersionUID = 7312060988977054762L;
	
	/**
	 * 错误码
	 */
	private String errcode;
	
	/**
	 * 错误消息
	 */
	private String errmsg;
	
	/**
	 * 消息详细描述
	 */
	private String errdesc;
	
	public WxErrorException(String errcode, String errmsg) {
		this.errcode = errcode;
		this.errmsg = errmsg;
		this.errdesc = WeChatMsgConfig.getStringValue(errcode);
	}
	

	public String getErrcode() {
		return errcode;
	}

	public void setErrcode(String errcode) {
		this.errcode = errcode;
		this.errdesc = WeChatMsgConfig.getStringValue(errcode);
	}

	public String getErrmsg() {
		return errmsg;
	}

	public void setErrmsg(String errmsg) {
		this.errmsg = errmsg;
	}

	public String getErrdesc() {
		return errdesc;
	}

	public void setErrdesc(String errdesc) {
		this.errdesc = errdesc;
	}
	
}
