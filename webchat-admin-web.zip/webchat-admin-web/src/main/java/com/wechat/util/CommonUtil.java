package com.wechat.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.xml.XMLSerializer;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.thoughtworks.xstream.XStream;
public class CommonUtil {
	
	private static ObjectMapper objectMapper = new ObjectMapper();    
	
	private static String Encrypt(String strSrc,String encName) {
		MessageDigest md = null;
		String strDes = null;
		
		byte[] bt = strSrc.getBytes();
		try {
                if (encName == null || encName.equals("")) {
                    encName="MD5";
                }
				md = MessageDigest.getInstance(encName);
				md.update(bt);
		        strDes = bytes2Hex(md.digest());  //to HexString
		} catch (NoSuchAlgorithmException e) {
			return null;
		}
		return strDes;
	}
	
	
	private static String bytes2Hex(byte[]bts) {
		String hs="";
	     String stmp="";
	     for (int n=0; n < bts.length; n++){
	         stmp=(java.lang.Integer.toHexString(bts[n] & 0xFF));
	         if (stmp.length()==1) hs=hs+"0"+stmp;
	             else hs=hs+stmp;
	     }
	     return hs;
	}
	
	
	/**
	 * MD5加密
	 * @param str
	 * @return
	 */
	public static String MD5(String str){
		return Encrypt(str, "MD5");
	}
	
	/**
	 * SHA1加密
	 * @param str
	 * @return
	 */
	public static String SHA1(String str){
		return Encrypt(str, "SHA-1");
	}
	
	/**
	 * SHA256加密
	 * @param str
	 * @return
	 */
	public static String SHA256(String str){
		return Encrypt(str, "SHA-256");
	}
	


	/**
	 * BASE64 编码  
	 * @param s
	 * @return
	 */
	@SuppressWarnings("restriction")
	public static String BASE64Encode(String str) {
		if (str == null) 
			return null;
		return (new sun.misc.BASE64Encoder()).encode(str.getBytes());
	}  

  
	/**
	 * BASE64解码  
	 * @param s
	 * @return
	 */
	@SuppressWarnings("restriction")
	public static String BASE64Decode(String str) {
		if (str == null) 
			return null;
		sun.misc.BASE64Decoder decoder = new sun.misc.BASE64Decoder(); 
		try {
			byte[] b = decoder.decodeBuffer(str);
			return new String(b);  
		} catch (IOException e) {
			return null;
		}
	} 
	
	/**
	 * jsong字符串
	 * @param obj
	 * @return
	 */
	public static String ObjectToJSON(Object obj){
		try {
			return objectMapper.writeValueAsString(obj);
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 字符串转对象
	 * @param json
	 * @return
	 */
	public static JsonNode JSONToObject(String json){
		try {
			return objectMapper.readTree(json);
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 对象转map
	 * @param json
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static HashMap<String, Object> ObjectToMap(Object obj){
		try {
			return objectMapper.convertValue(obj, HashMap.class);
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 字符串转对象
	 * @param json
	 * @return
	 */
	public static JSONObject JSONToJSONObject(String json){
		try {
			return JSONObject.fromObject(json);
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 字符串转对象
	 * @param json
	 * @return
	 */
	public static JSONArray JSONToJSONArray(String json){
		try {
			return JSONArray.fromObject(json);
		} catch (Exception e) {
			return null;
		}
	}
	
	
	
	/**
	 * Map转换为xml
	 * @param map 转换对象
	 * @return
	 */
	public static String mapToXML(Map<String, Object> map){
		XMLSerializer xmlSerializer = new XMLSerializer();
		xmlSerializer.setRootName("root");
		xmlSerializer.setTypeHintsEnabled(false);
		return xmlSerializer.write(JSONObject.fromObject(map)).replaceAll("\r\n", "");
	}
	
	/**
	 * Obj转换为xml
	 * @param obj 转换对象
	 * @return
	 */
	public static String WxObjToXML(Object obj){
		XStream xStream = new XStream();  
		xStream.autodetectAnnotations(true);
		String xml = xStream.toXML(obj);
		return xml;
	}
	
	/**
	 * Obj转换为xml
	 * @param obj 转换对象
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Map<String,Object> WxObjToMap(Object obj){
		JSONObject job = JSONObject.fromObject(obj);
		Map<String,Object> map = new HashMap<String,Object>();  
		Iterator<String> keys = job.keys();  
		while(keys.hasNext()){
			String key = (String) keys.next();  
			String value = job.get(key).toString();  
			if(value.startsWith("{")&&value.endsWith("}")){
				map.put(key, WxObjToMap(value));  
			}else{  
				map.put(key, value);  
			}  
		}  
		return map;  
	}
	
	/**
	 * Obj转换为xml
	 * @param obj 转换对象
	 * @return
	 */
	public static String ObjToXML(Object obj){
		XMLSerializer xmlSerializer = new XMLSerializer();
		xmlSerializer.setRootName("xml");
		xmlSerializer.setTypeHintsEnabled(false);
		System.out.println(JSONObject.fromObject(obj).toString());
		return xmlSerializer.write(JSONObject.fromObject(obj)).replaceAll("\r\n", "");
	}
	
	
	/**
	 * xml转换为Map
	 * @param xml 转换对象
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Map<String,Object> xmlToMap(String xml){
		Map<String, Class> classMap = new HashMap<String, Class>();
		classMap.put("b", Map.class);
		XMLSerializer xmlSerializer = new XMLSerializer();
		xmlSerializer.setRootName("root");
		xmlSerializer.setTypeHintsEnabled(false);
		return (Map<String,Object>)JSONObject.toBean((JSONObject) xmlSerializer.read(xml), Map.class , classMap);
	}
	
	/**
	 * xml转换为Map
	 * @param xml 转换对象
	 * @param complexDomNames 复合节点名称
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Map<String,Object> xmlToMap(String xml, String[] complexDomNames){
		Map<String,Class> classMap = new HashMap<String,Class>();
		for (String complexDomName : complexDomNames){
			classMap.put(complexDomName, Map.class);
		}
		XMLSerializer xmlSerializer = new XMLSerializer();
		xmlSerializer.setRootName("root");
		xmlSerializer.setTypeHintsEnabled(false);
		return (Map<String,Object>)JSONObject.toBean((JSONObject) xmlSerializer.read(xml), Map.class , classMap);
	}
	
	
	/**
	 * input 转 string
	 * @return
	 */
	public static String convertStreamToString(InputStream is){
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));   
        StringBuilder sb = new StringBuilder();   

        String line = null;   
        try {   
            while ((line = reader.readLine()) != null) {   
                sb.append(line);
            }   
        } catch (IOException e) {   
            return null;
        } finally {   
            try {   
                is.close();   
            } catch (IOException e) {   
                return null; 
            }   
        }   
        return sb.toString();   
	}
	
	/**
	 * xml转换为Map
	 * @param xmlStream 转换对象
	 * @return
	 */
	public static JSONObject xmlToJSON(InputStream xmlStream){
		XMLSerializer xmlSerializer = new XMLSerializer();
		xmlSerializer.setRootName("root");
		xmlSerializer.setTypeHintsEnabled(false);
		return (JSONObject) xmlSerializer.readFromStream(xmlStream);
	}
	
	
	/**
	 * xml转换为Map
	 * @param xml 转换对象
	 * @param xml 复合节点名称
	 * @return
	 */
	public static JSONObject xmlToJSON(String xml){
		XMLSerializer xmlSerializer = new XMLSerializer();
		xmlSerializer.setRootName("root");
		xmlSerializer.setTypeHintsEnabled(false);
		return (JSONObject) xmlSerializer.read(xml);
	}
	
	
	
	
	/***
	 * 将时间按照指定格式字符串转换
	 * @param time 日期
	 * @param formatStr 格式化字符串
	 * @return 结果
	 */
	public static String DateFormat(String formatStr,Long time){
		return new SimpleDateFormat(formatStr).format(time);
	}
	
	/***
	 * 将时间按照指定格式字符串转换
	 * @param time 日期
	 * @param formatStr 格式化字符串
	 * @return 结果
	 * @throws ParseException 
	 */
	public static Date DateFormat(String formatStr, String dateStr) throws ParseException{
		return new SimpleDateFormat(formatStr).parse(dateStr);
	}
	
	
//	/** 
//     * 将emoji表情替换成* 
//     *  
//     * @param source 
//     * @return 过滤后的字符串 
//     */  
//    public static String filterEmoji(String source) {  
//        if(StringUtils.isNotBlank(source)){  
//            return source.replaceAll("[\\ud800\\udc00-\\udbff\\udfff\\ud800-\\udfff]", "*");  
//        }else{  
//            return source;  
//        }  
//    }  
    
    
    
    	/**
	     * 检测是否有emoji字符
	     * @param source
	     * @return 一旦含有就抛出
	     */
	    public static boolean containsEmoji(String source) {
	        if (StringUtils.isBlank(source)) {
	            return false;
	        }
	 
	        int len = source.length();
	 
	        for (int i = 0; i < len; i++) {
	            char codePoint = source.charAt(i);
	 
	            if (isEmojiCharacter(codePoint)) {
	                //do nothing，判断到了这里表明，确认有表情字符
	                return true;
	            }
	        }
	 
	        return false;
	    }
	 
	    private static boolean isEmojiCharacter(char codePoint) {
	        return (codePoint == 0x0) ||
	                (codePoint == 0x9) ||
	                (codePoint == 0xA) ||
	                (codePoint == 0xD) ||
	                ((codePoint >= 0x20) && (codePoint <= 0xD7FF)) ||
	                ((codePoint >= 0xE000) && (codePoint <= 0xFFFD)) ||
	                ((codePoint >= 0x10000) && (codePoint <= 0x10FFFF));
	    }
	 
	    /**
	     * 过滤emoji 或者 其他非文字类型的字符
	     * @param source
	     * @return
	     */
	    public static String filterEmoji(String source) {
	 
	        if (!containsEmoji(source)) {
	            return source;//如果不包含，直接返回
	        }
	        //到这里铁定包含
	        StringBuilder buf = null;
	 
	        int len = source.length();
	 
	        for (int i = 0; i < len; i++) {
            char codePoint = source.charAt(i);
	 
	            if (isEmojiCharacter(codePoint)) {
                if (buf == null) {
	                    buf = new StringBuilder(source.length());
                }
	 
	                buf.append(codePoint);
            } else {
	            }
	        }
	 
	        if (buf == null) {
	            return source;//如果没有找到 emoji表情，则返回源字符串
	        } else {
	        	if (buf.length() == len) {//这里的意义在于尽可能少的toString，因为会重新生成字符串
	                buf = null;
	                return source;
	            } else {
	                return buf.toString();
	            }
	        }
	 
	    }
}
