package com.wechat.config;

public class WeChatMsgConstants {
	
	/**
	 * 验证码
	 */
	public static final String VALIDATE_CODE = "validate_code";
	
	/**
	 * 图片服务器key
	 */
	public static final String KEY_IMG_SERVER = "img_server";
	
	/**
	 * 服务器域
	 */
	public static final String KEY_SERVER_DOMAIN = "server_domain";
	
	
	/**
	 * 文件基路径
	 */
	public static final String KEY_FILE_UPLOAD_BASE_DIR = "file_upload_base_dir";
	
	/**
	 * 图片缓存目录
	 */
	public static final String KEY_IMG_CACHE_BASE_DIR = "img_cache_base_dir";
	
	/**
	 * 文件临时路径
	 */
	public static final String KEY_TEMP_DIR = "temp_dir";
	
	/**
	 * 内容传路径
	 */
	public static final String CMS_DIR = "cms_dir";
	
	/**
	 * 权限资源路径
	 */
	public static final String ACTION_DIR = "action_dir";
}
