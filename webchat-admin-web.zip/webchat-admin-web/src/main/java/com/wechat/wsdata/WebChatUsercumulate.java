package com.wechat.wsdata;

import java.util.List;

/**
 * 获取用户增减数据
 */
public class WebChatUsercumulate {
	
	// 用户特权信息
	private List<WebChatUsercumulateItem> list;

	public WebChatUsercumulate() {
	}

	public List<WebChatUsercumulateItem> getList() {
		return list;
	}

	public void setList(List<WebChatUsercumulateItem> list) {
		this.list = list;
	}
	
	
	
	
	
	/**
	 * 获取用户增减数据项
	 */
	public class WebChatUsercumulateItem{
		
		// 日期
		private String ref_date;
		
		// 用户总量
		private int cumulate_user;
		
		
		public WebChatUsercumulateItem() {
		}

		public String getRef_date() {
			return ref_date;
		}

		public void setRef_date(String ref_date) {
			this.ref_date = ref_date;
		}

		public int getCumulate_user() {
			return cumulate_user;
		}
		
		public void setCumulate_user(int cumulate_user) {
			this.cumulate_user = cumulate_user;
		}
	}
}


