package com.wechat.wsdata;

import java.util.List;

/**
 * 获取用户增减数据
 */
public class WebChatUsersummary {
	
	// 用户特权信息
	private List<WebChatUsersummaryItem> list;

	public WebChatUsersummary() {
	}

	public List<WebChatUsersummaryItem> getList() {
		return list;
	}

	public void setList(List<WebChatUsersummaryItem> list) {
		this.list = list;
	}
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * 获取用户增减数据项
	 */
	public class WebChatUsersummaryItem{
		
		// 日期
		private String ref_date;
		
		// 用户来源
		private int user_source;
		
		// 新增用户数
		private int new_user;
		
		// 取消用户数
		private int cancel_user;
		
		public WebChatUsersummaryItem() {
		}

		public String getRef_date() {
			return ref_date;
		}

		public void setRef_date(String ref_date) {
			this.ref_date = ref_date;
		}

		public int getUser_source() {
			return user_source;
		}

		public void setUser_source(int user_source) {
			this.user_source = user_source;
		}

		public int getNew_user() {
			return new_user;
		}

		public void setNew_user(int new_user) {
			this.new_user = new_user;
		}

		public int getCancel_user() {
			return cancel_user;
		}

		public void setCancel_user(int cancel_user) {
			this.cancel_user = cancel_user;
		}
	}
}


