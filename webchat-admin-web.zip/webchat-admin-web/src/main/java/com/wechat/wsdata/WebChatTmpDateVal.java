package com.wechat.wsdata;


/**
 * 获取用户增减数据
 */
public class WebChatTmpDateVal {
	
	// 属性值
	private String value;
	
	//字体颜色
	private String color;

	public WebChatTmpDateVal() {
	}
	
	public WebChatTmpDateVal(String value) {
		this.value = value;
		this.color = "#000000";
	}

	
	public WebChatTmpDateVal(String value, String color) {
		this.value = value;
		this.color = color;
	}


	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

}


