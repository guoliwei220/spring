package com.wechat.wsdata;


/**
 * 创建二维码响应对象
 * @author Administrator
 *
 */
public class WebChatTicket {

	/**
	 * ticket
	 */
	private String ticket;
	
	/**
	 * 过期时间 秒数
	 */
	private int expire_seconds;
	
	/**
	 * 图片地址
	 */
	private String url;
	
	public WebChatTicket() {
		// TODO Auto-generated constructor stub
	}

	public String getTicket() {
		return ticket;
	}

	public void setTicket(String ticket) {
		this.ticket = ticket;
	}

	public int getExpire_seconds() {
		return expire_seconds;
	}

	public void setExpire_seconds(int expire_seconds) {
		this.expire_seconds = expire_seconds;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	
}
