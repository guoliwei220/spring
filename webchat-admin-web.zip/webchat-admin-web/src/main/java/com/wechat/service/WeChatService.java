package com.wechat.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.wechat.exception.WxErrorException;
import com.wechat.exception.WxNetException;
import com.wechat.util.CommonUtil;
import com.wechat.util.HttpClientManager;
import com.wechat.wsdata.WebChatJsTicket;
import com.wechat.wsdata.WebChatOauth2Token;
import com.wechat.wsdata.WebChatTicket;
import com.wechat.wsdata.WebChatTmpDateVal;
import com.wechat.wsdata.WebChatToken;
import com.wechat.wsdata.WebChatUserInfo;
import com.wechat.wsdata.WebChatUsercumulate;
import com.wechat.wsdata.WebChatUsersummary;


/**
 * 微信工具类
 * @author Jiahuijie
 *601933
 */
public class WeChatService {
	
	/**
	 * 鉴权
	 * @return
	 */
	public static boolean checkSignature(String _token, String _signature, String _timestamp, String _nonce){
		
		//1. 将token、timestamp、nonce三个参数进行字典序排序
		List<String> list = new ArrayList<String>();
		list.add(_token);
		list.add(_timestamp);
		list.add(_nonce);
		
		Collections.sort(list);
		
		//2. 将三个参数字符串拼接成一个字符串进行sha1加密
		StringBuffer signatureBuffer = new StringBuffer();
		for (String str : list){
			signatureBuffer.append(str);
		}
		
		//3. 签名加密
		String signature = CommonUtil.SHA1(signatureBuffer.toString());
		
		//3. 开发者获得加密后的字符串可与signature对比，标识该请求来源于微信
		if (signature != null && signature.equalsIgnoreCase(_signature))
			return true;
		return false;
	}
	
	/**
	 * 创建acctoken
	 * @return
	 * @throws WxErrorException 
	 * @throws IOException 
	 * @throws WxNetException 
	 */
	public static WebChatToken createAccToken(String appId, String appSecret) throws WxErrorException, WxNetException{
		
		String url = "https://api.weixin.qq.com/cgi-bin/token";
			
		Map<String,String> params = new HashMap<String,String>();
		params.put("grant_type", "client_credential");
		params.put("appid", appId);
		params.put("secret", appSecret);
		
		
		String jsonStr = HttpClientManager.get(url, params);
		
		JSONObject job = JSONObject.fromObject(jsonStr);
		
		if(job.has("errcode") && job.getInt("errcode") != 0)
			throw new WxErrorException(job.getString("errcode"),job.getString("errmsg"));
		
		WebChatToken token = new WebChatToken();
		token.setAccessToken(job.getString("access_token"));
		token.setExpiresIn(job.getInt("expires_in"));
		
		return token;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//数据统计接口部分
	
	/**
	 * 获取用户增减数据
	 * @return
	 * @throws WxNetException 
	 * @throws WxErrorException 
	 */
	public static WebChatUsersummary getUsersummary(String accToken, Date beginDate, Date endDate) throws WxErrorException, WxNetException {
		String acten = accToken;
		
		String url = "https://api.weixin.qq.com/datacube/getusersummary?access_token=" + acten;
		
		JSONObject json = new JSONObject();
		json.put("begin_date", CommonUtil.DateFormat("yyyy-MM-dd", beginDate.getTime()));
		json.put("end_date", CommonUtil.DateFormat("yyyy-MM-dd", endDate.getTime()));
		
		String jsonStr = HttpClientManager.postJSON(url, json);
		
		JSONObject job = JSONObject.fromObject(jsonStr);
		
		if(job.has("errcode") && job.getInt("errcode") != 0)
			throw new WxErrorException(job.getString("errcode"),job.getString("errmsg"));
		
		WebChatUsersummary wcu = (WebChatUsersummary)JSONObject.toBean(job, WebChatUsersummary.class);
		return wcu;
	}
	
	
	
	/**
	 * 获取用户总量
	 * @return
	 * @throws WxNetException 
	 * @throws WxErrorException 
	 */
	public static WebChatUsercumulate getUsercumulate(String accToken, Date beginDate, Date endDate) throws WxErrorException, WxNetException {
		String acten = accToken;
		
		String url = "https://api.weixin.qq.com/datacube/getusercumulate?access_token=" + acten;
		
		JSONObject json = new JSONObject();
		json.put("begin_date", CommonUtil.DateFormat("yyyy-MM-dd", beginDate.getTime()));
		json.put("end_date", CommonUtil.DateFormat("yyyy-MM-dd", endDate.getTime()));
		
		String jsonStr = HttpClientManager.postJSON(url, json);
		
		JSONObject job = JSONObject.fromObject(jsonStr);
		
		if(job.has("errcode") && job.getInt("errcode") != 0)
			throw new WxErrorException(job.getString("errcode"),job.getString("errmsg"));
		
		WebChatUsercumulate wcu = (WebChatUsercumulate)JSONObject.toBean(job, WebChatUsercumulate.class);
		return wcu;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//网页授权接口部分
	
	/**
	 * 通过code获取acctoken
	 * @param code
	 * @return
	 * @throws WxErrorException 
	 * @throws WxNetException 
	 */
	public static WebChatOauth2Token getAcctokenByCode(String code, String appId, String appSecret) throws WxErrorException, WxNetException{
		
		String url = "https://api.weixin.qq.com/sns/oauth2/access_token";
		Map<String,String> params = new HashMap<String,String>();
		params.put("code", code);
		params.put("appid", appId);
		params.put("secret", appSecret);
		params.put("grant_type", "authorization_code");
		
		String jsonStr = HttpClientManager.get(url, params);
		
		JSONObject job = JSONObject.fromObject(jsonStr);
		
		if(job.has("errcode") && job.getInt("errcode") != 0)
			throw new WxErrorException(job.getString("errcode"), job.getString("errmsg"));
		
		WebChatOauth2Token wcot = new WebChatOauth2Token();
		wcot.setAccessToken(job.getString("access_token"));
		wcot.setOpenId(job.getString("openid"));
		wcot.setExpiresIn(job.getInt("expires_in"));
		wcot.setRefreshToken(job.getString("refresh_token"));
		wcot.setScope(job.getString("scope"));
		
		return wcot;
	}
	
	
	/**
	 * 通过页面获取用户信息
	 * @param pageAccToken
	 * @param openId
	 * @return
	 * @throws WxErrorException 
	 * @throws WxNetException 
	 */
	@SuppressWarnings({ "unchecked", "deprecation" })
	public static WebChatUserInfo getUserInfoByPage(String pageAccToken, String openId) throws WxErrorException, WxNetException {
		
		String url = "https://api.weixin.qq.com/sns/userinfo";
		
		Map<String,String> params = new HashMap<String,String>();
		params.put("access_token", pageAccToken);
		params.put("openid", openId);
		params.put("lang", "zh_CN");
		
		String jsonStr = HttpClientManager.get(url, params);
		
		JSONObject job = JSONObject.fromObject(jsonStr);
		
		if(job.has("errcode") && job.getInt("errcode") != 0)
			throw new WxErrorException(job.getString("errcode"),job.getString("errmsg"));
		
		WebChatUserInfo wcui = new WebChatUserInfo();
		wcui.setCity(job.getString("city"));
		wcui.setCountry(job.getString("country"));
		wcui.setHeadImgUrl(job.getString("headimgurl"));
		wcui.setNickname(job.getString("nickname"));
		wcui.setOpenId(job.getString("openid"));
		wcui.setPrivilegeList(JSONArray.toList(job.getJSONArray("privilege"), List.class));
		wcui.setProvince(job.getString("province"));
		wcui.setSex(job.getInt("sex"));//用户的性别，值为1时是男性，值为2时是女性，值为0时是未知 
		
		return wcui;
	}
	
	/**
	 * 获取用户信息
	 * @param openId
	 * @return
	 * @throws WxNetException 
	 * @throws WxErrorException 
	 */
	public static WebChatUserInfo getUserInfo(String accToken,String openId) throws WxNetException, WxErrorException {
		
		String url = "https://api.weixin.qq.com/cgi-bin/user/info";
		
		String at = accToken;
		
		Map<String,String> params = new HashMap<String,String>();
		params.put("access_token", at);
		params.put("openid", openId);
		params.put("lang", "zh_CN");
		
		String jsonStr = HttpClientManager.get(url, params);
		
		JSONObject job = JSONObject.fromObject(jsonStr);
		
		if(job.has("errcode") && job.getInt("errcode") != 0)
			throw new WxErrorException(job.getString("errcode"),job.getString("errmsg"));
			
		WebChatUserInfo wcui = new WebChatUserInfo();
		wcui.setCity(job.getString("city"));
		wcui.setCountry(job.getString("country"));
		wcui.setHeadImgUrl(job.getString("headimgurl"));
		wcui.setNickname(job.getString("nickname"));
		wcui.setOpenId(job.getString("openid"));
		wcui.setProvince(job.getString("province"));
		wcui.setSex(job.getInt("sex"));//用户的性别，值为1时是男性，值为2时是女性，值为0时是未知 
		
		return wcui;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//二维码部分
	
	
	/**
	 * 创建二维码ticket
	 * @return
	 * @throws WxNetException 
	 * @throws WxErrorException 
	 */
	public static WebChatTicket createTicket(String accToken, int scenekey) throws WxErrorException, WxNetException {
		String acten = accToken;
		String url = "https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=" + acten;
		
		JSONObject json = new JSONObject();
		json.put("expire_seconds", 1800);
		json.put("action_name", "QR_SCENE");
		
		JSONObject action_info = new JSONObject();
		JSONObject scene = new JSONObject();
		scene.put("scene_id", scenekey);
		action_info.put("scene", scene);
		json.put("action_info", action_info);
		
		String jsonStr = HttpClientManager.postJSON(url, json);
		
		JSONObject job = JSONObject.fromObject(jsonStr);
		
		if(job.has("errcode") && job.getInt("errcode") != 0)
			throw new WxErrorException(job.getString("errcode"),job.getString("errmsg"));
		
		WebChatTicket wct = new WebChatTicket();
		wct.setTicket(job.getString("ticket"));
		wct.setExpire_seconds(job.getInt("expire_seconds"));
		wct.setUrl(job.getString("url"));
		
		return wct;
	}
	
	
	/**
	 * 创建永久二维码ticket
	 * @return
	 * @throws WxNetException 
	 * @throws WxErrorException 
	 */
	public static WebChatTicket createLongTicket(String accToken, int scenekey) throws WxErrorException, WxNetException {
		String acten = accToken;
		
		String url = "https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=" + acten;
		
		JSONObject json = new JSONObject();
		json.put("action_name", "QR_LIMIT_SCENE");
		
		JSONObject action_info = new JSONObject();
		JSONObject scene = new JSONObject();
		scene.put("scene_id", scenekey);
		action_info.put("scene", scene);
		json.put("action_info", action_info);
		
		String jsonStr = HttpClientManager.postJSON(url, json);
		
		JSONObject job = JSONObject.fromObject(jsonStr);
		
		if(job.has("errcode") && job.getInt("errcode") != 0)
			throw new WxErrorException(job.getString("errcode"),job.getString("errmsg"));
		
		WebChatTicket wct = new WebChatTicket();
		wct.setTicket(job.getString("ticket"));
		wct.setUrl(job.getString("url"));
		
		return wct;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//菜单管理部分
	
	
	/**
	 * 创建菜单
	 * @return
	 * @throws WxErrorException 
	 * @throws WxNetException 
	 */
	public static JSONObject createMenu(String accToken, JSONObject menuJson) throws WxErrorException, WxNetException {
		String acten = accToken;
		
		String url = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=" + acten;
		
		String jsonStr = HttpClientManager.postJSON(url, menuJson);
		
		JSONObject job = JSONObject.fromObject(jsonStr);
		
		if(job.has("errcode") && job.getInt("errcode") != 0)
			throw new WxErrorException(job.getString("errcode"),job.getString("errmsg"));
			
		return job;
	}
	
	/**
	 * 获取菜单
	 * @return
	 * @throws WxNetException 
	 * @throws WxErrorException 
	 */
	public static JSONObject getMenu(String accToken) throws WxNetException, WxErrorException {
		
		String acten = accToken;
		
		String url = "https://api.weixin.qq.com/cgi-bin/menu/get";
		
		Map<String,String> params = new HashMap<String,String>();
		params.put("access_token", acten);
		
		String jsonStr = HttpClientManager.get(url, params);
		
		JSONObject job = JSONObject.fromObject(jsonStr);
		
		if(job.has("errcode") && job.getInt("errcode") != 0)
			throw new WxErrorException(job.getString("errcode"),job.getString("errmsg"));
			
		return job;
	}
	
	/**
	 * 删除菜单
	 * @return
	 * @throws WxNetException 
	 * @throws WxErrorException 
	 */
	public static JSONObject deleteMenu(String accToken) throws WxErrorException, WxNetException {
		String acten = accToken;
		
		String url = "https://api.weixin.qq.com/cgi-bin/menu/delete";
		Map<String,String> params = new HashMap<String,String>();
		params.put("access_token", acten);
		
		String jsonStr = HttpClientManager.get(url,params);
		
		JSONObject job = JSONObject.fromObject(jsonStr);
		
		if(job.has("errcode") && job.getInt("errcode") != 0)
			throw new WxErrorException(job.getString("errcode"),job.getString("errmsg"));
			
		return job;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//客服管理部分
	
	
	/**
	 *  客服发送消息接口
	 * @return
	 * @throws WxNetException 
	 * @throws WxErrorException 
	 */
	public static JSONObject sendMsg(String accToken, JSONObject msgJson) throws WxErrorException, WxNetException {
		String acten = accToken;
		
		String url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=" + acten;
		
		String jsonStr = HttpClientManager.postJSON(url, msgJson);
		
		JSONObject job = JSONObject.fromObject(jsonStr);
		
		if(job.has("errcode") && job.getInt("errcode") != 0)
			throw new WxErrorException(job.getString("errcode"),job.getString("errmsg"));
			
		return job;
	}
	
	
	
	
	
	
	
	
	//多媒体操作
	
	
	
	
	
	/**
	 * 多媒体下载
	 * @param accToken
	 * @param filepath
	 * @throws WxErrorException
	 * @throws WxNetException
	 */
	public static String downloadMedia(String accToken, String mediaId, String filepath, String filename) throws WxNetException {
		String url = "http://file.api.weixin.qq.com/cgi-bin/media/get";
		Map<String,String> params = new HashMap<String,String>();
		params.put("access_token", accToken);
		params.put("media_id", mediaId);
		return HttpClientManager.download(url, params, filepath, filename);
	}
	
	
	
	
	
	
	
	//js部分
	
	
	/**
	 *  获取js ticket接口
	 * @return
	 * @throws WxNetException 
	 * @throws WxErrorException 
	 */
	public static WebChatJsTicket getJsTicket(String accToken) throws WxErrorException, WxNetException {
		String url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket";
		Map<String,String> params = new HashMap<String,String>();
		params.put("access_token", accToken);
		params.put("type", "jsapi");
		
		String jsonStr = HttpClientManager.get(url, params);
		
		JSONObject job = JSONObject.fromObject(jsonStr);
		
		if(job.has("errcode") && job.getInt("errcode") != 0)
			throw new WxErrorException(job.getString("errcode"),job.getString("errmsg"));
		
		WebChatJsTicket wcu = (WebChatJsTicket)JSONObject.toBean(job, WebChatJsTicket.class);
		
		return wcu;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	//模板消息
	
	
	/**
	 *  发送模板消息接口
	 * @return
	 * @throws WxNetException 
	 * @throws WxErrorException 
	 */
	public static void sendTempMsg(String accToken, String touser, String template_id, String link, String topcolor, Map<String, WebChatTmpDateVal> tempData) throws WxErrorException, WxNetException {
		String url = "https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=" + accToken;
		
		JSONObject obj = new JSONObject();
		obj.put("touser", touser);
		obj.put("template_id", template_id);
		obj.put("link", link);
		obj.put("topcolor", topcolor);
		obj.put("data", tempData);
		
		String jsonStr = HttpClientManager.postJSON(url, obj);
		
		JSONObject job = JSONObject.fromObject(jsonStr);
		if(job.has("errcode") && job.getInt("errcode") != 0)
			throw new WxErrorException(job.getString("errcode"),job.getString("errmsg"));
	}
}
