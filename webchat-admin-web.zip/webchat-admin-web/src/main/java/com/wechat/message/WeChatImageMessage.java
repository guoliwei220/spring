package com.wechat.message;

/**
 * 图片消息
 * @author jiahuijie
 *
 */
public class WeChatImageMessage extends WeChatMessage{

	private static final long serialVersionUID = -7530976688438288893L;

	/**
	 * 图片Url
	 */
	private String PicUrl;
	
	/**
	 * 多媒体资源id
	 */
	private String MediaId;
	
	public WeChatImageMessage() {
		super();
		setMsgType(MSG_TYPE_IMAGE);
	}

	public String getPicUrl() {
		return PicUrl;
	}

	public void setPicUrl(String picUrl) {
		PicUrl = picUrl;
	}

	public String getMediaId() {
		return MediaId;
	}

	public void setMediaId(String mediaId) {
		MediaId = mediaId;
	}

	
	
	
}
