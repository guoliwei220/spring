package com.wechat.message;

/**
 * 微信事件消息基类
 * @author jiahuijie
 *
 */
public class WeChatEventMessage extends WeChatMessage implements java.io.Serializable{

	private static final long serialVersionUID = 7178055689705274985L;
	
	/**
	 * 消息类型
	 */
	public static final String EVENT_TYPE_SUBSCRIBE = "subscribe";   //订阅
	public static final String EVENT_TYPE_UNSUBSCRIBE = "unsubscribe"; //取消订阅
	public static final String EVENT_TYPE_SCAN = "SCAN"; //扫码
	public static final String EVENT_TYPE_LOCATION = "LOCATION"; //上报地理位置
	public static final String EVENT_TYPE_CLICK = "CLICK"; //菜单点击
	public static final String EVENT_TYPE_VIEW = "VIEW"; //菜单跳转
	
	/**
	 * 消息类型
	 */
	private String Event;
	
	public WeChatEventMessage() {
	}

	public String getEvent() {
		return Event;
	}

	public void setEvent(String event) {
		Event = event;
	}
}
