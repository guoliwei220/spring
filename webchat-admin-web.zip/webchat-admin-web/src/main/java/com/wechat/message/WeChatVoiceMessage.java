package com.wechat.message;

/**
 * 声音消息
 * @author jiahuijie
 *
 */
public class WeChatVoiceMessage extends WeChatMessage{

	private static final long serialVersionUID = -7530976688438288893L;

	/**
	 * 格式化类型
	 */
	public static final String FORMAT_AMR = "amr";
	public static final String FORMAT_SPEEX = "speex";
	
	/**
	 * 格式化类型
	 */
	private String Format;
	
	/**
	 * 多媒体资源id
	 */
	private String MediaId;
	
	public WeChatVoiceMessage() {
		super();
		setMsgType(MSG_TYPE_VOICE);
	}


	public String getFormat() {
		return Format;
	}

	public void setFormat(String format) {
		Format = format;
	}

	public String getMediaId() {
		return MediaId;
	}

	public void setMediaId(String mediaId) {
		MediaId = mediaId;
	}
	
}
