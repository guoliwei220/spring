package com.wechat.message;

import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * 图文消息
 * @author jiahuijie
 *
 */
@XStreamAlias("xml")
public class WeChatCallbackNewsMessage extends WeChatCallbackMessage{

	private static final long serialVersionUID = -7530976688438288893L;

	/**
	 * 内容
	 */
	private Integer ArticleCount;
	
	/**
	 * 文章列表
	 */
	private List<WeChatCallbackNewsArticle> Articles = new ArrayList<WeChatCallbackNewsArticle>();
	
	public WeChatCallbackNewsMessage() {
		super();
		setMsgType(MSG_TYPE_NEWS);
	}

	public Integer getArticleCount() {
		return ArticleCount;
	}

	public void setArticleCount(Integer articleCount) {
		ArticleCount = articleCount;
	}

	public List<WeChatCallbackNewsArticle> getArticles() {
		return Articles;
	}

	public void setArticles(List<WeChatCallbackNewsArticle> articles) {
		Articles = articles;
	}

}