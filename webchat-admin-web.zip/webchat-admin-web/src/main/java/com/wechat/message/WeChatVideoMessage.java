package com.wechat.message;

/**
 * 视频消息
 * @author jiahuijie
 *
 */
public class WeChatVideoMessage extends WeChatMessage{

	private static final long serialVersionUID = -7530976688438288893L;

	/**
	 * 缩略图
	 */
	private String ThumbMediaId;
	
	/**
	 * 多媒体资源id
	 */
	private String MediaId;
	
	public WeChatVideoMessage() {
		super();
		setMsgType(MSG_TYPE_VIDEO);
	}

	public String getMediaId() {
		return MediaId;
	}

	public void setMediaId(String mediaId) {
		MediaId = mediaId;
	}

	public String getThumbMediaId() {
		return ThumbMediaId;
	}

	public void setThumbMediaId(String thumbMediaId) {
		ThumbMediaId = thumbMediaId;
	}
	
	
	
}
