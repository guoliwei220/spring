package com.wechat.message;

/**
 * 链接消息
 * @author jiahuijie
 *
 */
public class WeChatLinkMessage extends WeChatMessage{

	private static final long serialVersionUID = -7530976688438288893L;

	/**
	 * 链接标题
	 */
	private String Title;
	
	/**
	 * 链接描述
	 */
	private String Description;
	
	/**
	 * 链接描述
	 */
	private String Url;
	
	public WeChatLinkMessage() {
		super();
		setMsgType(MSG_TYPE_LINK);
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		Title = title;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public String getUrl() {
		return Url;
	}

	public void setUrl(String url) {
		Url = url;
	}
	
	
}
