package com.wechat.message;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * 文本消息
 * @author jiahuijie
 *
 */
@XStreamAlias("xml")
public class WeChatCallbackTextMessage extends WeChatCallbackMessage{

	private static final long serialVersionUID = -7530976688438288893L;

	/**
	 * 内容
	 */
	private String Content;
	
	public WeChatCallbackTextMessage() {
		super();
		setMsgType(MSG_TYPE_TEXT);
	}

	public String getContent() {
		return Content;
	}

	public void setContent(String content) {
		Content = content;
	}
	
}
