package com.wechat.message;

/**
 * 文本消息
 * @author jiahuijie
 *
 */
public class WeChatTextMessage extends WeChatMessage{

	private static final long serialVersionUID = -7530976688438288893L;

	/**
	 * 内容
	 */
	private String Content;
	
	public WeChatTextMessage() {
		super();
		setMsgType(MSG_TYPE_TEXT);
	}

	public String getContent() {
		return Content;
	}

	public void setContent(String content) {
		Content = content;
	}
	
}
