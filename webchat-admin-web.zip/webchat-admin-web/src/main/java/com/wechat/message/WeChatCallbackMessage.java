package com.wechat.message;


/**
 * 微信消息基类
 * @author jiahuijie
 *
 */
public class WeChatCallbackMessage implements java.io.Serializable{

	private static final long serialVersionUID = 7178055689705274985L;
	
	/**
	 * 消息类型
	 */
	public static final String MSG_TYPE_TEXT = "text";   //文本消息
	public static final String MSG_TYPE_IMAGE = "image"; //图片消息
	public static final String MSG_TYPE_VOICE = "voice"; //语音消息
	public static final String MSG_TYPE_VIDEO = "video"; //视频消息
	public static final String MSG_TYPE_MUSIC = "music"; //音乐
	public static final String MSG_TYPE_NEWS = "news"; //图文
	
	/**
	 * 接受者openid
	 */
	private String ToUserName;
 
	/**
	 * 发送者openid
	 */
	private String FromUserName;
 
	/**
	 * 创建时间
	 */
	private Long CreateTime;
 
	/**
	 * 消息类型
	 */
	private String MsgType;
	
	public WeChatCallbackMessage() {
	}

	public String getToUserName() {
		return ToUserName;
	}

	public void setToUserName(String toUserName) {
		ToUserName = toUserName;
	}

	public String getFromUserName() {
		return FromUserName;
	}

	public void setFromUserName(String fromUserName) {
		FromUserName = fromUserName;
	}

	public Long getCreateTime() {
		return CreateTime;
	}

	public void setCreateTime(Long createTime) {
		CreateTime = createTime;
	}

	public String getMsgType() {
		return MsgType;
	}

	public void setMsgType(String msgType) {
		MsgType = msgType;
	}
}
