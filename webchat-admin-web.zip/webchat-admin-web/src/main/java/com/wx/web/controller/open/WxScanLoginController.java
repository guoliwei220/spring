package com.wx.web.controller.open;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import com.wx.domain.WxAuth;
import com.wx.service.WxAuthService;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.wechat.exception.WxErrorException;
import com.wechat.exception.WxNetException;
import com.wechat.service.WeChatService;
import com.wechat.wsdata.WebChatTicket;
import com.wx.domain.WxAccessToken;
import com.wx.domain.WxQrcode;
import com.wx.domain.WxScanLogin;
import com.wx.exception.ServiceErrorException;
import com.wx.service.WxAccessTokenService;
import com.wx.service.WxScanLoginService;
import com.wx.web.controller.BaseController;
import com.wx.web.form.open.WxScanLoginInitQrcode;

/**
 * 微信扫码登陆
 * @author Administrator
 *
 */
@Controller
@RequestMapping("/")
public class WxScanLoginController extends BaseController{
	
	public static final String WX_SCAN_LOGIN_TICKET_KEY = "qrcode_ticket";

	public static final String WX_SCAN_LOGIN_TICKET_SECRET_KEY = "qrcode_ticket_secret";

	@Autowired
	private WxAccessTokenService wxAccessTokenService;
	
	@Autowired
	private WxScanLoginService wxScanLoginService;

	@Autowired
	private WxAuthService wxAuthService;

	@Autowired
	private RedisTemplate<String, Object> redisTemplate;
	
	/**
	 * 初始化二维码
	 * @param request
	 * @return
	 * @throws WxNetException 
	 * @throws WxErrorException 
	 * @throws ServiceErrorException 
	 */
	@RequestMapping(value = {"/qrcodeLogin"}, method = RequestMethod.GET)
	public ModelAndView qrcodeLogin(HttpServletRequest request, HttpSession session,
			@Valid WxScanLoginInitQrcode form, BindingResult errors) throws WxErrorException, WxNetException, ServiceErrorException{
		
		if (errors.hasErrors()){
			return buildMVError(sendAjaxError(errors.getFieldErrors()));
		}
		
		//授权校验
		/**
		 * 待加
		 */
		
		
		//获取token
		WxAccessToken wat = wxAccessTokenService.getAccessToken();
		
		//生成临时二维码
		WebChatTicket wct = WeChatService.createTicket(wat.getAccessToken(), WxQrcode.SCENE_SYS_LOGIN);
		
		Date now = new Date();
		WxScanLogin wsl = new WxScanLogin();
		wsl.setCallbackurl(form.getReturnUrl());
		wsl.setTicket(wct.getTicket());
		wsl.setSceneid(WxQrcode.SCENE_SYS_LOGIN);
		wsl.setIsLogin(false);
		wsl.setExpiresTime(DateUtils.addSeconds(now, wct.getExpire_seconds()));

		redisTemplate.opsForValue().set(wsl.getTicket(), wsl, wct.getExpire_seconds(), TimeUnit.SECONDS);

		WxAuth wxAuth = wxAuthService.loadByAppId(form.getAppid());
		if(wxAuth == null){
			return buildMVError(sendAjaxError("appid不存在"));
		}

		session.setAttribute(WX_SCAN_LOGIN_TICKET_KEY, wsl.getTicket());
		session.setAttribute(WX_SCAN_LOGIN_TICKET_SECRET_KEY, wxAuth.getSecret());
		
		return buildMVOK("qrcodelogin", sendAjaxOK("ticket", wsl.getTicket()));
	}
}
