package com.wx.web.form;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.validation.constraints.NotNull;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MPandaGoodsLimitForm extends BasePageLimitForm implements java.io.Serializable{

	private static final long serialVersionUID = 1629285276895610969L;

	/**
	 * 节点ID
	 */
	@NotNull
	private Long kindId;

	public MPandaGoodsLimitForm() {
	}

	public Long getKindId() {
		return kindId;
	}

	public void setKindId(Long kindId) {
		this.kindId = kindId;
	}
}
