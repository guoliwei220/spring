package com.wx.web.controller;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import com.wx.domain.WxAccessToken;
import com.wx.service.WxAccessTokenService;
import com.wx.service.WxJsTicketService;
import com.wx.web.mv.BaseResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.wechat.exception.WxErrorException;
import com.wechat.exception.WxNetException;
import com.wx.web.form.open.WxAuthForm;

@Controller
@RequestMapping
public class TestController extends BaseController{

	@Autowired
	private WxAccessTokenService wxAccessTokenService;

	@Autowired
	private WxJsTicketService wxJsTicketService;


	@RequestMapping(value="/test/auth", method=RequestMethod.GET)
	public ModelAndView auth(HttpServletRequest request, HttpServletResponse response, HttpSession session, 
			ModelMap map) throws UnsupportedEncodingException, WxErrorException, WxNetException {
		
		String nickname = request.getParameter("nickname");
		String imgshow = request.getParameter("imgshow");
		String openId = request.getParameter("openId");
		String sex = request.getParameter("sex");
		String isAttention = request.getParameter("isAttention");
		
		map.put("nickname", nickname);
		map.put("imgshow", imgshow);
		map.put("openId", openId);
		map.put("sex", sex);
		map.put("isAttention", isAttention);
		
		return buildMVOK("test/auth");
	}


	@RequestMapping(value="/test/upload", method=RequestMethod.GET)
	public ModelAndView upload(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			@Valid WxAuthForm form, BindingResult errors) throws UnsupportedEncodingException, WxErrorException, WxNetException {
		return buildMVOK("test/upload");
	}


	@RequestMapping(value="/test/pay", method=RequestMethod.GET)
	public ModelAndView pay(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			@Valid WxAuthForm form, BindingResult errors) throws UnsupportedEncodingException, WxErrorException, WxNetException {
		return buildMVOK("test/pay");
	}


	@RequestMapping("/manager/initWxAccessToken")
	public @ResponseBody BaseResponse initWxAccessToken() {
		wxAccessTokenService.init();
		return sendAjaxOK();
	}

	@RequestMapping("/manager/initWxJsTicket")
	public @ResponseBody BaseResponse initWxJsTicketService() {
		wxJsTicketService.init();
		return sendAjaxOK();
	}
}
