package com.wx.web.form;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.URL;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 添加微信菜单链接form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class WxMenuAddLink extends BaseIdForm implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;

	/**
	 * url
	 */
	@NotBlank
	@URL
	@Length(max=250)
	private String url;
	
	/**
	 * 默认构造方法
	 */
	public WxMenuAddLink() {
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	
}
