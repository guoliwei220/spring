package com.wx.web.form;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 管理员登陆
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class AdminLogin implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;

	/**
	 * 用户名
	 */
	@NotBlank
	private String username;
	
	/**
	 * 用户密码
	 */
	@NotBlank
	private String password;
	
	/**
	 * 验证码
	 */
	@NotBlank
	private String verifyCode;
	
	
	/**
	 * 默认构造方法
	 */
	public AdminLogin() {
	}


	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}


	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}


	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}


	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}


	/**
	 * @return the verifyCody
	 */
	public String getVerifyCode() {
		return verifyCode;
	}


	/**
	 * @param verifyCody the verifyCody to set
	 */
	public void setVerifyCode(String verifyCode) {
		this.verifyCode = verifyCode;
	}
}
