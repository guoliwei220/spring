package com.wx.web.form;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

/**
 * 修改广告位form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class MWxAdsPositionUpdate extends BaseIdForm implements java.io.Serializable{
	private static final long serialVersionUID = -1021860167597666337L;

	/**
	 * 标题
	 */
	@NotBlank
	@Length(min=1, max=20)
	private String title;

	/**
	 * 广告位key
	 */
	@NotBlank
	@Length(min=5, max=20)
	private String adsPosition;

	/**
	 * 默认构造方法
	 */
	public MWxAdsPositionUpdate() {
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAdsPosition() {
		return adsPosition;
	}

	public void setAdsPosition(String adsPosition) {
		this.adsPosition = adsPosition;
	}
}
