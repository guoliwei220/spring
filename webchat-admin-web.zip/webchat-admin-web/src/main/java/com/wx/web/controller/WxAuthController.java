package com.wx.web.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wx.domain.WxAuth;
import com.wx.exception.ServiceErrorException;
import com.wx.service.WxAuthService;
import com.wx.vo.PageListData;
import com.wx.web.form.BaseIdForm;
import com.wx.web.form.BaseIdsForm;
import com.wx.web.form.BasePageLimitForm;
import com.wx.web.form.WxAuthAdd;
import com.wx.web.form.WxAuthUpdate;
import com.wx.web.mv.BaseResponse;

/**
 * 微信授权管理contoller
 * @author jiahuijie
 *
 */
@Controller
@RequestMapping("/manager/wxauth")
public class WxAuthController extends BaseController{

	@Autowired
	private WxAuthService wxAuthService;
	
	/**
	 * 添加微信授权
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/add"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse login(HttpServletRequest request,
			@Valid @RequestBody WxAuthAdd form, BindingResult errors) {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		
		WxAuth wxAuth = new WxAuth();
		wxAuth.setAppid(form.getAppid());
		wxAuth.setName(form.getName());
		wxAuth.setRemark(form.getRemark());
		wxAuth.setSecret(form.getSecret());
		
		try {
			wxAuthService.addAuth(wxAuth);
		} catch (ServiceErrorException e) {
			return sendAjaxError(e.getMsg());
		}
		
		return sendAjaxOK();
	}

	
	/**
	 * 删除
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/del"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse del(HttpServletRequest request,
			@RequestBody @Valid BaseIdForm form, BindingResult errors){
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		wxAuthService.removeAuth(form.getId());
		return sendAjaxOK();
	}
	
	/**
	 * 批量删除
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/dels"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse dels(HttpServletRequest request,
			@RequestBody @Valid BaseIdsForm form, BindingResult errors){
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		wxAuthService.removeAuth(form.getIds());
		return sendAjaxOK();
	}
	
	
	/**
	 * 初始化修改
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/toUpdate"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse view(HttpServletRequest request, HttpSession session,
			@Valid BaseIdForm form, BindingResult errors){
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		
		WxAuth wxAuth = wxAuthService.loadById(form.getId());
		
		if (wxAuth == null){
			return sendAjaxError();
		}
		
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("wxAuth", wxAuth);
		
		return sendAjaxOK(result);
	}
	
	
	/**
	 * 修改微信授权
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/update"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse login(HttpServletRequest request,
			@Valid @RequestBody WxAuthUpdate form, BindingResult errors) {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		
		WxAuth wxAuth = new WxAuth();
		wxAuth.setId(form.getId());
		wxAuth.setAppid(form.getAppid());
		wxAuth.setName(form.getName());
		wxAuth.setRemark(form.getRemark());
		wxAuth.setSecret(form.getSecret());
		
		try {
			wxAuthService.updateAuth(wxAuth);
		} catch (ServiceErrorException e) {
			return sendAjaxError(e.getMsg());
		}
		
		return sendAjaxOK();
	}
	
	
	/**
	 * 分页查询
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = {"/list"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse list(HttpServletRequest request,
			@Valid BasePageLimitForm form, BindingResult errors){
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		
		int pageNo = form.getPageNo();
		int pageSize = form.getPageSize();
		
		PageListData<WxAuth> pd = wxAuthService.list(pageNo, pageSize);
		
		return sendAjaxOK(pd);
	}
}
