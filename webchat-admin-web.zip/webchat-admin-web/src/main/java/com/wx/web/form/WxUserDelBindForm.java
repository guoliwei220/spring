package com.wx.web.form;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 设置微信参数form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class WxUserDelBindForm implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;


	/**
	 * 应用密钥 
	 */
	@NotBlank
	private String openid;


	public String getOpenid() {
		return openid;
	}


	public void setOpenid(String openid) {
		this.openid = openid;
	}
	
	

}
