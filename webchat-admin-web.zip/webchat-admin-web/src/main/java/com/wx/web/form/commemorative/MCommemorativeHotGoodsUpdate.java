package com.wx.web.form.commemorative;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.wx.web.form.BaseIdForm;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;

/**
 * Created by jh on 2016/1/7.
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class MCommemorativeHotGoodsUpdate extends BaseIdForm implements java.io.Serializable {

    @NotBlank
    private String goodsId;

    @NotNull
    private String goodsTitle;

    @NotNull
    private Integer sequence;

    public String getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(String goodsId) {
        this.goodsId = goodsId;
    }

    public String getGoodsTitle() {
        return goodsTitle;
    }

    public void setGoodsTitle(String goodsTitle) {
        this.goodsTitle = goodsTitle;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }
}
