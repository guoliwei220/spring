package com.wx.web.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wechat.util.CommonUtil;
import com.wx.domain.WxConfig;
import com.wx.domain.WxUser;
import com.wx.service.WxConfigService;
import com.wx.service.WxUserService;
import com.wx.vo.PageListData;
import com.wx.web.form.BaseIdForm;
import com.wx.web.form.WxConfigSet;
import com.wx.web.form.WxUserBindForm;
import com.wx.web.form.WxUserDelBindForm;
import com.wx.web.mv.BaseResponse;

/**
 * 参数配置contoller
 * @author jiahuijie
 *
 */
@Controller
@RequestMapping("/manager/wxuser")
public class WxUserController extends BaseController{
	@Autowired
	private WxUserService wxUserService;
	
	/**
	 * 用户解绑
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/userbind"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse userbind(HttpServletRequest request, HttpSession session,
			@Valid @RequestBody WxUserBindForm form, BindingResult errors) {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		};
	 	PageListData<Map<String, Object>> list= wxUserService.findBindUsers(form.getPhonenum());
		if(null==list){
			
			return sendAjaxError("用户未绑定 无需解绑");
		}	
		return sendAjaxOK(list);
	}

	/**
	 * 用户解绑
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/userdelbind"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse  userdelbind(HttpServletRequest request, HttpSession session,
			@RequestBody @Valid WxUserDelBindForm bindForm, BindingResult errors){
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		wxUserService.delUserBind(bindForm.getOpenid());
		return sendAjaxOK();
		
	}
}
