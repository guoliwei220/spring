package com.wx.web.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wechat.message.WeChatCallbackMessage;
import com.wx.domain.WxCallback;
import com.wx.domain.WxResourceNews;
import com.wx.domain.WxResourceText;
import com.wx.service.WxCallbackService;
import com.wx.service.WxNewsResourceService;
import com.wx.service.WxTextResourceService;
import com.wx.vo.PageListData;
import com.wx.web.form.BaseIdForm;
import com.wx.web.form.BaseIdsForm;
import com.wx.web.form.BasePageLimitForm;
import com.wx.web.form.WxResourceAddNews;
import com.wx.web.form.WxResourceAddNewsItem;
import com.wx.web.form.WxResourceAddText;
import com.wx.web.form.WxResourceLoad;
import com.wx.web.form.WxResourceUpdateNews;
import com.wx.web.mv.BaseResponse;

/**
 * 资源contoller
 * @author jiahuijie
 *
 */
@Controller
@RequestMapping("/manager/wxresource")
public class WxResourceController extends BaseController{

	@Autowired
	private WxCallbackService wxCallbackService;
	
	@Autowired
	private WxTextResourceService wxTextResourceService;
	
	@Autowired
	private WxNewsResourceService wxNewsResourceService;
	
	/**
	 * 添加文本回复
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/addText"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse addText(HttpServletRequest request,
			@Valid @RequestBody WxResourceAddText form, BindingResult errors) {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}
		
		Long id = wxTextResourceService.add(form.getContent());
		
		return sendAjaxOK("resourceId", id);
	}
	
	
	/**
	 * 添加新闻回复
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/addNews"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse addNews(HttpServletRequest request,
			@Valid @RequestBody WxResourceAddNews form, BindingResult errors) {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}
		
		WxResourceNews wrn = new WxResourceNews();
		int size = form.getItems().size();
		
		if (size >= 1){
			WxResourceAddNewsItem item = form.getItems().get(0);
			wrn.setHref1(item.getHref());
			wrn.setImage1(item.getImage());
			wrn.setTitle1(item.getTitle());
		} 
		
		if (size >= 2){
			WxResourceAddNewsItem item = form.getItems().get(1);
			wrn.setHref2(item.getHref());
			wrn.setImage2(item.getImage());
			wrn.setTitle2(item.getTitle());
		}
		
		if (size >= 3){
			WxResourceAddNewsItem item = form.getItems().get(2);
			wrn.setHref3(item.getHref());
			wrn.setImage3(item.getImage());
			wrn.setTitle3(item.getTitle());
		}
		
		if (size >= 4){
			WxResourceAddNewsItem item = form.getItems().get(3);
			wrn.setHref4(item.getHref());
			wrn.setImage4(item.getImage());
			wrn.setTitle4(item.getTitle());
		}
		
		if (size >= 5){
			WxResourceAddNewsItem item = form.getItems().get(4);
			wrn.setHref5(item.getHref());
			wrn.setImage5(item.getImage());
			wrn.setTitle5(item.getTitle());
		}
		
		if (size >= 6){
			WxResourceAddNewsItem item = form.getItems().get(5);
			wrn.setHref6(item.getHref());
			wrn.setImage6(item.getImage());
			wrn.setTitle6(item.getTitle());
		}
		
		if (size >= 7){
			WxResourceAddNewsItem item = form.getItems().get(6);
			wrn.setHref7(item.getHref());
			wrn.setImage7(item.getImage());
			wrn.setTitle7(item.getTitle());
		}
		
		if (size >= 8){
			WxResourceAddNewsItem item = form.getItems().get(7);
			wrn.setHref8(item.getHref());
			wrn.setImage8(item.getImage());
			wrn.setTitle8(item.getTitle());
		}
		
		wrn.setItemCount(size);
		wxNewsResourceService.add(wrn);
		
		return sendAjaxOK("resourceId", wrn.getId());
	}
	
	
	/**
	 * 初始化修改新闻回复
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/updateNews"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse updateNewsGet(HttpServletRequest request,
			@Valid BaseIdForm form, BindingResult errors) {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}
		
		WxResourceNews wrn = wxNewsResourceService.loadById(form.getId());
		WxResourceUpdateNews wrun = new WxResourceUpdateNews();
		List<WxResourceAddNewsItem> items = new ArrayList<WxResourceAddNewsItem>();
		
		wrun.setId(wrn.getId());
		wrun.setItems(items);
		
		int size = wrn.getItemCount();
		if (size >= 1) {
			WxResourceAddNewsItem item = new WxResourceAddNewsItem();
			item.setHref(wrn.getHref1());
			item.setImage(wrn.getImage1());
			item.setTitle(wrn.getTitle1());
			items.add(item);
		}
		
		if (size >= 2){
			WxResourceAddNewsItem item = new WxResourceAddNewsItem();
			item.setHref(wrn.getHref2());
			item.setImage(wrn.getImage2());
			item.setTitle(wrn.getTitle2());
			items.add(item);
		}
		
		if (size >= 3){
			WxResourceAddNewsItem item = new WxResourceAddNewsItem();
			item.setHref(wrn.getHref3());
			item.setImage(wrn.getImage3());
			item.setTitle(wrn.getTitle3());
			items.add(item);
		}
		
		if (size >= 4){
			WxResourceAddNewsItem item = new WxResourceAddNewsItem();
			item.setHref(wrn.getHref4());
			item.setImage(wrn.getImage4());
			item.setTitle(wrn.getTitle4());
			items.add(item);
		}
		
		if (size >= 5){
			WxResourceAddNewsItem item = new WxResourceAddNewsItem();
			item.setHref(wrn.getHref5());
			item.setImage(wrn.getImage5());
			item.setTitle(wrn.getTitle5());
			items.add(item);
		}
		
		if (size >= 6){
			WxResourceAddNewsItem item = new WxResourceAddNewsItem();
			item.setHref(wrn.getHref6());
			item.setImage(wrn.getImage6());
			item.setTitle(wrn.getTitle6());
			items.add(item);
		}
		
		if (size >= 7){
			WxResourceAddNewsItem item = new WxResourceAddNewsItem();
			item.setHref(wrn.getHref7());
			item.setImage(wrn.getImage7());
			item.setTitle(wrn.getTitle7());
			items.add(item);
		}
		
		if (size >= 8){
			WxResourceAddNewsItem item = new WxResourceAddNewsItem();
			item.setHref(wrn.getHref8());
			item.setImage(wrn.getImage8());
			item.setTitle(wrn.getTitle8());
			items.add(item);
		}
		
		return sendAjaxOK("resource", wrun);
	}
	
	
	
	/**
	 * 修改新闻回复
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/updateNews"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse updateNewsPost(HttpServletRequest request,
			@Valid @RequestBody WxResourceUpdateNews form, BindingResult errors) {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}
		
		WxResourceNews wrn = new WxResourceNews();
		int size = form.getItems().size();
		
		if (size >= 1){
			WxResourceAddNewsItem item = form.getItems().get(0);
			wrn.setHref1(item.getHref());
			wrn.setImage1(item.getImage());
			wrn.setTitle1(item.getTitle());
		} 
		
		if (size >= 2){
			WxResourceAddNewsItem item = form.getItems().get(1);
			wrn.setHref2(item.getHref());
			wrn.setImage2(item.getImage());
			wrn.setTitle2(item.getTitle());
		}
		
		if (size >= 3){
			WxResourceAddNewsItem item = form.getItems().get(2);
			wrn.setHref3(item.getHref());
			wrn.setImage3(item.getImage());
			wrn.setTitle3(item.getTitle());
		}
		
		if (size >= 4){
			WxResourceAddNewsItem item = form.getItems().get(3);
			wrn.setHref4(item.getHref());
			wrn.setImage4(item.getImage());
			wrn.setTitle4(item.getTitle());
		}
		
		if (size >= 5){
			WxResourceAddNewsItem item = form.getItems().get(4);
			wrn.setHref5(item.getHref());
			wrn.setImage5(item.getImage());
			wrn.setTitle5(item.getTitle());
		}
		
		if (size >= 6){
			WxResourceAddNewsItem item = form.getItems().get(5);
			wrn.setHref6(item.getHref());
			wrn.setImage6(item.getImage());
			wrn.setTitle6(item.getTitle());
		}
		
		if (size >= 7){
			WxResourceAddNewsItem item = form.getItems().get(6);
			wrn.setHref7(item.getHref());
			wrn.setImage7(item.getImage());
			wrn.setTitle7(item.getTitle());
		}
		
		if (size >= 8){
			WxResourceAddNewsItem item = form.getItems().get(7);
			wrn.setHref8(item.getHref());
			wrn.setImage8(item.getImage());
			wrn.setTitle8(item.getTitle());
		}
		
		wrn.setId(form.getId());
		wrn.setItemCount(size);
		wxNewsResourceService.update(wrn);
		
		return sendAjaxOK("resourceId", wrn.getId());
	}
	
	
	/**
	 * 加载回复
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/load"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse load(HttpServletRequest request,
			@Valid WxResourceLoad form, BindingResult errors) {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}
		
		if (!StringUtils.isBlank(form.getBtnKey())){
			WxCallback wc = wxCallbackService.loadCallbackByBtnKey(form.getBtnKey());
			if (wc == null){
				return sendAjaxOK();
			}
			form.setId(wc.getResourceId());
			form.setType(wc.getResourceType());
		} else if (!StringUtils.isBlank(form.getScene())){
			WxCallback wc = wxCallbackService.loadCallbackByScene(form.getScene());
			if (wc == null){
				return sendAjaxOK();
			}
			form.setId(wc.getResourceId());
			form.setType(wc.getResourceType());
		} else {
			if (StringUtils.isBlank(form.getType()) || form.getId() == null){
				return sendAjaxError("参数错误");
			}
		}
		
		String type = form.getType();
		
		if (type.equals(WeChatCallbackMessage.MSG_TYPE_TEXT)){
			WxResourceText wrt = wxTextResourceService.loadById(form.getId());
			
			Map<String,Object> data = new HashMap<String,Object>();
			data.put("type", WeChatCallbackMessage.MSG_TYPE_TEXT);
			data.put("resource", wrt);
			
			return sendAjaxOK(data);
		} else if (type.equals(WeChatCallbackMessage.MSG_TYPE_NEWS)){
			WxResourceNews wrn = wxNewsResourceService.loadById(form.getId());
			Map<String,Object> data = new HashMap<String,Object>();
			data.put("type", WeChatCallbackMessage.MSG_TYPE_NEWS);
			data.put("resource", wrn);
			
			return sendAjaxOK(data);
		}
		
		return sendAjaxError();
	}
	
	
	/**
	 * 删除新闻资源
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/delNews"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse delNews(HttpServletRequest request,
			@RequestBody @Valid BaseIdForm form, BindingResult errors){
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		wxNewsResourceService.remove(form.getId());
		return sendAjaxOK();
	}
	
	/**
	 * 批量删除新闻资源
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/delsNews"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse delsNews(HttpServletRequest request,
			@RequestBody @Valid BaseIdsForm form, BindingResult errors){
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		wxNewsResourceService.remove(form.getIds());
		return sendAjaxOK();
	}
	
	
	
	
	
	/**
	 * 分页加载图文
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/newsList"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse newsList(HttpServletRequest request,
			@Valid BasePageLimitForm form, BindingResult errors) {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}
		
		int pageNo = form.getPageNo();
		int pageSize = form.getPageSize();
		
		PageListData<WxResourceNews> pd = wxNewsResourceService.list(pageNo, pageSize);
		
		return sendAjaxOK(pd);
	}
}
