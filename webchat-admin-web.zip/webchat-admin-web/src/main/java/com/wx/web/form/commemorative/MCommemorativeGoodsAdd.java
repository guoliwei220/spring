package com.wx.web.form.commemorative;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;

/**
 * Created by jh on 2016/1/6.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MCommemorativeGoodsAdd implements java.io.Serializable{

    @NotBlank
    private String goodsId;

    @NotNull
    private String goodsTitle;

    @NotNull
    private Long kindId;

    @NotNull
    private Integer sequence;

    public String getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(String goodsId) {
        this.goodsId = goodsId;
    }

    public String getGoodsTitle() {
        return goodsTitle;
    }

    public void setGoodsTitle(String goodsTitle) {
        this.goodsTitle = goodsTitle;
    }

    public Long getKindId() {
        return kindId;
    }

    public void setKindId(Long kindId) {
        this.kindId = kindId;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }
}
