package com.wx.web.form;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 添加微信菜单消息form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class WxMenuAddMsg extends BaseIdForm implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;

	/**
	 * 消息id
	 */
	@NotNull
	private Long resourceId;
	
	/**
	 * 消息类型
	 */
	@NotBlank
	private String resourceType;
	
	/**
	 * 默认构造方法
	 */
	public WxMenuAddMsg() {
	}

	public Long getResourceId() {
		return resourceId;
	}

	public void setResourceId(Long resourceId) {
		this.resourceId = resourceId;
	}

	public String getResourceType() {
		return resourceType;
	}

	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}
	
}
