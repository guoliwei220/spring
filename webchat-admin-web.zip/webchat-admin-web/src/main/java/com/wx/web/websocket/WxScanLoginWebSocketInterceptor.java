package com.wx.web.websocket;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.server.support.HttpSessionHandshakeInterceptor;

import com.wx.web.controller.open.WxScanLoginController;

/**
 * 握手拦截器
 * @author jiahuijie
 *
 */
public class WxScanLoginWebSocketInterceptor extends HttpSessionHandshakeInterceptor {

	@Override
	public boolean beforeHandshake(ServerHttpRequest req,
			ServerHttpResponse resp, WebSocketHandler hanlder,
			Map<String, Object> attr) throws Exception {
		
		ServletServerHttpRequest request = (ServletServerHttpRequest) req;
		HttpSession session = request.getServletRequest().getSession();
		String qrcode_ticket = (String)session.getAttribute(WxScanLoginController.WX_SCAN_LOGIN_TICKET_KEY);
		
		if (qrcode_ticket == null){
			return false;
		}
		
		attr.put(WxScanLoginController.WX_SCAN_LOGIN_TICKET_KEY, qrcode_ticket);
		return true;
	}
	
	
	@Override
	public void afterHandshake(ServerHttpRequest request,
			ServerHttpResponse response, WebSocketHandler wsHandler,
			Exception ex) {
		super.afterHandshake(request, response, wsHandler, ex);
	}
}
