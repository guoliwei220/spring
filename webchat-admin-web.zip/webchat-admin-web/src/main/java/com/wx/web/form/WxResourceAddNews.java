package com.wx.web.form;

import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 添加新闻资源form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class WxResourceAddNews implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;


	@NotNull
	@Size(max=8)
	private List<WxResourceAddNewsItem> items;
	
	
	/**
	 * 默认构造方法
	 */
	public WxResourceAddNews() {
	}

	public List<WxResourceAddNewsItem> getItems() {
		return items;
	}
	
	public void setItems(List<WxResourceAddNewsItem> items) {
		this.items = items;
	}
}
