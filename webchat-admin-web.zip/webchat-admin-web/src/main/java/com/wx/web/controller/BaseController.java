package com.wx.web.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import nl.bitwalker.useragentutils.Browser;
import nl.bitwalker.useragentutils.OperatingSystem;
import nl.bitwalker.useragentutils.UserAgent;

import org.slf4j.LoggerFactory;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wechat.exception.WxErrorException;
import com.wechat.exception.WxNetException;
import com.wx.config.Config;
import com.wx.config.Constants;
import com.wx.exception.DataFiledErrorException;
import com.wx.exception.ServiceErrorException;
import com.wx.util.CommonUtil;
import com.wx.vo.PageListData;
import com.wx.vo.TreeNode;
import com.wx.vo.UA;
import com.wx.web.mv.BaseResponse;
import com.wx.web.mv.FormResponse;
import com.wx.web.mv.ResponseMessage;
import com.wx.web.mv.ViewResponse;



/**
 * controller基类
 * @author Jiahuijie
 *
 */

public class BaseController {

	private static final org.slf4j.Logger log = LoggerFactory.getLogger(BaseController.class);
	
	/**
	 * 验证码验证
	 * @param session
	 * @param valCode
	 * @return
	 */
	public boolean validateValcode(HttpSession session, String valCode){
		String correctValCode = (String)session.getAttribute(com.google.code.kaptcha.Constants.KAPTCHA_SESSION_KEY);
		
		if (correctValCode == null)
			return false;
		
		if (correctValCode.equalsIgnoreCase(valCode)){
			
			session.removeAttribute(com.google.code.kaptcha.Constants.KAPTCHA_SESSION_KEY);
			
			return true;		
		}
		
			
		
		return false;
	}
	
	
	/**
	 * 获取访问者信息
	 * @param request
	 * @return
	 */
	public UA getVisitorInfo(HttpServletRequest request){
		UserAgent userAgent = UserAgent.parseUserAgentString(request.getHeader("User-Agent"));
		Browser browser = userAgent.getBrowser();  
	    OperatingSystem os = userAgent.getOperatingSystem();
	    
	    UA ua = new UA();
	    ua.setFromIP(request.getRemoteAddr());
	    ua.setToIP(request.getLocalAddr());
	    
	    ua.setBrowerType(browser.getBrowserType().getName());
	    ua.setBrowser(browser.getName());
	    ua.setDeviceType(os.getDeviceType().getName());
	    ua.setOs( os.getGroup().getName());
	    
	    return ua;
	}
	
	/**
	 * 设置cookie
	 * @param name cookie名字
	 * @param value cookie值
	 * @throws  
	 */
	public void setCookie(HttpServletResponse response, String name, String value) {
		try {
			value = URLEncoder.encode(value, "UTF-8");
		} catch (UnsupportedEncodingException e) {}
		Cookie cookie = new Cookie(name, value);
		cookie.setDomain(Config.getStringValue(Constants.KEY_SERVER_DOMAIN));
		cookie.setPath("/");
		cookie.setMaxAge(365 * 24 * 60 * 60);
		response.addCookie(cookie);
	}
	
	/**
	 * 获取cookie值
	 * @param request
	 * @param name
	 * @return
	 */
	public String getCookie(HttpServletRequest request, String name) {
		Cookie[] cookies = request.getCookies();
		for (Cookie cookie : cookies){
			if (cookie.getName().equals(name))
				return cookie.getValue();
		}
		return null;
	}
	
	/**
	 * 删除cookie
	 * @param response
	 * @param name
	 */
	public void removeCookie(HttpServletResponse response, String name){
		Cookie cookie = new Cookie(name, "");
		cookie.setDomain(Config.getStringValue(Constants.KEY_SERVER_DOMAIN));
		cookie.setPath("/"); 
		cookie.setMaxAge(-1);
		response.addCookie(cookie);
	}
	
	/**
	 * 发送成功信息
	 * @return
	 */
	public BaseResponse sendAjaxOK(){
		BaseResponse result = new BaseResponse();
		result.setResponseMessage(ResponseMessage._SUCCESS);
		return result;
	}
	
	/**
	 * 发送错误信息
	 * @return
	 */
	public BaseResponse sendAjaxError(){
		BaseResponse result = new BaseResponse();
		result.setResponseMessage(ResponseMessage._ERROR);
		return result;
	}
	
	/**
	 * 发送未登录信息
	 * @return
	 */
	public BaseResponse sendAjaxUnLoginError(){
		BaseResponse result = new BaseResponse();
		result.setResponseMessage(ResponseMessage._UNLOGIN_ERROR);
		return result;
	}
	
	/**
	 * 发送错误信息
	 * @param msg 错误消息
	 * @return
	 */
	public BaseResponse sendAjaxError(String msg){
		BaseResponse result = new BaseResponse();
		result.setResponseMessage(ResponseMessage._ERROR);
		result.setMsg(msg);
		return result;
	}
	
	/**
	 * 发送表单验证错误
	 * @param field 表单项
	 * @param msg 错误消息
	 * @return
	 */
	public BaseResponse sendAjaxError(String field, String msg){
		FormResponse result = new FormResponse();
		result.setResponseMessage(ResponseMessage._PARAM_ERROR);
		result.setFieldErrorMsg(field, msg);
		return result;
	}
	
	/**
	 * 发送表单验证错误
	 * @param fieldErrors 表单项
	 * @return
	 */
	public BaseResponse sendAjaxError(List<FieldError> fieldErrors){
		FormResponse result = new FormResponse();
		result.setResponseMessage(ResponseMessage._PARAM_ERROR);
		
		for (FieldError fieldError : fieldErrors){
			result.setFieldErrorMsg(fieldError.getField(), fieldError.getDefaultMessage());
			break;
		}
		
		return result;
	}
	
	
	/**
	 * 表单验证错误
	 * @param fieldError 表单错误项
	 * @return
	 */
	public BaseResponse sendAjaxError(FieldError fieldError){
		FormResponse result = new FormResponse();
		result.setResponseMessage(ResponseMessage._PARAM_ERROR);
		result.setFieldErrorMsg(fieldError.getField(), fieldError.getDefaultMessage());
		return result;
	}
	
	
	/**
	 * 正常返回
	 * @param key 值key
	 * @param value 值内容
	 * @return
	 */
	public BaseResponse sendAjaxOK(String key, Object value){
		BaseResponse result = new BaseResponse();
		result.setResponseMessage(ResponseMessage._SUCCESS);
		result.pushData(key, value);
		return result;
	}
	
	
	/**
	 * 正常返回
	 * @param data 返回数据
	 * @return
	 */
	public BaseResponse sendAjaxOK(Map<String,Object> data){
		BaseResponse result = new BaseResponse();
		result.setResponseMessage(ResponseMessage._SUCCESS);
		result.setData(data);
		return result;
	}
	
	
	/**
	 * 正常返回
	 * @param pageData 返回数据
	 * @return
	 */
	public <T> BaseResponse sendAjaxOK(PageListData<T> pageData){
		BaseResponse result = new BaseResponse();
		result.setResponseMessage(ResponseMessage._SUCCESS);
		result.pushData("countAll", pageData.getCountAll());
		result.pushData("list", pageData.getList());
		return result;
	}
	
	
	/**
	 * 构建tree
	 * @param nodes tree节点
	 * @return
	 */
	public <T> BaseResponse sendAjaxTree(List<TreeNode<T>> nodes){
		TreeNode<T> node = new TreeNode<T>();
		node.setRoot(true);
		node = CommonUtil.formatTree(node, nodes);
		
		BaseResponse result = new BaseResponse();
		result.setResponseMessage(ResponseMessage._SUCCESS);
		result.pushData("root", node.getChildren());
		return result;
	}
	
	
	
	/**
	 * 构建成功视图
	 * @return
	 */
	public ViewResponse buildMVOK(String viewName){
		BaseResponse response = sendAjaxOK();
		ViewResponse vr = new ViewResponse(response);
		vr.setViewName(viewName);
		return vr;
	}
	
	/**
	 * 构建成功视图
	 * @return
	 */
	public ViewResponse buildMVOK(String viewName, BaseResponse response){
		ViewResponse vr = new ViewResponse(response);
		vr.setViewName(viewName);
		return vr;
	}
	
	/**
	 * 构建成功视图
	 * @return
	 */
	public ViewResponse buildMVError(BaseResponse response){
		ViewResponse vr = new ViewResponse(response);
		vr.setViewName("error");
		return vr;
	}
	
	
  /** 
	* 用于业务层异常处理的方法 
	*/  
	@ExceptionHandler(ServiceErrorException.class)
	public @ResponseBody BaseResponse ServiceErrorExceptionHandler(ServiceErrorException e, HttpServletRequest request){
		return sendAjaxError(e.getMsg());
	}
	
	
	/** 
	* 用于业务层异常处理的方法 
	*/  
	@ExceptionHandler(DataFiledErrorException.class)
	public @ResponseBody BaseResponse DataFiledErrorExceptionHandler(DataFiledErrorException e, HttpServletRequest request){
		return sendAjaxError(e.getField(), e.getMsg());
	}  
	
	
	/** 
	* 用于微信异常异常处理的方法 
	*/  
	@ExceptionHandler(WxErrorException.class)
	public @ResponseBody BaseResponse WxErrorExceptionHandler(WxErrorException e, HttpServletRequest request){
		return sendAjaxError("微信接口异常:"+ e.getErrcode() + " " + e.getErrdesc());
	}  
	
	/** 
	* 用于微信通信网络异常处理的方法 
	*/  
	@ExceptionHandler(WxNetException.class)
	public @ResponseBody BaseResponse WxNetExceptionHandler(WxNetException e, HttpServletRequest request){
		return sendAjaxError("网络异常");
	}  
	
	/** 
	* 用于异常处理的方法 
	*/  
	@ExceptionHandler(Exception.class)
	public @ResponseBody BaseResponse ExceptionHandler(Exception e, HttpServletRequest request){
		log.error("controller未知异常" ,e);
		e.printStackTrace();
		return sendAjaxError("未知异常");
	}  
}
