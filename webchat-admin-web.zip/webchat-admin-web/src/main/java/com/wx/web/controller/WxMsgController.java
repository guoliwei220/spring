package com.wx.web.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wechat.exception.WxErrorException;
import com.wechat.exception.WxNetException;
import com.wechat.service.WeChatService;
import com.wechat.util.CommonUtil;
import com.wx.domain.WxAccessToken;
import com.wx.domain.WxMsg;
import com.wx.exception.ServiceErrorException;
import com.wx.service.WxAccessTokenService;
import com.wx.service.WxMsgService;
import com.wx.vo.PageListData;
import com.wx.web.form.BaseIdForm;
import com.wx.web.form.BaseIdsForm;
import com.wx.web.form.BasePageLimitForm;
import com.wx.web.form.WxMsgCallback;
import com.wx.web.mv.BaseResponse;

/**
 * 微信消息contoller
 * @author jiahuijie
 *
 */
@Controller
@RequestMapping("/manager/wxmsg")
public class WxMsgController extends BaseController{

	@Autowired
	private WxMsgService wxMsgService;
	
	@Autowired
	private WxAccessTokenService wxAccessTokenService;
	
	/**
	 * 删除
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/del"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse del(HttpServletRequest request,
			@RequestBody @Valid BaseIdForm form, BindingResult errors){
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		wxMsgService.remove(form.getId());
		return sendAjaxOK();
	}
	
	/**
	 * 批量删除
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/dels"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse dels(HttpServletRequest request,
			@RequestBody @Valid BaseIdsForm form, BindingResult errors){
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		wxMsgService.remove(form.getIds());
		return sendAjaxOK();
	}
	
	
	/**
	 * 回复消息
	 * @param request
	 * @return
	 * @throws WxNetException 
	 * @throws WxErrorException 
	 * @throws ServiceErrorException 
	 */
	@RequestMapping(value = {"/callback"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse callback(HttpServletRequest request,
			@Valid @RequestBody WxMsgCallback form, BindingResult errors) throws ServiceErrorException, WxErrorException, WxNetException {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		
		WxMsg wxMsg = new WxMsg();
		wxMsg.setId(form.getId());
		wxMsg.setCallbackMode(WxMsg.CALLBACK_MODE_CUSTOM);
		wxMsg.setCallback(form.getContent());
		
		WxMsg newMsg = wxMsgService.updateMsgByCallback(wxMsg);
		
		WxAccessToken wxAccessToken = wxAccessTokenService.getAccessToken();
		
		JSONObject msgJson = new JSONObject();
		msgJson.put("touser", newMsg.getFromOpenId());
		msgJson.put("msgtype", "text");
		
		JSONObject textJson = new JSONObject();
		textJson.put("content", form.getContent());
		msgJson.put("text", textJson);
		
		WeChatService.sendMsg(wxAccessToken.getAccessToken(), msgJson);
		
		return sendAjaxOK();
	}
	
	
	/**
	 * 分页查询
	 * @param request
	 * @param session
	 * @return
	 */
	@RequestMapping(value = {"/list"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse list(HttpServletRequest request,
			@Valid BasePageLimitForm form, BindingResult errors){
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		
		int pageNo = form.getPageNo();
		int pageSize = form.getPageSize();
		
		PageListData<Map<String,Object>> pd = wxMsgService.listUnCallback(pageNo, pageSize);
		
		for (Map<String,Object> map : pd.getList()){
			map.put("msg", CommonUtil.xmlToJSON((String)map.get("msg")));
		}
		
		return sendAjaxOK(pd);
	}
}
