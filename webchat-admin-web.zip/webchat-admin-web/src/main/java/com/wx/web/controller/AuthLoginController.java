package com.wx.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wx.domain.AuthLoginLog;
import com.wx.exception.DataFiledErrorException;
import com.wx.service.AdminService;
import com.wx.util.CommonUtil;
import com.wx.vo.AdminLoginSign;
import com.wx.vo.UA;
import com.wx.web.form.AdminLogin;
import com.wx.web.form.AdminUpdatePass;
import com.wx.web.mv.BaseResponse;

/**
 * 登陆contoller
 * @author jiahuijie
 *
 */
@Controller
@RequestMapping
public class AuthLoginController extends BaseController{

	@Autowired
	private AdminService adminService;
	
	/**
	 * 管理员登陆
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/login"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse login(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			@Valid @RequestBody AdminLogin login, BindingResult errors) {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		
		if (!validateValcode(session, login.getVerifyCode())){
			return sendAjaxError("valcode", "验证码不正确");
		}
		
		AdminLoginSign als;
		
		try {
			als = adminService.login(login.getUsername(), login.getPassword());
		} catch (DataFiledErrorException e) {
			return sendAjaxError(e.getField(), e.getMsg());
		}
		
		session.setAttribute(AdminLoginSign.class.getName(), als);
		
		UA ua = getVisitorInfo(request);
		AuthLoginLog llog = new AuthLoginLog();
		llog.setBrowzer(ua.getBrowser());
		llog.setBrowzerType(ua.getBrowerType());
		llog.setFromIP(ua.getFromIP());
		llog.setOs(ua.getOs());
		llog.setOsType(ua.getDeviceType());
		llog.setToIP(ua.getToIP());
		llog.setUserId(als.getAdminId());
		
		adminService.loginLog(llog);
		
		String alscookie = CommonUtil.ObjectToJSON(als);
		setCookie(response, "sign", alscookie);
		
		return sendAjaxOK("sign", als);
	}
	
	
	
	/**
	 * 注销登陆
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/logout"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse logout(HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		removeCookie(response, "sign");
		session.invalidate();
		return sendAjaxOK();
	}
	
	
	/**
	 * 管理员修改密码
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/manager/updatePass"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse updatePass(HttpServletRequest request, HttpSession session,
			@Valid @RequestBody AdminUpdatePass form, BindingResult errors) {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		
		if (!form.getNewPassword().equals(form.getRePassword())){
			return sendAjaxError("rePassword", "重复密码不正确");
		}
		
		AdminLoginSign als = (AdminLoginSign)session.getAttribute(AdminLoginSign.class.getName());
		
		try {
			adminService.updatePassword(als.getAdminId(), CommonUtil.MD5(form.getOldPassword()), CommonUtil.MD5(form.getNewPassword()));
		} catch (DataFiledErrorException e) {
			return sendAjaxError(e.getField(), e.getMsg());
		}
		
		return sendAjaxOK();
	}
}
