package com.wx.web.form;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.validation.constraints.NotNull;

/**
 * Created by jh on 2015/11/25.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MWxAdsFormUpdate extends BaseIdForm implements java.io.Serializable {

    private String image;

    private String link;

    @NotNull(message = "广告位置不能为空")
    private String adsPosition;

    private Integer sequence;

    @NotNull(message = "商品标题不能为空")
    private String title;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getAdsPosition() {
        return adsPosition;
    }

    public void setAdsPosition(String adsPosition) {
        this.adsPosition = adsPosition;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
