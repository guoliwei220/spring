package com.wx.web.mv;

import java.io.Serializable;


/**
 * @author Administrator
 *
 */
public class ResponseMessage implements Serializable{

	private static final long serialVersionUID = 655602099707803752L;

	/**
	 * 代码
	 */
	private String key;
	
	/**
	 * 代码
	 */
	private String code;
	
	/**
	 * 错误信息
	 */
	private String msg;
	
	/**
	 * 构造
	 * @param key
	 * @param code
	 */
	public ResponseMessage(String key, String code) {
		this.key = key;
		this.code = code;
		this.msg = ResponseMessageConfig.getValue(key);
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public void setCode(String code) {
		this.code = code;
	}
	
	public String getCode() {
		return code;
	}
	
	
	//操作成功
	public static final ResponseMessage _SUCCESS = new ResponseMessage("_SUCCESS", "000000");
	//操作失败
	public static final ResponseMessage _ERROR = new ResponseMessage("_ERROR", "000001");
	//参数错误
	public static final ResponseMessage _PARAM_ERROR = new ResponseMessage("_PARAM_ERROR", "000002");
	//未登录
	public static final ResponseMessage _UNLOGIN_ERROR = new ResponseMessage("_UNLOGIN_ERROR", "000003");
	//权限不足
	public static final ResponseMessage _UNAUTH_ERROR = new ResponseMessage("_UNAUTH_ERROR", "000004");
	//尚未申请
	public static final ResponseMessage _UNAPPLY_ERROR = new ResponseMessage("_UNAPPLY_ERROR", "000005");
	//代理商申请未审核
	public static final ResponseMessage _UNREVIEW_AGENT_ERROR = new ResponseMessage("_UNREVIEW_AGENT_ERROR", "000006");
	//代理商审核不通过
	public static final ResponseMessage _REFUSE_AGENT_ERROR = new ResponseMessage("_REFUSE_AGENT_ERROR", "000007");
	//会员申请未审核
	public static final ResponseMessage _UNREVIEW_MEMBERS_ERROR = new ResponseMessage("_UNREVIEW_MEMBERS_ERROR", "000008");
	//会员审核不通过
	public static final ResponseMessage _REFUSE_MEMBERS_ERROR = new ResponseMessage("_REFUSE_MEMBERS_ERROR", "000009");
}
