package com.wx.web.controller.commemorative;

import com.wx.exception.ServiceErrorException;
import com.wx.mobileDomain.MCommemorativeGoods;
import com.wx.mobileDomain.MCommemorativeKind;
import com.wx.mobileDomain.MPandaGoods;
import com.wx.service.MCommemorativeKindService;
import com.wx.service.MCommemorativeService;
import com.wx.vo.PageListData;
import com.wx.vo.TreeNode;
import com.wx.web.controller.BaseController;
import com.wx.web.form.*;
import com.wx.web.form.commemorative.*;
import com.wx.web.mv.BaseResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

/**
 * 纪念币管理
 * Created by fengshiyou on 2016/1/5.
 */
@Controller
@RequestMapping("/manager/commemorative")
public class CommemorativeController extends BaseController {

    @Autowired
    private MCommemorativeKindService mCommemorativeKindService;

    @Autowired
    private MCommemorativeService mCommemorativeService;


    /**
     * 添加类别
     * @param request
     * @return
     * @throws ServiceErrorException
     */
    @RequestMapping(value = {"/kindAdd"}, method = RequestMethod.POST)
    public @ResponseBody BaseResponse addMenu(HttpServletRequest request, HttpSession session,
                                              @Valid @RequestBody MCommemorativeKindAdd form, BindingResult errors) throws ServiceErrorException {

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldError());
        }

        MCommemorativeKind mCommemorativeKind = new MCommemorativeKind();
        mCommemorativeKind.setName(form.getName());
        mCommemorativeKind.setParentId(form.getParentId());
        mCommemorativeKind.setImage(form.getImage());

        mCommemorativeKindService.add(mCommemorativeKind);

        TreeNode<MCommemorativeKind> node = new TreeNode<MCommemorativeKind>();
        node.setId(mCommemorativeKind.getId());
        node.setData(mCommemorativeKind);
        node.setLabel(mCommemorativeKind.getName());
        node.setParentId(mCommemorativeKind.getParentId());
        node.setRoot(false);
        node.setChildren(new ArrayList<TreeNode<MCommemorativeKind>>());

        return sendAjaxOK("node", node);
    }

    /**
     * 删除
     * @param request
     * @return
     * @throws ServiceErrorException
     */
    @RequestMapping(value = {"/kindDel"}, method = RequestMethod.POST)
    public @ResponseBody BaseResponse del(HttpServletRequest request,
                                          @RequestBody @Valid BaseIdForm form, BindingResult errors) throws ServiceErrorException{
        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }

        mCommemorativeKindService.remove(form.getId());

        return sendAjaxOK();
    }

    /**
     * 修改类别
     * @param request
     * @return
     * @throws ServiceErrorException
     */
    @RequestMapping(value = {"/kindUpdate"}, method = RequestMethod.GET)
    public @ResponseBody BaseResponse initUpdate(HttpServletRequest request, HttpSession session,
                                                 @Valid BaseIdForm form, BindingResult errors) throws ServiceErrorException {

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldError());
        }

        MCommemorativeKind mCommemorativeKind = mCommemorativeKindService.load(form.getId());

        return sendAjaxOK("mCommemorativeKind", mCommemorativeKind);

    }

    /**
     * 修改类别
     * @param request
     * @return
     * @throws ServiceErrorException
     */
    @RequestMapping(value = {"/kindUpdate"}, method = RequestMethod.POST)
    public @ResponseBody BaseResponse update(HttpServletRequest request, HttpSession session,
                                             @Valid @RequestBody MCommemorativeKindUpdate form, BindingResult errors) throws ServiceErrorException {

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldError());
        }

        MCommemorativeKind mCommemorativeKind = new MCommemorativeKind();
        mCommemorativeKind.setId(form.getId());
        mCommemorativeKind.setName(form.getName());
        mCommemorativeKind.setParentId(form.getParentId());
        mCommemorativeKind.setImage(form.getImage());

        mCommemorativeKindService.update(mCommemorativeKind);

        TreeNode<MCommemorativeKind> node = new TreeNode<MCommemorativeKind>();
        node.setId(mCommemorativeKind.getId());
        node.setData(mCommemorativeKind);
        node.setLabel(mCommemorativeKind.getName());
        node.setParentId(mCommemorativeKind.getParentId());
        node.setRoot(false);

        return sendAjaxOK("node", node);
    }

    /**
     * 加载类别
     * @param request
     * @return
     */
    @RequestMapping(value = {"/kindList"}, method = RequestMethod.GET)
    public @ResponseBody
    BaseResponse list(HttpServletRequest request, HttpSession session) {
        List<MCommemorativeKind> menus = mCommemorativeKindService.loadMenu();
        List<TreeNode<MCommemorativeKind>> treeNodes = new ArrayList<TreeNode<MCommemorativeKind>>();
        for (MCommemorativeKind dlArea : menus){
            TreeNode<MCommemorativeKind> node = new TreeNode<MCommemorativeKind>();
            node.setId(dlArea.getId());
            node.setData(dlArea);
            node.setLabel(dlArea.getName());
            node.setParentId(dlArea.getParentId());
            node.setRoot(false);
            treeNodes.add(node);
        }
        return sendAjaxTree(treeNodes);
    }



    /**
     * 添加纪念币
     * @param request
     * @return
     */
    @RequestMapping(value = {"/goodsAdd"}, method = RequestMethod.POST)
    public @ResponseBody BaseResponse addNews(HttpServletRequest request,
                                              @Valid @RequestBody MCommemorativeGoodsAdd form, BindingResult errors) {
        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldError());
        }

        MCommemorativeGoods pg = new MCommemorativeGoods();
        pg.setGoodsId(form.getGoodsId());
        pg.setGoodsTitle(form.getGoodsTitle());
        pg.setKindId(form.getKindId());
        pg.setSequence(form.getSequence());

        mCommemorativeService.add(pg);

        return sendAjaxOK();
    }


    /**
     * 初始化修改纪念币
     * @param request
     * @return
     */
    @RequestMapping(value = {"/goodsUpdate"}, method = RequestMethod.GET)
    public @ResponseBody BaseResponse updateNewsGet(HttpServletRequest request,
                                                    @Valid BaseIdForm form, BindingResult errors) {

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldError());
        }

        MCommemorativeGoods mCommemorativeGoods = mCommemorativeService.loadById(form.getId());

        return sendAjaxOK("mCommemorativeGoods", mCommemorativeGoods);
    }



    /**
     * 修改纪念币
     * @param request
     * @return
     */
    @RequestMapping(value = {"/goodsUpdate"}, method = RequestMethod.POST)
    public @ResponseBody BaseResponse updateNewsPost(HttpServletRequest request,
                                                     @Valid @RequestBody MCommemorativeGoodsUpdate form, BindingResult errors) {

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldError());
        }

        MCommemorativeGoods pg = new MCommemorativeGoods();
        pg.setId(form.getId());
        pg.setGoodsId(form.getGoodsId());
        pg.setGoodsTitle(form.getGoodsTitle());
        pg.setKindId(form.getKindId());
        pg.setSequence(form.getSequence());

        mCommemorativeService.update(pg);

        return sendAjaxOK();
    }


    /**
     * 删除
     * @param request
     * @return
     */
    @RequestMapping(value = {"/goodsDel"}, method = RequestMethod.POST)
    public @ResponseBody BaseResponse goodsDel(HttpServletRequest request,
                                               @RequestBody @Valid BaseIdForm form, BindingResult errors){
        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }
        mCommemorativeService.remove(form.getId());
        return sendAjaxOK();
    }

    /**
     * 批量删除
     * @param request
     * @return
     */
    @RequestMapping(value = {"/goodsDels"}, method = RequestMethod.POST)
    public @ResponseBody BaseResponse goodsDels(HttpServletRequest request,
                                                @RequestBody @Valid BaseIdsForm form, BindingResult errors){
        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }
        mCommemorativeService.remove(form.getIds());
        return sendAjaxOK();
    }



    /**
     * 分页加载
     * @param request
     * @return
     */
    @RequestMapping(value = {"/goodsList"}, method = RequestMethod.GET)
    public @ResponseBody BaseResponse goodsList(HttpServletRequest request,
                                                @Valid MPandaGoodsLimitForm form, BindingResult errors) {
        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldError());
        }

        PageListData<MCommemorativeGoods> pd = mCommemorativeService.list(form.getKindId(), form.getPageNo(), form.getPageSize());

        return sendAjaxOK(pd);
    }





    /**
     * 添加纪念币热销商品
     * @param request
     * @return
     */
    @RequestMapping(value = {"/hotGoodsAdd"}, method = RequestMethod.POST)
    public @ResponseBody BaseResponse hotGoodsAdd(HttpServletRequest request,
                                              @Valid @RequestBody MCommemorativeHotGoodsAdd form, BindingResult errors) {
        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldError());
        }

        MCommemorativeGoods pg = new MCommemorativeGoods();
        pg.setGoodsId(form.getGoodsId());
        pg.setGoodsTitle(form.getGoodsTitle());
        pg.setSequence(form.getSequence());

        mCommemorativeService.add(pg);

        return sendAjaxOK();
    }


    /**
     * 初始化修改纪念币热销商品
     * @param request
     * @return
     */
    @RequestMapping(value = {"/hotGoodsUpdate"}, method = RequestMethod.GET)
    public @ResponseBody BaseResponse hotGoodsUpdateGet(HttpServletRequest request,
                                                    @Valid BaseIdForm form, BindingResult errors) {

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldError());
        }

        MCommemorativeGoods mCommemorativeGoods = mCommemorativeService.loadById(form.getId());

        return sendAjaxOK("mCommemorativeGoods", mCommemorativeGoods);
    }



    /**
     * 修改纪念币热销商品
     * @param request
     * @return
     */
    @RequestMapping(value = {"/hotGoodsUpdate"}, method = RequestMethod.POST)
    public @ResponseBody BaseResponse hotGoodsUpdatePost(HttpServletRequest request,
                                                     @Valid @RequestBody MCommemorativeHotGoodsUpdate form, BindingResult errors) {

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldError());
        }

        MCommemorativeGoods pg = new MCommemorativeGoods();
        pg.setId(form.getId());
        pg.setGoodsId(form.getGoodsId());
        pg.setGoodsTitle(form.getGoodsTitle());
        pg.setSequence(form.getSequence());

        mCommemorativeService.update(pg);

        return sendAjaxOK();
    }


    /**
     * 删除热销商品
     * @param request
     * @return
     */
    @RequestMapping(value = {"/hotGoodsDel"}, method = RequestMethod.POST)
    public @ResponseBody BaseResponse hotGoodsDel(HttpServletRequest request,
                                               @RequestBody @Valid BaseIdForm form, BindingResult errors){
        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }
        mCommemorativeService.remove(form.getId());
        return sendAjaxOK();
    }

    /**
     * 批量删除热销商品
     * @param request
     * @return
     */
    @RequestMapping(value = {"/hotGoodsDels"}, method = RequestMethod.POST)
    public @ResponseBody BaseResponse hotGoodsDels(HttpServletRequest request,
                                                @RequestBody @Valid BaseIdsForm form, BindingResult errors){
        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }
        mCommemorativeService.remove(form.getIds());
        return sendAjaxOK();
    }



    /**
     * 分页加载热销商品
     * @param request
     * @return
     */
    @RequestMapping(value = {"/hotGoodsList"}, method = RequestMethod.GET)
    public @ResponseBody BaseResponse hotGoodsList(HttpServletRequest request,
                                                @Valid BasePageLimitForm form, BindingResult errors) {
        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldError());
        }

        PageListData<MCommemorativeGoods> pd = mCommemorativeService.list(null, form.getPageNo(), form.getPageSize());

        return sendAjaxOK(pd);
    }
}
