package com.wx.web.form;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.validation.constraints.NotNull;

/**
 * Created by jh on 2015/11/27.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class HotGoodsFormFind implements java.io.Serializable{

    /**
     * 商品的ID
     */
    private Long goodsId;

    /**
     * 商品的名字
     */
    private String goodsName;

    /**
     * 起始位置
     */
    @NotNull
    private Integer pageNo;

    /**
     * 分页容量
     */
    @NotNull
    private Integer pageSize;

    public Long getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(Long goodsId) {
        this.goodsId = goodsId;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
}
