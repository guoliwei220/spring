package com.wx.web.form;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;

/**
 * Created by jh on 2015/11/30.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class HotGoodsUpdateSqForm  implements java.io.Serializable{

    @NotNull(message = "ID不能为空")
    private Long id;

    @NotNull(message = "权重不能为空")
    private Integer sequence;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }
}
