package com.wx.web.controller.open;

import com.wechat.message.*;
import com.wechat.service.WeChatService;
import com.wechat.util.CommonUtil;
import com.wechat.wsdata.WebChatUserInfo;
import com.wx.config.Config;
import com.wx.config.Constants;
import com.wx.domain.*;
import com.wx.exception.ServiceErrorException;
import com.wx.service.*;
import com.wx.web.controller.BaseController;
import net.sf.json.JSONObject;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 微信对接contoller
 * @author jiahuijie
 *
 */
@Controller
@RequestMapping
public class WxConnectionController extends BaseController{
	
	private static final Logger log = Logger.getLogger(WxConnectionController.class);
	
	@Autowired
	private WxConfigService wxConfigService;
	
	@Autowired
	private WxAccessTokenService wxAccessTokenService;
	
	@Autowired
	private WxCallbackService wxCallbackService;
	
	@Autowired
	private WxMsgService wxMsgService;
	
	@Autowired
	private WxScanLoginService wxScanLoginService;
	
	@Autowired
	private WxUserService wxUserService;
	
	@RequestMapping(value="/connect", method=RequestMethod.GET)
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException{
		resp.setContentType("text/json; charset=UTF-8"); 
		PrintWriter out = resp.getWriter();
		
		String _echostr = req.getParameter("echostr");
		
		if (checkSignature(req)){
			out.print(_echostr);
			out.close();
		}
	}
	
	
	/**
	 * 处理消息
	 */
	@RequestMapping(value="/connect", method=RequestMethod.POST)
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		//鉴权
		if (!checkSignature(req))
			return;
		
		//初始化接受消息
		String xmlmsg = CommonUtil.convertStreamToString(req.getInputStream());
		JSONObject msg = CommonUtil.xmlToJSON(xmlmsg);
		
		//初始化被动响应消息
		String callbackxmlmsg = null;
		
		//获取基本参数
		String toUsername = msg.getString("ToUserName");
		String fromUsername = msg.getString("FromUserName");
		String msgType = msg.getString("MsgType");

		//插入消息记录
//		WxMsg wxMsg = new WxMsg();
//		String bb = URLEncoder.encode(xmlmsg, "UTF-8");
//		wxMsg.setMsg(xmlmsg);
//		wxMsg.setFromOpenId(fromUsername);
//		wxMsg.setToOpenId(toUsername);
//		wxMsg.setIsReply(false);
//		wxMsg.setMsgType(msgType);
//		wxMsgService.add(wxMsg);
		
		boolean isAllCallback = true;
		
		//文本信息
	    if (WeChatMessage.MSG_TYPE_TEXT.equals(msgType)){
    		String content = msg.getString("Content");
    		
			Object obj = wxCallbackService.loadResourceByWords(content);
			if (obj != null){
				isAllCallback = false;
			}
			callbackxmlmsg = buildMsg(fromUsername, toUsername, obj);
	    } 
	    
	    //事件信息
	    else if (WeChatMessage.MSG_TYPE_EVENT.equals(msgType)) {
	    	isAllCallback = false;
	    	String event = msg.getString("Event");
	    	
	    	if (WeChatEventMessage.EVENT_TYPE_SUBSCRIBE.equalsIgnoreCase(event)){//订阅事件
				wxUserService.updateAttention(fromUsername, true);
	    	/**	//记录用户关注
	    		try {
	    			WxAccessToken wat = wxAccessTokenService.getAccessToken();
	    			WebChatUserInfo wcui = WeChatService.getUserInfo(wat.getAccessToken(), fromUsername);
	    			WxUser user = new WxUser();
	    			user.setCity(wcui.getCity());
	    			user.setCountry(wcui.getCountry());
	    			user.setImgshow(wcui.getHeadImgUrl());
	    			user.setNickname(wcui.getNickname());
	    			user.setOpenid(wcui.getOpenId());
	    			user.setProvince(wcui.getProvince());
					user.setIsAttention(true);
	    			wxUserService.createUser(user);
				} catch (Exception e) {
					log.error("用户订阅记录异常：", e);
				}
			 */
	    		
	    		if (msg.has("Ticket")){
	    			String ticket = msg.getString("Ticket");
	    			int eventKey = msg.getInt("EventKey");
	    			
	    			if (eventKey == WxQrcode.SCENE_SYS_LOGIN) {
		    			try {
							wxScanLoginService.scan(fromUsername, ticket);
							
							//发送登陆成功的模板消息
							
						} catch (ServiceErrorException e) {
							log.error("扫码登陆异常：", e);
						}
	    			}
    			}
	    		
				Object obj = wxCallbackService.loadResourceByScence(WxCallback.SCENE_SUBSCRIBE);
				callbackxmlmsg = buildMsg(fromUsername, toUsername, obj);
	    		
	    	} else if (WeChatEventMessage.EVENT_TYPE_UNSUBSCRIBE.equalsIgnoreCase(event)) {//取消关注
				wxUserService.updateAttention(fromUsername, false);
			} else if (WeChatEventMessage.EVENT_TYPE_SCAN.equalsIgnoreCase(event)){//扫码事件
    			String ticket = msg.getString("Ticket");
    			int eventKey = msg.getInt("EventKey");
    			
    			if (eventKey == WxQrcode.SCENE_SYS_LOGIN) {
	    			try {
						wxScanLoginService.scan(fromUsername, ticket);
						
						//发送登陆成功的模板消息
						
					} catch (ServiceErrorException e) {
						log.error("扫码登陆异常：", e);
					}
    			}
    			
	    	} else if (WeChatEventMessage.EVENT_TYPE_CLICK.equalsIgnoreCase(event)){//菜单事件
    			String eventKey = msg.getString("EventKey");
    			
				Object obj = wxCallbackService.loadResourceByBtnKey(eventKey);
				callbackxmlmsg = buildMsg(fromUsername, toUsername, obj);
	    	} 
	    }
	    
	    //位置信息
	    else if (WeChatEventMessage.MSG_TYPE_LOCATION.equals(msgType)) {} 
	    
	    //视频信息
	    else if (WeChatEventMessage.MSG_TYPE_VIDEO.equals(msgType)) {} 
	    
	    //语音信息
	    else if (WeChatEventMessage.MSG_TYPE_VOICE.equals(msgType)) {}
	    
	    //连接信息
	    else if (WeChatEventMessage.MSG_TYPE_LINK.equals(msgType)) {}
	    
	    
	    //没有任何回复消息则加载自动回复
	    if (isAllCallback){
	    	Object obj = wxCallbackService.loadResourceByScence(WxCallback.SCENE_CALLBACK);
	    	callbackxmlmsg = buildMsg(fromUsername, toUsername, obj);
		}
	    
	    //发送自动回复
	    if (callbackxmlmsg != null){
			try {
				resp.setContentType("text/xml; charset=UTF-8"); 
				PrintWriter out = resp.getWriter();
				out.print(callbackxmlmsg);
				out.flush();
				out.close();
			} catch (IOException e) {
				log.debug("自动回复响应报错",e);
			}
			
//			wxMsg.setCallback(callbackxmlmsg);
//			wxMsg.setCallbackMode(WxMsg.CALLBACK_MODE_AUTO);
//			wxMsg.setIsReply(true);
//			wxMsgService.updateMsgByCallback(wxMsg);
		}
	    
	    
	    
	}
	
	
	/**
	 * 鉴权
	 * @return
	 * @throws Exception
	 */
	public boolean checkSignature(HttpServletRequest req){
		
		WxConfig wxConfig = wxConfigService.getConfig();
		
		//微信加密签名
		String _signature = req.getParameter("signature");
		//时间戳
		String _timestamp = req.getParameter("timestamp");
		//随机数
		String _nonce = req.getParameter("nonce");

		if (WeChatService.checkSignature(wxConfig.getToken(), _signature, _timestamp, _nonce)){
			return true;
		}
		
		return false;
	}
	
	
	/**
	 * 构建消息
	 * @param fromUsername
	 * @param toUsername
	 * @param msg
	 */
	public String buildMsg(String fromUsername, String toUsername, Object msg){
		if (msg == null){
			return null;
		}
		
		String xmlmsg = null;
		
		if (WxResourceText.class.isInstance(msg)){
			xmlmsg = buildTextMsg(toUsername, fromUsername, (WxResourceText)msg);
		} else if (WxResourceNews.class.isInstance(msg)){
			xmlmsg = buildNewsMsg(toUsername, fromUsername, (WxResourceNews)msg);
		}
		
		return xmlmsg;
	}
	
	
	/**
	 * 构建文本信息
	 * @param fromUsername
	 * @param toUsername
	 * @param msg
	 * @return
	 */
	public String buildTextMsg(String fromUsername, String toUsername, WxResourceText msg){
		WeChatCallbackTextMessage wcctm = new WeChatCallbackTextMessage();
		wcctm.setContent(msg.getContent());
		wcctm.setCreateTime(new Date().getTime() * 1000);
		wcctm.setFromUserName(fromUsername);
		wcctm.setToUserName(toUsername);
		
		String callbackMsg = CommonUtil.WxObjToXML(wcctm);
		
		return callbackMsg;
	}
	
	/**
	 * 构建图文信息
	 * @param fromUsername
	 * @param toUsername
	 * @param msg
	 * @return
	 */
	public String buildNewsMsg(String fromUsername, String toUsername, WxResourceNews msg){
		WeChatCallbackNewsMessage wccnm = new WeChatCallbackNewsMessage();
		wccnm.setCreateTime(new Date().getTime() * 1000);
		wccnm.setFromUserName(fromUsername);
		wccnm.setToUserName(toUsername);
		wccnm.setArticleCount(msg.getItemCount());
		
		List<WeChatCallbackNewsArticle> articles = wccnm.getArticles();
		
		Map<String,Object> newsMap = CommonUtil.WxObjToMap(msg);
		for (int i = 0; i < wccnm.getArticleCount(); i++){
			WeChatCallbackNewsArticle article = new WeChatCallbackNewsArticle();
			article.setDescription("");
			article.setPicUrl(Config.getStringValue(Constants.KEY_IMG_SERVER) + (String)newsMap.get("image" + (i+1)));
			article.setTitle((String)newsMap.get("title" + (i+1)));
			article.setUrl((String)newsMap.get("href" + (i+1)));
			articles.add(article);
		}
		
		String callbackMsg = CommonUtil.WxObjToXML(wccnm);
	
		return callbackMsg;
	}
	
	
	/**
	 * 构建图文信息
	 * @param fromUsername
	 * @param toUsername
	 * @param articles
	 * @return
	 */
	public String buildNewsMsg(String fromUsername, String toUsername, List<WeChatCallbackNewsArticle> articles){
		WeChatCallbackNewsMessage wccnm = new WeChatCallbackNewsMessage();
		wccnm.setCreateTime(new Date().getTime() * 1000);
		wccnm.setFromUserName(fromUsername);
		wccnm.setToUserName(toUsername);
		wccnm.setArticleCount(articles.size());
		wccnm.setArticles(articles);
		
		String callbackMsg = CommonUtil.WxObjToXML(wccnm);
	
		return callbackMsg;
	}
}
