package com.wx.web.form;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 添加新闻资源form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class WxResourceAddNewsItem implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;

	/**
     * 标题
     */
	@NotBlank
	@Length(max=20)
    private String title;

    /**
     * 图片
     */
	@NotBlank
	@Length(max=50)
    private String image;

    /**
     * 链接
     */
	@NotBlank
	@Length(max=350)
    private String href;
	
	/**
	 * 默认构造方法
	 */
	public WxResourceAddNewsItem() {
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getHref() {
		return href;
	}

	public void setHref(String href) {
		this.href = href;
	}

	
}
