package com.wx.web.mv;

import org.springframework.web.servlet.ModelAndView;

public class ViewResponse extends ModelAndView{

	private BaseResponse response;
	
	public ViewResponse(BaseResponse response){
		this.addObject("response", response);
	}
	
	public ViewResponse(String viewName){
		super.setViewName(viewName);
	}

	public BaseResponse getResponse() {
		return response;
	}

	public void setResponse(BaseResponse response) {
		this.response = response;
	}
	
	
}
