package com.wx.web.mv;



public class FormResponse extends BaseResponse {

	/**
	 * 字段错误
	 */
	private FieldError fieldError = new FieldError();
	
	public FormResponse(){
		super();
	}
	
	public FieldError getFieldError() {
		return fieldError;
	}

	public void setFieldError(FieldError fieldError) {
		this.fieldError = fieldError;
	}
	
	public void setFieldErrorMsg(String field, String msg){
		FieldError fieldError = new FieldError();
		fieldError.setField(field);
		fieldError.setErrmsg(msg);
		this.fieldError = fieldError;
	}
	
}
