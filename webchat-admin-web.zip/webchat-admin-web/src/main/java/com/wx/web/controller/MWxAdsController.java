package com.wx.web.controller;

import com.wx.mobileDomain.MWxAds;
import com.wx.mobileDomain.MWxAdsPosition;
import com.wx.service.MWxAdsPositionService;
import com.wx.service.MWxAdsService;
import com.wx.vo.PageListData;
import com.wx.web.form.*;
import com.wx.web.mv.BaseResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by jh on 2015/11/25.
 */
@Controller()
@RequestMapping("/manager/mAds")
public class MWxAdsController extends BaseController {

    @Autowired
    private MWxAdsService mWxAdsService;

    @RequestMapping(value = {"/list"}, method = RequestMethod.GET)
    public @ResponseBody
    BaseResponse list(HttpServletRequest request,
                      @Valid BasePageLimitForm form, BindingResult errors){

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }
        int pageNo = form.getPageNo();
        int pageSize = form.getPageSize();
        PageListData<Map<String,Object>> pd = mWxAdsService.list(pageNo,pageSize);

        return sendAjaxOK(pd);
    }

    @RequestMapping(value = {"/save"}, method = RequestMethod.GET)
    public @ResponseBody
    BaseResponse saveGet(HttpServletRequest request){
        List<MWxAdsPosition> mWxAdsPositions = mWxAdsService.selectAdsPostionList();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("mWxAdsPositions", mWxAdsPositions);
        return sendAjaxOK(data);
    }

    @RequestMapping(value = {"/save"}, method = RequestMethod.POST)
    public @ResponseBody
    BaseResponse save(HttpServletRequest request,
                      @RequestBody @Valid MWxAdsFormAdd form, BindingResult errors){

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }
        mWxAdsService.save(form);

        return sendAjaxOK();
    }


    @RequestMapping(value = {"/update"}, method = RequestMethod.GET)
    public @ResponseBody
    BaseResponse updateGet(HttpServletRequest request,
                        @Valid BaseIdForm form, BindingResult errors){

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }

        MWxAds mWxAds = mWxAdsService.load(form.getId());
        List<MWxAdsPosition> mWxAdsPositions = mWxAdsService.selectAdsPostionList();

        Map<String, Object> data = new HashMap<String, Object>();
        data.put("mWxAds", mWxAds);
        data.put("mWxAdsPositions", mWxAdsPositions);

        return sendAjaxOK(data);
    }

    @RequestMapping(value = {"/update"}, method = RequestMethod.POST)
    public @ResponseBody
    BaseResponse update(HttpServletRequest request,
                      @RequestBody @Valid MWxAdsFormUpdate form, BindingResult errors){

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }

        mWxAdsService.update(form);

        return sendAjaxOK();
    }

    @RequestMapping(value = {"/delete"}, method = RequestMethod.GET)
    public @ResponseBody
    BaseResponse delete(HttpServletRequest request,
                        @Valid MWxAdsFormDel form, BindingResult errors){

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }

        mWxAdsService.delete(form);

        return sendAjaxOK();
    }

    @RequestMapping(value = {"/deletes"}, method = RequestMethod.POST)
    public @ResponseBody BaseResponse dels(HttpServletRequest request,
                                           @RequestBody @Valid BaseIdsForm form, BindingResult errors){
        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }
        mWxAdsService.deletes(form.getIds());
        return sendAjaxOK();
    }






}
