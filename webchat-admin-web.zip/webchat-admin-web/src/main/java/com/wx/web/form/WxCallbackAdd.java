package com.wx.web.form;

import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 添加自动回复form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class WxCallbackAdd implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;

	/**
	 * 规则id
	 */
	private Long id;
	
	/**
	 * 规则名称
	 */
	@Length(max=20)
	private String name;
	
	/**
	 * 资源id
	 */
	@NotNull
	private Long resourceId;
	
	/**
	 * 资源类型
	 */
	@NotNull
	private String resourceType;
	
	/**
	 * 场景
	 */
	@NotNull
	private String scene;
	
	/**
	 * 关键词
	 */
	@Size(max=30)
	private List<String> words;
	
	/**
	 * 默认构造方法
	 */
	public WxCallbackAdd() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getResourceId() {
		return resourceId;
	}

	public void setResourceId(Long resourceId) {
		this.resourceId = resourceId;
	}

	public String getResourceType() {
		return resourceType;
	}

	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

	public String getScene() {
		return scene;
	}

	public void setScene(String scene) {
		this.scene = scene;
	}

	public List<String> getWords() {
		return words;
	}

	public void setWords(List<String> words) {
		this.words = words;
	}

}
