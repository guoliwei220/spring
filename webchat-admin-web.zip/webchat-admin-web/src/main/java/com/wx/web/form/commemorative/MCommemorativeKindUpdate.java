package com.wx.web.form.commemorative;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.wx.web.form.BaseIdForm;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

/**
 * Created by jh on 2016/1/6.
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class MCommemorativeKindUpdate extends BaseIdForm implements java.io.Serializable{

    /**
     * 菜单名称
     */
    @NotBlank
    @Length(min = 1, max = 15)
    private String name;

    /**
     * 类别的图片
     */
    @NotBlank
    private String image;

    /**
     * 父角色ID
     */
    private Long parentId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }
}
