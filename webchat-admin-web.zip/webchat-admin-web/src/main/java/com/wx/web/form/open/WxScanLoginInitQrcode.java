package com.wx.web.form.open;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.URL;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 微信扫码登陆创建二维码form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class WxScanLoginInitQrcode implements java.io.Serializable{

	private static final long serialVersionUID = 4450854470513418204L;

	/**
	 * 回传url
	 */
	@NotBlank
	@URL
	private String returnUrl;

	/**
	 * appid
	 */
	@NotBlank
	private String appid;
	
	
	/**
	 * 默认构造方法
	 */
	public WxScanLoginInitQrcode() {
	}

	public String getReturnUrl() {
		return returnUrl;
	}
	
	public void setReturnUrl(String returnUrl) {
		this.returnUrl = returnUrl;
	}

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}
}
