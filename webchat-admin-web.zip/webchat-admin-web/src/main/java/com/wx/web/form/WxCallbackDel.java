package com.wx.web.form;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 删除自动回复form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class WxCallbackDel implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;

	/**
	 * 规则id
	 */
	private Long id;
	
	/**
	 * 场景
	 */
	@NotNull
	private String scene;
	
	/**
	 * 默认构造方法
	 */
	public WxCallbackDel() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getScene() {
		return scene;
	}

	public void setScene(String scene) {
		this.scene = scene;
	}
}
