package com.wx.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wx.domain.WxConfig;
import com.wx.service.WxConfigService;
import com.wx.web.form.WxConfigSet;
import com.wx.web.mv.BaseResponse;

/**
 * 参数配置contoller
 * @author jiahuijie
 *
 */
@Controller
@RequestMapping("/manager/wxconfig")
public class WxConfigController extends BaseController{

	@Autowired
	private WxConfigService wxConfigService;
	
	/**
	 * 设置参数
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/setConfig"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse login(HttpServletRequest request, HttpSession session,
			@Valid @RequestBody WxConfigSet form, BindingResult errors) {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		
		WxConfig wxConfig = new WxConfig();
		wxConfig.setAppid(form.getAppKey());
		wxConfig.setAppsecret(form.getAppSecret());
		wxConfig.setToken(form.getToken());
		
		wxConfigService.setConfig(wxConfig);
		
		return sendAjaxOK();
	}
	
	
	
	/**
	 * 加载参数
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/loadConfig"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse logout(HttpServletRequest request, HttpSession session) {
		WxConfig config = wxConfigService.getConfig();
		return sendAjaxOK("wxConfig", config);
	}
}
