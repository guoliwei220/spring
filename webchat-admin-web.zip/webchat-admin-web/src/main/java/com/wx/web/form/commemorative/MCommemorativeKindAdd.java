package com.wx.web.form.commemorative;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

/**
 * Created by jh on 2016/1/6.
 */
public class MCommemorativeKindAdd implements java.io.Serializable{

    private static final long serialVersionUID = -1021860167597666337L;

    /**
     * 类别名称
     */
    @NotBlank
    @Length(min = 1, max = 15)
    private String name;

    /**
     * 类别描述
     */
    @NotBlank
    @Length(max=250)
    private String image;

    /**
     * 父角色ID
     */
    private Long parentId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }
}
