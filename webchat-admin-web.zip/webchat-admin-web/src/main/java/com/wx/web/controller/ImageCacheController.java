package com.wx.web.controller;

import java.io.File;

import javax.imageio.stream.FileImageInputStream;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wx.config.Config;
import com.wx.config.Constants;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wx.util.ImageProcessor;

/**
 * 获取不同规格图片
 * @author jiahuijie
 *
 */
@Controller
@RequestMapping("/imgres")
public class ImageCacheController {
	
	/**
	 * 获取各种规格图片
	 * @param request
	 * @param response
	 * @param relPath
	 * @param width
	 * @param height
	 * @param imgType
	 * @throws Exception
	 */
	@RequestMapping(value = "/{relPath}/{width}_{height}.{imgType}", method = RequestMethod.GET)
	public void imgCache(HttpServletRequest request,
			HttpServletResponse response, @PathVariable String relPath,
			@PathVariable String width, @PathVariable String height,
			@PathVariable String imgType) throws Exception {

		// 获取真实目录
		String realPath = request.getSession().getServletContext()
				.getRealPath(relPath.replace("_", "/"));

		File realFile = new File(realPath);
		
		if (!realFile.exists()) {
			return;
		}

		response.setContentType("image/" + imgType);
		ServletOutputStream out = response.getOutputStream();

		ImageProcessor.scaleImage(realPath, out, imgType,
				Integer.parseInt(width), Integer.parseInt(height), true);
		
		out.flush();
		out.close();
	}
	
	
	/**
	 * 获取原始图片
	 * @param request
	 * @param response
	 * @param relPath
	 * @throws Exception
	 */
	@RequestMapping(value = "/{relPath}.{imgType}", method = RequestMethod.GET)
	public void imgBasic(HttpServletRequest request,HttpServletResponse response, 
			@PathVariable String relPath, @PathVariable String imgType) throws Exception {

		// 获取真实目录
		String realPath = request.getSession().getServletContext()
				.getRealPath(relPath.replace("_", "/"));
		
		File realFile = new File(realPath + "." + imgType);
			
		if (!realFile.exists()) {
			return;
		}
		request.getRequestDispatcher("/" + relPath.replace("_", "/") + "." +  imgType).forward(request, response);
	}
}
