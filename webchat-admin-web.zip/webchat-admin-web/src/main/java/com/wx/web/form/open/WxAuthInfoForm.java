package com.wx.web.form.open;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 微信授权form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class WxAuthInfoForm implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;

	/**
	 * 应用id
	 */
	private String appid;
		
	/**
	 * 时间戳
	 */
	private Long timestamp;
	
	/**
	 * 随机数
	 */
	private String nonce;
	
	/**
	 * 签名
	 */
	private String signature;
	
	/**
	 * openid
	 */
	private String openId;
	
	/**
	 * 默认构造方法
	 */
	public WxAuthInfoForm() {
	}


	public String getAppid() {
		return appid;
	}


	public void setAppid(String appid) {
		this.appid = appid;
	}


	public Long getTimestamp() {
		return timestamp;
	}


	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}


	public String getNonce() {
		return nonce;
	}


	public void setNonce(String nonce) {
		this.nonce = nonce;
	}


	public String getSignature() {
		return signature;
	}


	public void setSignature(String signature) {
		this.signature = signature;
	}
	
	public String getOpenId() {
		return openId;
	}
	
	public void setOpenId(String openId) {
		this.openId = openId;
	}
}
