package com.wx.web.websocket;

import com.wechat.service.WeChatService;
import com.wx.domain.WxAuth;
import com.wx.exception.ServiceErrorException;
import com.wx.service.WxAuthService;
import com.wx.service.WxScanLoginService;
import com.wx.util.CommonUtil;
import com.wx.web.controller.BaseController;
import com.wx.web.controller.open.WxScanLoginController;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.net.URLEncoder;
import java.util.*;


/**
 * 控制台handler
 * @author jiahuijie
 *
 */
public class WxScanLoginHandler extends TextWebSocketHandler {
	
	@Autowired
	private WxScanLoginService wxScanLoginService;

	@Autowired
	private WxAuthService wxAuthService;
	
	/**
	 * 连接成功
	 */
	@Override
	public void afterConnectionEstablished(WebSocketSession session)
			throws Exception {
	}

	@Override
	protected void handleTextMessage(WebSocketSession session,
									 TextMessage message) throws Exception {
		super.handleTextMessage(session, message);

		String ticket = (String)session.getAttributes().get(WxScanLoginController.WX_SCAN_LOGIN_TICKET_KEY);
		String secret = (String)session.getAttributes().get(WxScanLoginController.WX_SCAN_LOGIN_TICKET_SECRET_KEY);

		if(StringUtils.isBlank(ticket)){
			return;
		}

		try {
			Map<String, Object> tickinfo = wxScanLoginService.check(ticket);

			Map<String, Object> data = new HashMap<String, Object>();
			data.put("isLogin", false);

			if (tickinfo == null){
				CharSequence payload = JSONObject.fromObject(new BaseController().sendAjaxOK(data)).toString();
				TextMessage toMsg = new TextMessage(payload);
				session.sendMessage(toMsg);
				return;
			}

			StringBuffer sb = new StringBuffer();
			sb.append(tickinfo.get("callbackurl"));

			if (sb.indexOf("?") < 0){
				sb.append("?");
				sb.append("tk=1");
			} else {
				sb.append("&");
				sb.append("tk=1");
			}

			String appsecret = secret;
			String timestamp = String.valueOf(new Date().getTime());
			String nonce = CommonUtil.getRandomStr(6);

			String signature = null;

			//SHA1加密
			//1. 将secrect、timestamp、nonce三个参数进行字典序排序
			List<String> list = new ArrayList<String>();
			list.add(appsecret);
			list.add(timestamp);
			list.add(nonce);
			Collections.sort(list);

			//2. 将三个参数字符串拼接成一个字符串进行sha1加密
			StringBuffer signatureBuffer = new StringBuffer();
			for (String str : list){
				signatureBuffer.append(str);
			}

			//3. 签名加密
			signature = CommonUtil.SHA1(signatureBuffer.toString());

			sb.append("timestamp=").append(timestamp);
			sb.append("&nonce=").append(nonce);
			sb.append("&signature=").append(signature);

			sb.append("&nickname=");
			sb.append(URLEncoder.encode((String)tickinfo.get("nickname"),"utf8"));

			sb.append("&openid=");
			sb.append(URLEncoder.encode((String)tickinfo.get("openid"),"utf8"));

			sb.append("&imgshow=");
			sb.append(URLEncoder.encode((String)tickinfo.get("imgshow"),"utf8"));

			data.put("isLogin", true);
			data.put("toUrl", sb.toString());

			CharSequence payload = JSONObject.fromObject(new BaseController().sendAjaxOK(data)).toString();
			TextMessage toMsg = new TextMessage(payload);
			session.sendMessage(toMsg);
		} catch (ServiceErrorException e) {
			CharSequence payload = JSONObject.fromObject(new BaseController().sendAjaxError(e.getMsg())).toString();
			TextMessage toMsg = new TextMessage(payload);
			session.sendMessage(toMsg);
		}
	}

	/**
	 * 处理错误
	 */
	@Override
	public void handleTransportError(WebSocketSession session,
			Throwable exception) throws Exception {
		if(session.isOpen()){
            session.close();
        }
	}

	/**
	 * 连接关闭
	 */
	@Override
	public void afterConnectionClosed(WebSocketSession session,
			CloseStatus closeStatus) throws Exception {
	}

	@Override
	public boolean supportsPartialMessages() {
		return false;
	}
}
