package com.wx.web.mv;



public class FieldError {

	/**
	 * 成功
	 */
	public String field;
	
	/**
	 * 消息
	 */
	private String errmsg;
	
	
	public FieldError(){
		
	}


	public String getField() {
		return field;
	}


	public void setField(String field) {
		this.field = field;
	}


	public String getErrmsg() {
		return errmsg;
	}


	public void setErrmsg(String errmsg) {
		this.errmsg = errmsg;
	}
	
}
