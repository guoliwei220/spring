package com.wx.web.form;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 添加微信授权form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class WxAuthAdd implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;

	/**
	 * 授权方名称
	 */
	@NotBlank
	@Length(min=2, max=20)
	private String name;
	
	/**
	 * 应用Id
	 */
	@NotBlank
	@Length(min=5, max=20)
	private String appid;
	
	/**
	 * 应用密钥 
	 */
	@NotBlank
	@Length(min=5, max=20)
	private String secret;
	
	/**
	 * 备注
	 */
	@Length(max=350)
	private String remark;
	
	/**
	 * 默认构造方法
	 */
	public WxAuthAdd() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public String getSecret() {
		return secret;
	}

	public void setSecret(String secret) {
		this.secret = secret;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
