package com.wx.web.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wechat.exception.WxErrorException;
import com.wechat.exception.WxNetException;
import com.wechat.service.WeChatService;
import com.wx.domain.WxAccessToken;
import com.wx.domain.WxCallback;
import com.wx.domain.WxMenu;
import com.wx.exception.ServiceErrorException;
import com.wx.service.WxAccessTokenService;
import com.wx.service.WxMenuService;
import com.wx.util.JacksonUtil;
import com.wx.vo.TreeNode;
import com.wx.vo.WxTreeNode;
import com.wx.web.form.BaseIdForm;
import com.wx.web.form.WxMenuAdd;
import com.wx.web.form.WxMenuAddLink;
import com.wx.web.form.WxMenuAddMsg;
import com.wx.web.form.WxMenuUpdate;
import com.wx.web.mv.BaseResponse;

/**
 * 菜单配置contoller
 * @author jiahuijie
 *
 */
@Controller
@RequestMapping("/manager/wxmenu")
public class WxMenuController extends BaseController{

	@Autowired
	private WxMenuService wxMenuService;
	
	@Autowired
	private WxAccessTokenService wxAccessTokenService;
	
	/**
	 * 添加菜单
	 * @param request
	 * @return
	 * @throws ServiceErrorException 
	 */
	@RequestMapping(value = {"/add"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse addMenu(HttpServletRequest request, HttpSession session,
			@Valid @RequestBody WxMenuAdd form, BindingResult errors) throws ServiceErrorException {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}
		
		if (form.getParentId() == null){
			if (form.getName().length() > 4){
				return sendAjaxError("name","一级菜单最多4个字符");
			}
		} else {
			if (form.getName().length() > 7){
				return sendAjaxError("name","二级菜单做多7个字符");
			}
		}
		
		WxMenu wxMenu = new WxMenu();
		wxMenu.setName(form.getName());
		wxMenu.setParentId(form.getParentId());
		
		WxMenu wx = wxMenuService.add(wxMenu);
		
		TreeNode<WxMenu> node = new TreeNode<WxMenu>();
		node.setId(wx.getId());
		node.setData(wx);
		node.setLabel(wx.getName());
		node.setParentId(wx.getParentId());
		node.setRoot(false);
		node.setChildren(new ArrayList<TreeNode<WxMenu>>());
		
		return sendAjaxOK("node", node);
	}
	

	/**
	 * 删除
	 * @param request
	 * @return
	 * @throws ServiceErrorException 
	 */
	@RequestMapping(value = {"/del"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse del(HttpServletRequest request,
			@RequestBody @Valid BaseIdForm form, BindingResult errors) throws ServiceErrorException{
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		
		wxMenuService.remove(form.getId());
		
		return sendAjaxOK();
	}
	
	
	/**
	 * 修改菜单
	 * @param request
	 * @return
	 * @throws ServiceErrorException 
	 */
	@RequestMapping(value = {"/update"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse update(HttpServletRequest request, HttpSession session,
			@Valid @RequestBody WxMenuUpdate form, BindingResult errors) throws ServiceErrorException {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}
		
		if (form.getParentId() == null){
			if (form.getName().length() > 4){
				return sendAjaxError("name","一级菜单最多4个字符");
			}
		} else {
			if (form.getName().length() > 7){
				return sendAjaxError("name","二级菜单做多7个字符");
			}
		}
		
		WxMenu wxMenu = new WxMenu();
		wxMenu.setName(form.getName());
		wxMenu.setId(form.getId());
		
		WxMenu wx = wxMenuService.update(wxMenu);
		
		TreeNode<WxMenu> node = new TreeNode<WxMenu>();
		node.setId(wx.getId());
		node.setData(wx);
		node.setLabel(wx.getName());
		node.setParentId(wx.getParentId());
		node.setRoot(false);
		
		return sendAjaxOK("node", node);
		
	}
	
	
	/**
	 * 添加菜单url
	 * @param request
	 * @return
	 * @throws ServiceErrorException 
	 */
	@RequestMapping(value = {"/addLink"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse addLink(HttpServletRequest request, HttpSession session,
			@Valid @RequestBody WxMenuAddLink form, BindingResult errors) throws ServiceErrorException {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}
		
		wxMenuService.addLink(form.getId(), form.getUrl());
		
		return sendAjaxOK();
	}
	
	/**
	 * 添加事件响应url
	 * @param request
	 * @return
	 * @throws ServiceErrorException 
	 */
	@RequestMapping(value = {"/addMsg"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse addMsg(HttpServletRequest request, HttpSession session,
			@Valid @RequestBody WxMenuAddMsg form, BindingResult errors) throws ServiceErrorException {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}
		
		WxCallback wxCallback = new WxCallback();
		wxCallback.setResourceId(form.getResourceId());
		wxCallback.setResourceType(form.getResourceType());
		
		wxMenuService.addMsg(form.getId(), wxCallback);
		
		return sendAjaxOK("btnKey", wxCallback.getBtnKey());
	}
	
	
	/**
	 * 菜单重设动作
	 * @param request
	 * @return
	 * @throws ServiceErrorException 
	 */
	@RequestMapping(value = {"/resetAction"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse resetAction(HttpServletRequest request, HttpSession session,
			@Valid @RequestBody BaseIdForm form, BindingResult errors) throws ServiceErrorException {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}
		
		wxMenuService.resetAction(form.getId());
		
		return sendAjaxOK();
	}
	
	
	
	
	/**
	 * 加载菜单
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/list"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse list(HttpServletRequest request, HttpSession session) {
		List<WxMenu> menus = wxMenuService.loadMenu();
		List<TreeNode<WxMenu>> treeNodes = new ArrayList<TreeNode<WxMenu>>();
		for (WxMenu wxMenu : menus){
			TreeNode<WxMenu> node = new TreeNode<WxMenu>();
			node.setId(wxMenu.getId());
			node.setData(wxMenu);
			node.setLabel(wxMenu.getName());
			node.setParentId(wxMenu.getParentId());
			node.setRoot(false);
			treeNodes.add(node);
		}
		return sendAjaxTree(treeNodes);
	}
	
	
	
	/**
	 * 发布菜单
	 * @param request
	 * @return
	 * @throws ServiceErrorException 
	 * @throws WxNetException 
	 * @throws WxErrorException 
	 */
	@RequestMapping(value = {"/apply"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse apply(HttpServletRequest request, HttpSession session) throws ServiceErrorException, WxErrorException, WxNetException {
		
		WxTreeNode node = wxMenuService.apply();
		
		Map<String,Object> menu = new HashMap<String,Object>();
		menu.put("button", node.getSub_button());
		
		String menuJsonP = JacksonUtil.objectToJSON(menu);
		JSONObject menuJson = JSONObject.fromObject(menuJsonP);
		
		WxAccessToken wat = wxAccessTokenService.getAccessToken();
		WeChatService.createMenu(wat.getAccessToken(), menuJson);
		
		return sendAjaxOK();
	}
}
