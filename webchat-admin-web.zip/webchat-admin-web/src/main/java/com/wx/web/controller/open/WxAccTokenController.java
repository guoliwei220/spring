package com.wx.web.controller.open;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.wechat.exception.WxErrorException;
import com.wechat.exception.WxNetException;
import com.wx.domain.WxAccessToken;
import com.wx.exception.ServiceErrorException;
import com.wx.service.WxAccessTokenService;
import com.wx.service.WxConfigService;
import com.wx.web.controller.BaseController;
import com.wx.web.mv.BaseResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * 微信通信Token contoller
 * @author jiahuijie
 *
 */
@Controller("fWxAccTokenController")
public class WxAccTokenController extends BaseController{

	@Autowired
	private WxConfigService wxConfigService;

	@Autowired
	private WxAccessTokenService wxAccessTokenService;
	
	/**
	 * 获取参数
	 * @param request
	 * @return
	 * @throws WxNetException 
	 * @throws WxErrorException 
	 * @throws ServiceErrorException 
	 */
	@RequestMapping(value = {"/tokenConfig"}, method = RequestMethod.GET)
	@ResponseBody
	public BaseResponse tokenConfig(HttpServletRequest request) throws ServiceErrorException, WxErrorException, WxNetException {

		WxAccessToken wxAccessToken = wxAccessTokenService.getAccessToken();
		
		return sendAjaxOK("wxAccessToken", wxAccessToken);
	}


	/**
	 * 获取参数jsonp
	 * @param request
	 * @return
	 * @throws WxNetException
	 * @throws WxErrorException
	 * @throws ServiceErrorException
	 */
	@RequestMapping(value = {"/tokenConfig/jsonp"})
	@ResponseBody
	public JSONPObject tokenConfigJsonP(HttpServletRequest request, String callback) throws ServiceErrorException, WxErrorException, WxNetException {

		WxAccessToken wxAccessToken = wxAccessTokenService.getAccessToken();

		return new JSONPObject(callback, sendAjaxOK("wxAccessToken", wxAccessToken));
	}
}
