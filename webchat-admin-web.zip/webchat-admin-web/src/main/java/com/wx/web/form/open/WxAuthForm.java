package com.wx.web.form.open;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.NotBlank;

/**
 * 微信授权form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class WxAuthForm implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;

	/**
	 * 应用id
	 */
	private String appid;
	
	/**
	 * 网页获取信息code
	 */
	private String code;
	
	/**
	 * 跳转状态
	 */
	private String state;
	
	/**
	 * 回调url
	 */
	private String callback_uri;
	
	/**
	 * 默认构造方法
	 */
	public WxAuthForm() {
	}


	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCallback_uri() {
		return callback_uri;
	}
	
	public void setCallback_uri(String callback_uri) {
		this.callback_uri = callback_uri;
	}
	
}
