package com.wx.web.controller;

import com.wechat.exception.WxErrorException;
import com.wechat.exception.WxNetException;
import com.wechat.service.WeChatService;
import com.wechat.util.CommonUtil;
import com.wx.domain.WxAccessToken;
import com.wx.domain.WxAuth;
import com.wx.domain.WxMsg;
import com.wx.exception.ServiceErrorException;
import com.wx.mobileDomain.MWxAdsPosition;
import com.wx.service.MWxAdsPositionService;
import com.wx.service.WxAccessTokenService;
import com.wx.service.WxMsgService;
import com.wx.vo.PageListData;
import com.wx.web.form.*;
import com.wx.web.mv.BaseResponse;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

/**
 * 微信广告位contoller
 * @author jiahuijie
 *
 */
@Controller
@RequestMapping("/manager/mAdsPosition")
public class MWxAdsPositionController extends BaseController{

	@Autowired
	private MWxAdsPositionService mWxAdsPositionService;

	/**
	 * 添加广告位
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/add"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse add(HttpServletRequest request,
											@Valid @RequestBody MWxAdsPositionAdd form, BindingResult errors) {

		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}

		MWxAdsPosition position = new MWxAdsPosition();
		position.setTitle(form.getTitle());
		position.setAdsPosition(form.getAdsPosition());

		try {
			mWxAdsPositionService.add(position);
		} catch (ServiceErrorException e) {
			return sendAjaxError(e.getMsg());
		}

		return sendAjaxOK();
	}


	/**
	 * 删除
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/del"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse del(HttpServletRequest request,
										  @RequestBody @Valid BaseIdForm form, BindingResult errors){
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		mWxAdsPositionService.remove(form.getId());
		return sendAjaxOK();
	}

	/**
	 * 批量删除
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/dels"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse dels(HttpServletRequest request,
										   @RequestBody @Valid BaseIdsForm form, BindingResult errors){
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		mWxAdsPositionService.remove(form.getIds());
		return sendAjaxOK();
	}


	/**
	 * 初始化修改
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/update"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse view(HttpServletRequest request, HttpSession session,
										   @Valid BaseIdForm form, BindingResult errors){

		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}

		MWxAdsPosition wxAdsPosition = mWxAdsPositionService.loadById(form.getId());

		if (wxAdsPosition == null){
			return sendAjaxError();
		}

		Map<String,Object> result = new HashMap<String,Object>();
		result.put("wxAdsPosition", wxAdsPosition);

		return sendAjaxOK(result);
	}


	/**
	 * 修改广告位
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/update"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse login(HttpServletRequest request,
											@Valid @RequestBody MWxAdsPositionUpdate form, BindingResult errors) {

		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}

		MWxAdsPosition position = new MWxAdsPosition();
		position.setId(form.getId());
		position.setTitle(form.getTitle());
		position.setAdsPosition(form.getAdsPosition());

		try {
			mWxAdsPositionService.update(position);
		} catch (ServiceErrorException e) {
			return sendAjaxError(e.getMsg());
		}

		return sendAjaxOK();
	}


	/**
	 * 分页查询
	 * @param request
	 * @param form
	 * @param errors
	 * @return
	 */
	@RequestMapping(value = {"/list"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse list(HttpServletRequest request,
			@Valid BasePageLimitForm form, BindingResult errors){
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		
		int pageNo = form.getPageNo();
		int pageSize = form.getPageSize();
		
		PageListData<MWxAdsPosition> pd = mWxAdsPositionService.list(pageNo, pageSize);
		
		return sendAjaxOK(pd);
	}
}
