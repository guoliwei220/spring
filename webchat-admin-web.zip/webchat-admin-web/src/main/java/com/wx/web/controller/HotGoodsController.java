package com.wx.web.controller;

import com.wx.ecShopDomain.EsGoods;
import com.wx.mobileDomain.MHotGoods;
import com.wx.service.HotGoodsService;
import com.wx.vo.PageListData;
import com.wx.web.form.*;
import com.wx.web.mv.BaseResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by fengshiyou on 2015/11/27.
 */
@Controller
@RequestMapping("/manager/hotGoods")
public class HotGoodsController extends BaseController {

    @Autowired
    private HotGoodsService hotGoodsService;

    /**
     * 分页查询普通商品
     * @param request
     * @param form
     * @param errors
     * @return
     */
    @RequestMapping(value = {"/list"}, method = RequestMethod.GET)
    public @ResponseBody
    BaseResponse list(HttpServletRequest request,
                      @Valid HotGoodsFormFind form, BindingResult errors){
        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }
        PageListData<EsGoods> pd = hotGoodsService.list(form);

        return sendAjaxOK(pd);
    }


    /**
     * 分页查询热销商品
     * @param request
     * @param form
     * @param errors
     * @return
     */
    @RequestMapping(value = {"/hotList"}, method = RequestMethod.GET)
    public @ResponseBody
    BaseResponse listHotGoods(HttpServletRequest request,
                      @Valid BasePageLimitForm form, BindingResult errors){

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }
        PageListData<MHotGoods> pd = hotGoodsService.listHotGoods(form.getPageNo(), form.getPageSize());

        return sendAjaxOK(pd);
    }

    /**
     * 保存热销商品
     * @param request
     * @param form
     * @param errors
     * @return
     */
    @RequestMapping(value = {"/save"}, method = RequestMethod.POST)
    public @ResponseBody
    BaseResponse save(HttpServletRequest request,
                      @RequestBody @Valid HotGoodsFormAdd form, BindingResult errors){

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }
        hotGoodsService.save(form);

        return sendAjaxOK();
    }

    /**
     * 查询热销商品
     * @param request
     * @param form
     * @param errors
     * @return
     */
    @RequestMapping(value = {"/update"}, method = RequestMethod.GET)
    public @ResponseBody
    BaseResponse updateGet(HttpServletRequest request,
                           @Valid BaseIdForm form, BindingResult errors){

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }

        MHotGoods mHotGoods = hotGoodsService.load(form.getId());
        //List<MHotGoods> mWxAdsPositions = hotGoodsService.selectAdsPostionList();

        Map<String, Object> data = new HashMap<String, Object>();
        data.put("mHotGoods", mHotGoods);

        return sendAjaxOK(data);
    }

    /**
     * 更新热销商品
     * @param request
     * @param form
     * @param errors
     * @return
     */
    @RequestMapping(value = {"/update"}, method = RequestMethod.POST)
    public @ResponseBody
    BaseResponse update(HttpServletRequest request,
                        @RequestBody @Valid HotGoodsFormAdd form, BindingResult errors){

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }

        hotGoodsService.update(form);

        return sendAjaxOK();
    }

    /**
     * 删除热销商品
     * @param request
     * @param form
     * @param errors
     * @return
     */
    @RequestMapping(value = {"/delete"}, method = RequestMethod.GET)
    public @ResponseBody
    BaseResponse delete(HttpServletRequest request,
                        @Valid BaseIdForm form, BindingResult errors){

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }

        hotGoodsService.delete(form.getId());

        return sendAjaxOK();
    }

    /**
     * 批量删除热销商品
     * @param request
     * @param form
     * @param errors
     * @return
     */
    @RequestMapping(value = {"/deletes"}, method = RequestMethod.POST)
    public @ResponseBody BaseResponse dels(HttpServletRequest request,
                                           @RequestBody @Valid BaseIdsForm form, BindingResult errors){
        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }
        hotGoodsService.delete(form);
        return sendAjaxOK();
    }

    @RequestMapping(value = {"/open"}, method = RequestMethod.GET)
    public @ResponseBody
    BaseResponse open(HttpServletRequest request,
                         @Valid BaseIdForm form, BindingResult errors){

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }

        hotGoodsService.open(form.getId());

        return sendAjaxOK();
    }

    /**
     * 保存热销商品
     * @param request
     * @param form
     * @param errors
     * @return
     */
    @RequestMapping(value = {"/sequenceUpdate"}, method = RequestMethod.POST)
    public @ResponseBody
    BaseResponse updateSequence(HttpServletRequest request,
                      @RequestBody @Valid HotGoodsUpdateSqForm form, BindingResult errors){

        if (errors.hasErrors()){
            return sendAjaxError(errors.getFieldErrors());
        }
        hotGoodsService.updateSequence(form);

        return sendAjaxOK();
    }

}
