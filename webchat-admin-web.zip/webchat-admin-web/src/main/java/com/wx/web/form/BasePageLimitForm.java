package com.wx.web.form;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class BasePageLimitForm implements java.io.Serializable{

	private static final long serialVersionUID = -2938904301029087775L;

	/**
	 * 起始位置
	 */
	@NotNull
	private Integer pageNo;
	
	/**
	 * 分页容量
	 */
	@NotNull
	private Integer pageSize;
	

	public BasePageLimitForm() {
	}


	public Integer getPageNo() {
		if(pageNo <= 0)
			this.pageNo = 1;
		return pageNo;
	}


	public void setPageNo(Integer pageNo) {
		if(pageNo <= 0)
			this.pageNo = 1;
		this.pageNo = pageNo;
	}


	public Integer getPageSize() {
		return pageSize;
	}


	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	
}
