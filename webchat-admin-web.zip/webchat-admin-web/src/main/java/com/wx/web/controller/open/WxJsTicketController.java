package com.wx.web.controller.open;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import com.fasterxml.jackson.databind.util.JSONPObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wechat.exception.WxErrorException;
import com.wechat.exception.WxNetException;
import com.wx.domain.WxConfig;
import com.wx.domain.WxJsTicket;
import com.wx.exception.ServiceErrorException;
import com.wx.service.WxJsTicketService;
import com.wx.service.WxConfigService;
import com.wx.util.CommonUtil;
import com.wx.web.controller.BaseController;
import com.wx.web.form.WxJsConfigGet;
import com.wx.web.mv.BaseResponse;

/**
 * 微信页面js初始化参数 contoller
 * @author jiahuijie
 *
 */
@Controller("fWxJsConfigController")
public class WxJsTicketController extends BaseController{

	@Autowired
	private WxJsTicketService fWxJsTicketService;
	
	@Autowired
	private WxConfigService wxConfigService;
	
	/**
	 * 获取参数
	 * @param request
	 * @return
	 * @throws WxNetException 
	 * @throws WxErrorException 
	 * @throws ServiceErrorException 
	 */
	@RequestMapping(value = {"/wxJsConfig"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse wxJsConfig(HttpServletRequest request,
			@Valid WxJsConfigGet form, BindingResult errors) throws ServiceErrorException, WxErrorException, WxNetException {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}
		
		Map<String, Object> data = new HashMap<String, Object>();
		
		WxConfig wxConfig = wxConfigService.getConfig();
		WxJsTicket ticket = fWxJsTicketService.getJsTicket();
		
		String jsapi_ticket = ticket.getTicket();
		Long timestamp = new Date().getTime() / 1000;
		String noncestr = CommonUtil.produceValCode(6);
		
		//1.字典排序
		//jsapi_ticket noncestr timestamp url
		
		//2. 将参数字符串拼接成一个字符串进行sha1加密
		StringBuffer signatureBuffer = new StringBuffer();
		signatureBuffer.append("jsapi_ticket=").append(jsapi_ticket);
		signatureBuffer.append("&noncestr=").append(noncestr);
		signatureBuffer.append("&timestamp=").append(timestamp);
		signatureBuffer.append("&url=").append(form.getUrl());
		
		//3. 签名加密
		String signature = CommonUtil.SHA1(signatureBuffer.toString());
		
		data.put("timestamp", timestamp);
		data.put("nonceStr", noncestr);
		data.put("appId", wxConfig.getAppid());
		data.put("signature", signature);
		
		return sendAjaxOK("wxJsConfig", data);
	}


	/**
	 * 获取参数jsonp
	 * @param request
	 * @return
	 * @throws WxNetException
	 * @throws WxErrorException
	 * @throws ServiceErrorException
	 */
	@RequestMapping(value = {"/wxJsConfig/jsonp"})
	@ResponseBody
	public JSONPObject wxJsConfigJsonP(HttpServletRequest request, String callback,
													  @Valid WxJsConfigGet form, BindingResult errors) throws ServiceErrorException, WxErrorException, WxNetException {

		if (errors.hasErrors()){
			return new JSONPObject(callback,sendAjaxError(errors.getFieldError()));
		}

		Map<String, Object> data = new HashMap<String, Object>();

		WxConfig wxConfig = wxConfigService.getConfig();
		WxJsTicket ticket = fWxJsTicketService.getJsTicket();

		String jsapi_ticket = ticket.getTicket();
		Long timestamp = new Date().getTime() / 1000;
		String noncestr = CommonUtil.produceValCode(6);

		//1.字典排序
		//jsapi_ticket noncestr timestamp url

		//2. 将参数字符串拼接成一个字符串进行sha1加密
		StringBuffer signatureBuffer = new StringBuffer();
		signatureBuffer.append("jsapi_ticket=").append(jsapi_ticket);
		signatureBuffer.append("&noncestr=").append(noncestr);
		signatureBuffer.append("&timestamp=").append(timestamp);
		signatureBuffer.append("&url=").append(form.getUrl());

		//3. 签名加密
		String signature = CommonUtil.SHA1(signatureBuffer.toString());

		data.put("timestamp", timestamp);
		data.put("nonceStr", noncestr);
		data.put("appId", wxConfig.getAppid());
		data.put("signature", signature);

		return new JSONPObject(callback, sendAjaxOK("wxJsConfig", data));
	}
}
