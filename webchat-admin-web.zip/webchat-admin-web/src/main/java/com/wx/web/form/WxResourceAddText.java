package com.wx.web.form;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 添加文本资源form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class WxResourceAddText implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;

	/**
	 * 文本资源
	 */
	@NotBlank
	@Length(min = 1, max = 350)
	private String content;
	
	/**
	 * 默认构造方法
	 */
	public WxResourceAddText() {
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
