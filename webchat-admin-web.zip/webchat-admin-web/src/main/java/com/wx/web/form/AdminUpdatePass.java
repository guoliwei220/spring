package com.wx.web.form;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 管理员修改密码
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class AdminUpdatePass implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;

	/**
	 * 用户名
	 */
	@Length(max=20)
	@NotBlank
	private String oldPassword;
	
	/**
	 * 新密码
	 */
	@Length(max=20)
	@NotBlank
	private String newPassword;
	
	/**
	 * 重复密码
	 */
	@Length(max=20)
	@NotBlank
	private String rePassword;
	
	
	/**
	 * 默认构造方法
	 */
	public AdminUpdatePass() {
	}


	public String getOldPassword() {
		return oldPassword;
	}


	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}


	public String getNewPassword() {
		return newPassword;
	}


	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}


	public String getRePassword() {
		return rePassword;
	}


	public void setRePassword(String rePassword) {
		this.rePassword = rePassword;
	}
	
}
