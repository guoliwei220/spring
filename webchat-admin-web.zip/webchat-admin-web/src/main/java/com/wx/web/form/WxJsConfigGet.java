package com.wx.web.form;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 获取wx_js_config
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class WxJsConfigGet implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;

	/**
	 * 当前url
	 */
	@NotBlank
	private String url;
	
	
	/**
	 * 默认构造方法
	 */
	public WxJsConfigGet() {
	}


	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}
	
}
