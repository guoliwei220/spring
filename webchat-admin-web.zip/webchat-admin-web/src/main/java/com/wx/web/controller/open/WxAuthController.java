package com.wx.web.controller.open;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import com.wx.domain.WxAuth;
import com.wx.service.WxAuthService;
import com.wx.util.CommonUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.wechat.exception.WxErrorException;
import com.wechat.exception.WxNetException;
import com.wechat.service.WeChatService;
import com.wechat.wsdata.WebChatOauth2Token;
import com.wechat.wsdata.WebChatUserInfo;
import com.wx.domain.WxConfig;
import com.wx.domain.WxUser;
import com.wx.service.WxConfigService;
import com.wx.service.WxUserService;
import com.wx.web.controller.BaseController;
import com.wx.web.form.open.WxAuthForm;
import com.wx.web.form.open.WxAuthInfoForm;

/**
 * 微信授权管理contoller
 * @author jiahuijie
 *
 */
@Controller("openWxAuthController")
public class WxAuthController extends BaseController{

	private static final Logger log = LoggerFactory.getLogger(WxAuthController.class);
	
	@Autowired
	private WxConfigService wxConfigService;
	
	@Autowired
	private WxUserService wxUserService;

	@Autowired
	private WxAuthService wxAuthService;
	
	@RequestMapping(value="/auth", method=RequestMethod.GET)
	public ModelAndView auth(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			@Valid WxAuthForm form, BindingResult errors) throws UnsupportedEncodingException, WxErrorException, WxNetException {
		
		if (errors.hasErrors()){
			return buildMVError(sendAjaxError(errors.getFieldError()));
		}
		
		String callback_uri = form.getCallback_uri();
		String appid = form.getAppid();
		String code = form.getCode();

		if (StringUtils.isBlank(code) && (StringUtils.isBlank(appid) || StringUtils.isBlank(callback_uri))){
			return buildMVOK("error");
		} else {
			String state = form.getState();

			if (!StringUtils.isBlank(code)){
				if (StringUtils.isBlank(code) && !StringUtils.isBlank(state)){ //跳转未授权页面
					return buildMVOK("unauth");
				}
			} else {
				WxAuth wxAuth = wxAuthService.loadByAppId(appid);

				if (wxAuth == null){
					return buildMVOK("error");
				}

				String baseURI = request.getRequestURI();
				String basePath = request.getScheme()+"://"+request.getServerName()+baseURI;
				String curl = basePath + "?callback_uri=";

				StringBuffer sb = new StringBuffer();
				sb.append(callback_uri);

				if (callback_uri.indexOf("?") <= 0){
					sb.append("?");
				} else {
					sb.append("&");
				}

				String appsecret = wxAuth.getSecret();
				String timestamp = String.valueOf(new Date().getTime());
				String nonce = CommonUtil.getRandomStr(6);

				String signature = null;

				//SHA1加密
				//1. 将secrect、timestamp、nonce三个参数进行字典序排序
				List<String> list = new ArrayList<String>();
				list.add(appsecret);
				list.add(timestamp);
				list.add(nonce);
				Collections.sort(list);

				//2. 将三个参数字符串拼接成一个字符串进行sha1加密
				StringBuffer signatureBuffer = new StringBuffer();
				for (String str : list){
					signatureBuffer.append(str);
				}

				//3. 签名加密
				signature = CommonUtil.SHA1(signatureBuffer.toString());

				sb.append("timestamp=").append(timestamp);
				sb.append("&nonce=").append(nonce);
				sb.append("&signature=").append(signature);

				curl = curl + URLEncoder.encode(sb.toString(),"UTF-8");

				return buildMVOK("redirect:" + getUrl(curl), sendAjaxOK());
			}


		}
		
		WxConfig wxConfig = wxConfigService.getConfig();
		WebChatOauth2Token wtokent = WeChatService.getAcctokenByCode(code, wxConfig.getAppid(), wxConfig.getAppsecret());
		
		WxUser user = wxUserService.findByOpenId(wtokent.getOpenId());

		WebChatUserInfo wuser = WeChatService.getUserInfoByPage(wtokent.getAccessToken(), wtokent.getOpenId());

		if (user == null) {
			user = new WxUser();
			user.setCity(wuser.getCity());
			user.setCountry(wuser.getCountry());
			user.setImgshow(wuser.getHeadImgUrl());
			user.setNickname(wuser.getNickname());
			user.setOpenid(wuser.getOpenId());
			user.setProvince(wuser.getProvince());
			user.setIsAttention(false);
			if (wuser.getSex() == 0){
				user.setSex(null);
			} else if (wuser.getSex() == 1){
				user.setSex(true);
			} else if (wuser.getSex() == 2){
				user.setSex(false);
			}
			wxUserService.createUser(user);
		} else if (wuser.getHeadImgUrl() != null && !wuser.getHeadImgUrl().equals(user.getImgshow())){
			wxUserService.updateImgshow(user.getOpenid(), user.getImgshow());
			user.setImgshow(wuser.getHeadImgUrl());
		}
		
		StringBuffer sb = new StringBuffer();
		sb.append("redirect:");
		sb.append(callback_uri);
		
		if (callback_uri.indexOf("?") <= 0){
			sb.append("?");
		} else {
			sb.append("&");
		}

		sb.append("nickname=").append(URLEncoder.encode(user.getNickname(), "UTF-8"));
		sb.append("&openId=").append(user.getOpenid());
		sb.append("&imgshow=").append(URLEncoder.encode(user.getImgshow(), "UTF-8"));
		sb.append("&sex=").append(user.getSex());
		sb.append("&isAttention=").append(user.getIsAttention());
		
		log.debug(sb.toString());
		
		return buildMVOK(sb.toString());
	}
	
	
	
	@RequestMapping(value="/authInfo", method=RequestMethod.GET)
	public @ResponseBody JSONPObject authInfo(String callbackFunc,
			@Valid WxAuthInfoForm form, BindingResult errors) {
		
		if (errors.hasErrors()){
			return null;
		}

		WxUser user = wxUserService.findByOpenId(form.getOpenId());
		
		return new JSONPObject(callbackFunc, sendAjaxOK("userInfo", user));
	}
	
	
	
	
	/**
	 * 组装跳转url
	 * @param callbackUrl
	 * @param callbackUrl
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public String getUrl(String callbackUrl) throws UnsupportedEncodingException {
		WxConfig wxConfig = wxConfigService.getConfig();
		
		StringBuffer url = new StringBuffer();
		url.append("https://open.weixin.qq.com/connect/oauth2/authorize?appid=");
		url.append(wxConfig.getAppid());
		url.append("&redirect_uri=");
		url.append(URLEncoder.encode(callbackUrl, "UTF-8"));
		url.append("&response_type=code&scope=");
		url.append("snsapi_userinfo");
		url.append("&state=");
		url.append("1");
		url.append("#wechat_redirect");
		return url.toString();
	}

}
