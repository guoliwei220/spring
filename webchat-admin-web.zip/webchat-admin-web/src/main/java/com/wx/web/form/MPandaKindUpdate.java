package com.wx.web.form;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 添加微信菜单form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class MPandaKindUpdate extends BaseIdForm implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;

	/**
	 * 菜单名称
	 */
	@NotBlank
	@Length(min = 1, max = 15)
	private String name;

	/**
	 * 类别描述
	 */
	@NotBlank
	@Length(max=250)
	private String title;

	/**
	 * 父角色ID

	 */
	private Long parentId;
	
	/**
	 * 默认构造方法
	 */
	public MPandaKindUpdate() {
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

}
