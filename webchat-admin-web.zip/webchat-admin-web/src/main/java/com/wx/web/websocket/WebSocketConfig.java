package com.wx.web.websocket;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;


/**
 * websocket配置类
 * @author jiahuijie
 *
 */
@Configuration
@EnableWebMvc
@EnableWebSocket
public class WebSocketConfig extends WebMvcConfigurerAdapter implements WebSocketConfigurer{

	 	@Override
	    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
	        registry.addHandler(wxScanLoginHandler(), "/wxScanLogin").addInterceptors(new WxScanLoginWebSocketInterceptor());
	        registry.addHandler(wxScanLoginHandler(), "/sockjs/wxScanLogin").addInterceptors(new WxScanLoginWebSocketInterceptor()).withSockJS();
	 	}

	    @Bean
	    public WxScanLoginHandler wxScanLoginHandler() {
	        return new WxScanLoginHandler();
	    }
}
