package com.wx.web.form;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseKindIdForm implements java.io.Serializable{

	private static final long serialVersionUID = 1629285276895610969L;
	
	/**
	 * 节点ID
	 */
	@NotNull
	private Long kindId;
	
	public BaseKindIdForm() {
	}

	public Long getKindId() {
		return kindId;
	}

	public void setKindId(Long kindId) {
		this.kindId = kindId;
	}
}
