package com.wx.web.form;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;

/**
 * Created by jh on 2015/11/27.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class HotGoodsFormAdd implements java.io.Serializable{

    @NotNull(message = "图片路径不能为空")
    @NotBlank(message = "图片路径不能为空")
    private String image;

    @NotNull
    @NotBlank
    private String goodsId;

    @NotNull(message = "权重不能为空")
    private Integer sequence;

    @NotNull(message = "商品标题")
    private String goodsTitle;

    @NotNull
    @NotBlank
    private String isOpen;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(String goodsId) {
        this.goodsId = goodsId;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public String getGoodsTitle() {
        return goodsTitle;
    }

    public void setGoodsTitle(String goodsTitle) {
        this.goodsTitle = goodsTitle;
    }

    public String getIsOpen() {
        return isOpen;
    }

    public void setIsOpen(String isOpen) {
        this.isOpen = isOpen;
    }
}
