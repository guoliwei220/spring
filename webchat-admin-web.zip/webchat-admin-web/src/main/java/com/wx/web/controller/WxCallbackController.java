package com.wx.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wx.domain.WxCallback;
import com.wx.service.WxCallbackService;
import com.wx.web.form.WxCallbackAdd;
import com.wx.web.form.WxCallbackDel;
import com.wx.web.mv.BaseResponse;

/**
 * 自动回复contoller
 * @author jiahuijie
 *
 */
@Controller
@RequestMapping("/manager/wxcallback")
public class WxCallbackController extends BaseController{

	@Autowired
	private WxCallbackService wxCallbackService;
	
	/**
	 * 添加回复
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/add"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse addText(HttpServletRequest request,
			@Valid @RequestBody WxCallbackAdd form, BindingResult errors) {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}
		
		WxCallback wxCallback = new WxCallback();
		wxCallback.setResourceId(form.getResourceId());
		wxCallback.setResourceType(form.getResourceType());
		wxCallback.setScene(form.getScene());
		wxCallback.setId(form.getId());
		wxCallback.setName(form.getName());
		
		StringBuffer words = new StringBuffer();
		if (form.getWords() != null){
			for (String word : form.getWords()){
				words.append(word);
				words.append(" ");
			}
			if (words.length() > 0){
				words.deleteCharAt(words.length() - 1);
			}
			wxCallback.setWords(words.toString());
		}
		
		wxCallbackService.add(wxCallback);
		
		return sendAjaxOK("id", wxCallback.getId());
	}
	
	
	/**
	 * 删除回复
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/del"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse addText(HttpServletRequest request,
			@Valid @RequestBody WxCallbackDel form, BindingResult errors) {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}
		
		if (form.getScene().equals(WxCallback.SCENE_SUBSCRIBE) || form.getScene().equals(WxCallback.SCENE_CALLBACK)){
			wxCallbackService.removeByScene(form.getScene());
		} else {
			wxCallbackService.removeById(form.getId());
		}
		
		return sendAjaxOK();
	}
	
	
	
	
	/**
	 * 关键词回复
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/listForWords"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse listForWords(HttpServletRequest request) {
		List<WxCallback> wxCallbacks = wxCallbackService.listForWords();
		return sendAjaxOK("wxCallbacks",wxCallbacks);
	}
}
