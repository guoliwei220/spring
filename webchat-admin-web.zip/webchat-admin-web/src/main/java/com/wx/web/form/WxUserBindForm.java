package com.wx.web.form;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 设置微信参数form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class WxUserBindForm implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;


	/**
	 * 应用密钥 
	 */
	@NotBlank
	private String phonenum;
	
	
	/**
	 * 默认构造方法
	 */
	public WxUserBindForm() {
	}



	public String getPhonenum() {
		return phonenum;
	}


	public void setPhonenum(String phonenum) {
		this.phonenum = phonenum;
	}
	
}
