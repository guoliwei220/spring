package com.wx.web.form;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.validation.constraints.NotNull;

/**
 * Created by jh on 2015/11/25.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MWxAdsFormDel implements java.io.Serializable {

    @NotNull
    private  Long id ;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
