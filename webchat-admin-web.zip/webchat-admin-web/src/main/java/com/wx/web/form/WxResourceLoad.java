package com.wx.web.form;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 加载资源form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class WxResourceLoad implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;

	/**
	 * 回复场景
	 */
	private String scene;
	
	/**
	 * 按钮key
	 */
	private String btnKey;
	
	/**
	 * 父角色ID
	 */
	private Long id;
	
	/**
	 * 资源类型
	 */
	private String type;
	
	/**
	 * 默认构造方法
	 */
	public WxResourceLoad() {
	}
	
	public String getScene() {
		return scene;
	}
	
	public void setScene(String scene) {
		this.scene = scene;
	}
	
	public String getBtnKey() {
		return btnKey;
	}
	
	public void setBtnKey(String btnKey) {
		this.btnKey = btnKey;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
