package com.wx.web.form;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseIdsForm implements java.io.Serializable{

	private static final long serialVersionUID = 4270255520547474166L;
	
	/**
	 * 节点ID
	 */
	@NotNull
	private List<Long> ids;
	
	public BaseIdsForm() {
	}

	public List<Long> getIds() {
		return ids;
	}
	
	public void setIds(List<Long> ids) {
		this.ids = ids;
	}
}
