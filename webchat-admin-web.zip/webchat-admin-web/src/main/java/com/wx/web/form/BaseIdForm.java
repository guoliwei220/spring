package com.wx.web.form;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseIdForm implements java.io.Serializable{

	private static final long serialVersionUID = 4270255520547474166L;
	
	/**
	 * 节点ID
	 */
	@NotNull
	private Long id;
	
	public BaseIdForm() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
