package com.wx.web.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.wx.config.Config;
import com.wx.config.Constants;
import com.wx.util.CommonUtil;
import com.wx.vo.PageListData;
import com.wx.web.form.BasePageLimitForm;
import com.wx.web.mv.BaseResponse;

/**
 * 上传
 * @author Administrator
 *
 */
@Controller
@RequestMapping("/manager")
public class UploadFileController extends BaseController{
	
	
	/**
	 * cms图片上传
	 * @param request
	 * @param session
	 * @param file
	 * @return
	 */
	@RequestMapping(value = {"/cms/uploadImg"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse uploadImg(HttpServletRequest request, HttpSession session,
			@RequestParam MultipartFile file) {
		
		if (file == null){
			return sendAjaxError("上传文件不能为空");
		}
		
		String relativePath = Config.getStringValue(Constants.KEY_FILE_UPLOAD_BASE_DIR) + Config.getStringValue(Constants.CMS_DIR);
		String realPath = session.getServletContext().getRealPath(relativePath);
		
		try {
			String fileName = CommonUtil.getRandomFileName();
			String fileTypeName = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
			FileUtils.copyInputStreamToFile(file.getInputStream(), new File(realPath, fileName + fileTypeName));
			return sendAjaxOK("imgUrl",  relativePath.replaceAll("/", "_") + fileName + fileTypeName);
		} catch (IOException e) {
			return sendAjaxError("上传失败");
		}
	}
	
	
	/**
	 * cms文件上传
	 * @param request
	 * @param session
	 * @param file
	 * @return
	 */
	@RequestMapping(value = {"/cms/uploadFile"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse uploadFile(HttpServletRequest request, HttpSession session,
			@RequestParam MultipartFile file) {
		
		if (file == null){
			return sendAjaxError("上传文件不能为空");
		}
		
		String relativePath = Config.getStringValue(Constants.KEY_FILE_UPLOAD_BASE_DIR) + Config.getStringValue(Constants.CMS_DIR);
		String realPath = session.getServletContext().getRealPath(relativePath);
		
		try {
			String fileName = CommonUtil.getRandomFileName();
			String fileTypeName = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf("."));
			FileUtils.copyInputStreamToFile(file.getInputStream(), new File(realPath, fileName + fileTypeName));
			return sendAjaxOK("file",  relativePath + fileName + fileTypeName);
		} catch (IOException e) {
			return sendAjaxError("上传失败");
		}
	}
	
	
	/**
	 * cms图片列表
	 * @param request
	 * @param session
	 * @param file
	 * @return
	 */
	@RequestMapping(value = {"/cms/imgList"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse imgList(HttpServletRequest request, HttpSession session,
			@Valid BasePageLimitForm form, BindingResult errors) {
		
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		
		String relativePath = Config.getStringValue(Constants.KEY_FILE_UPLOAD_BASE_DIR) + Config.getStringValue(Constants.CMS_DIR);
		String realPath = session.getServletContext().getRealPath(relativePath);
		
		int pageNo = form.getPageNo();
		int pageSize = form.getPageSize();
		
		File cmsFile = new File(realPath);
		if (!cmsFile.exists()){
			return sendAjaxError();
		}
		
		
		String[] fileNames = cmsFile.list();
		
		
		PageListData<String> data = new PageListData<String>();
		List<String> fileData = new ArrayList<String>();
		data.setList(fileData);
		data.setCountAll(fileNames.length);
		
		for (int i = (pageNo - 1) * pageSize; i < fileNames.length; i++){
			fileData.add(relativePath.replaceAll("/", "_") + fileNames[i]);
		}
		
		return sendAjaxOK(data);
	}
	
	
	
	/**
	 * ckeditor上传
	 * @param request
	 * @param session
	 * @param file
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping(value = {"/ckeditor/upload"}, method = RequestMethod.POST)
	public void ckeditorUpload(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			@RequestParam MultipartFile upload) throws IOException {
		
		response.setCharacterEncoding("GBK");  
        PrintWriter out = response.getWriter();  
  
        // CKEditor提交的很重要的一个参数  
        String callback = request.getParameter("CKEditorFuncNum");
  
        String expandedName = ""; // 文件扩展名  
        if (upload.getContentType().equals("image/pjpeg") || upload.getContentType().equals("image/jpeg")) {
            // IE6上传jpg图片的headimageContentType是image/pjpeg，而IE9以及火狐上传的jpg图片是image/jpeg  
            expandedName = ".jpg";  
        } else if (upload.getContentType().equals("image/png") || upload.getContentType().equals("image/x-png")) {  
            // IE6上传的png图片的headimageContentType是"image/x-png"  
            expandedName = ".png";  
        } else if (upload.getContentType().equals("image/gif")) {  
            expandedName = ".gif";  
        } else if (upload.getContentType().equals("image/bmp")) {  
            expandedName = ".bmp";  
        } else {  
            out.println("<script type=\"text/javascript\">");  
            out.println("window.parent.CKEDITOR.tools.callFunction(" + callback  
                    + ",'','文件格式不正确（必须为.jpg/.gif/.bmp/.png文件）');");  
            out.println("</script>");  
            return;
        }  
  
        if (upload.getSize() > 600 * 1024) {
            out.println("<script type=\"text/javascript\">");  
            out.println("window.parent.CKEDITOR.tools.callFunction(" + callback  
                    + ",''," + "'文件大小不得大于600k');");  
            out.println("</script>");  
            return;  
        }
        
		String relativePath = Config.getStringValue(Constants.KEY_FILE_UPLOAD_BASE_DIR) + Config.getStringValue(Constants.CMS_DIR);
		String realPath = session.getServletContext().getRealPath(relativePath);
		
		try {
			String fileName = CommonUtil.getRandomFileName();
			String fileTypeName = expandedName;
			FileUtils.copyInputStreamToFile(upload.getInputStream(), new File(realPath, fileName + fileTypeName));
			out.println("<script type=\"text/javascript\">");  
	        out.println("window.parent.CKEDITOR.tools.callFunction(" + callback  
	                + ",'" + Config.getStringValue(Constants.KEY_IMG_SERVER) + relativePath.replaceAll("/", "_") + fileName + fileTypeName + "','')"); // 相对路径用于显示图片  
	        out.println("</script>");
		} catch (IOException e) {
			out.println("<script type=\"text/javascript\">");  
	        out.println("window.parent.CKEDITOR.tools.callFunction(" + callback  
	                + ",'','文件上传失败')");  
	        out.println("</script>");
		}
		
	}
}
