package com.wx.web.controller.open;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.wechat.exception.WxErrorException;
import com.wechat.exception.WxNetException;
import com.wx.domain.WxAccessToken;
import com.wx.domain.WxUser;
import com.wx.exception.ServiceErrorException;
import com.wx.service.WxAccessTokenService;
import com.wx.service.WxConfigService;
import com.wx.service.WxUserService;
import com.wx.web.controller.BaseController;
import com.wx.web.mv.BaseResponse;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

/**
 * 微信用户信息API contoller
 * @author jiahuijie
 *
 */
@Controller("fWxUserAPIController")
public class WxUserAPIController extends BaseController{

	@Autowired
	private WxUserService wxUserService;


	/**
	 * 获取用户是否关注jsonp
	 * @param request
	 * @return
	 * @throws WxNetException
	 * @throws WxErrorException
	 * @throws ServiceErrorException
	 */
	@RequestMapping(value = {"/userAttention/jsonp"})
	@ResponseBody
	public JSONPObject tokenConfigJsonP(HttpServletRequest request, String callback, String openId) throws ServiceErrorException, WxErrorException, WxNetException {

		if (StringUtils.isBlank(openId)){
			return 	new JSONPObject(callback, sendAjaxError("openId", "openId不能为空"));
		}

		WxUser wxUser = wxUserService.findByOpenId(openId);

		if (wxUser != null){
			if (wxUser.getIsAttention()){
				return new JSONPObject(callback, sendAjaxOK("isAttention", true));
			}
		}

		return new JSONPObject(callback, sendAjaxOK("isAttention", false));
	}
}
