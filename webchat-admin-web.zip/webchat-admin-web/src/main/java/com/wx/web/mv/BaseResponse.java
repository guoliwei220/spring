package com.wx.web.mv;

import java.util.HashMap;
import java.util.Map;


public class BaseResponse {

	/**
	 * 代码
	 */
	private String code;
	
	/**
	 * 消息
	 */
	private String msg;
	
	/**
	 * 响应数据
	 */
	private Map<String, Object> data = new HashMap<String,Object>();
	
	public BaseResponse(){
		
	}
	
	public BaseResponse(ResponseMessage em, String msg) {
		this.code = em.getCode();
		this.msg = msg;
	}
	
	public BaseResponse(ResponseMessage em) {
		this.code = em.getCode();
		this.msg = ResponseMessageConfig.getValue(em.getKey());
	}
	
	/**
	 * 设置Message
	 * @param jm
	 */
	public void setResponseMessage(ResponseMessage jm){
		this.code = jm.getCode();
		this.msg = ResponseMessageConfig.getValue(jm.getKey());
	}
	
	/**
	 * 增加响应数据
	 * @param key
	 * @param value
	 */
	public void pushData(String key, Object value){
		data.put(key, value);
	}
	

	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public Map<String, Object> getData() {
		return data;
	}

	public void setData(Map<String, Object> data) {
		this.data = data;
	}
}
