package com.wx.web.controller;

import com.wx.exception.ServiceErrorException;
import com.wx.mobileDomain.MPandaGoods;
import com.wx.mobileDomain.MPandaKind;
import com.wx.service.MPandaKindService;
import com.wx.service.MPandaGoodsService;
import com.wx.vo.PageListData;
import com.wx.vo.TreeNode;
import com.wx.web.form.*;
import com.wx.web.mv.BaseResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

/**
 * 地区contoller
 * @author jiahuijie
 *
 */
@Controller
@RequestMapping("/manager/panda")
public class MPandaController extends BaseController{

	@Autowired
	private MPandaKindService mPandaKindService;

	@Autowired
	private MPandaGoodsService mPandaGoodsService;

	/**
	 * 添加类别
	 * @param request
	 * @return
	 * @throws ServiceErrorException
	 */
	@RequestMapping(value = {"/kindAdd"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse addMenu(HttpServletRequest request, HttpSession session,
											  @Valid @RequestBody MPandaKindAdd form, BindingResult errors) throws ServiceErrorException {

		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}

		MPandaKind mPandaKind = new MPandaKind();
		mPandaKind.setName(form.getName());
		mPandaKind.setTitle(form.getTitle());
		mPandaKind.setParentId(form.getParentId());

		mPandaKindService.add(mPandaKind);

		TreeNode<MPandaKind> node = new TreeNode<MPandaKind>();
		node.setId(mPandaKind.getId());
		node.setData(mPandaKind);
		node.setLabel(mPandaKind.getName());
		node.setParentId(mPandaKind.getParentId());
		node.setRoot(false);
		node.setChildren(new ArrayList<TreeNode<MPandaKind>>());

		return sendAjaxOK("node", node);
	}



	/**
	 * 删除
	 * @param request
	 * @return
	 * @throws ServiceErrorException
	 */
	@RequestMapping(value = {"/kindDel"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse del(HttpServletRequest request,
										  @RequestBody @Valid BaseIdForm form, BindingResult errors) throws ServiceErrorException{
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}

		mPandaKindService.remove(form.getId());

		return sendAjaxOK();
	}


	/**
	 * 修改类别
	 * @param request
	 * @return
	 * @throws ServiceErrorException
	 */
	@RequestMapping(value = {"/kindUpdate"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse initUpdate(HttpServletRequest request, HttpSession session,
											 @Valid BaseIdForm form, BindingResult errors) throws ServiceErrorException {

		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}

		MPandaKind mPandaKind = mPandaKindService.load(form.getId());

		return sendAjaxOK("mPandaKind", mPandaKind);

	}


	/**
	 * 修改类别
	 * @param request
	 * @return
	 * @throws ServiceErrorException
	 */
	@RequestMapping(value = {"/kindUpdate"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse update(HttpServletRequest request, HttpSession session,
											 @Valid @RequestBody MPandaKindUpdate form, BindingResult errors) throws ServiceErrorException {

		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}

		MPandaKind mPandaKind = new MPandaKind();
		mPandaKind.setId(form.getId());
		mPandaKind.setName(form.getName());
		mPandaKind.setTitle(form.getTitle());
		mPandaKind.setParentId(form.getParentId());

		mPandaKindService.update(mPandaKind);

		TreeNode<MPandaKind> node = new TreeNode<MPandaKind>();
		node.setId(mPandaKind.getId());
		node.setData(mPandaKind);
		node.setLabel(mPandaKind.getName());
		node.setParentId(mPandaKind.getParentId());
		node.setRoot(false);

		return sendAjaxOK("node", node);
	}


	/**
	 * 加载类别
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/kindList"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse list(HttpServletRequest request, HttpSession session) {
		List<MPandaKind> menus = mPandaKindService.loadMenu();
		List<TreeNode<MPandaKind>> treeNodes = new ArrayList<TreeNode<MPandaKind>>();
		for (MPandaKind dlArea : menus){
			TreeNode<MPandaKind> node = new TreeNode<MPandaKind>();
			node.setId(dlArea.getId());
			node.setData(dlArea);
			node.setLabel(dlArea.getName());
			node.setParentId(dlArea.getParentId());
			node.setRoot(false);
			treeNodes.add(node);
		}
		return sendAjaxTree(treeNodes);
	}





	/**
	 * 添加熊猫币
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/goodsAdd"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse addNews(HttpServletRequest request,
											  @Valid @RequestBody MPandaGoodsAdd form, BindingResult errors) {
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}

		MPandaGoods pg = new MPandaGoods();
		pg.setGoodsId(form.getGoodsId());
		pg.setGoodsTitle(form.getGoodsTitle());
		pg.setKindId(form.getKindId());
		pg.setSequence(form.getSequence());
		pg.setShortDesc(form.getShortDesc());

		mPandaGoodsService.add(pg);

		return sendAjaxOK();
	}


	/**
	 * 初始化修改熊猫币
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/goodsUpdate"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse updateNewsGet(HttpServletRequest request,
													@Valid BaseIdForm form, BindingResult errors) {

		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}

		MPandaGoods mPandaGoods = mPandaGoodsService.loadById(form.getId());

		return sendAjaxOK("mPandaGoods", mPandaGoods);
	}



	/**
	 * 修改熊猫币
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/goodsUpdate"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse updateNewsPost(HttpServletRequest request,
													 @Valid @RequestBody MPandaGoodsUpdate form, BindingResult errors) {

		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}

		MPandaGoods pg = new MPandaGoods();
		pg.setId(form.getId());
		pg.setGoodsId(form.getGoodsId());
		pg.setGoodsTitle(form.getGoodsTitle());
		pg.setShortDesc(form.getShortDesc());
		pg.setKindId(form.getKindId());
		pg.setSequence(form.getSequence());

		mPandaGoodsService.update(pg);

		return sendAjaxOK();
	}


	/**
	 * 删除
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/goodsDel"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse goodsDel(HttpServletRequest request,
											  @RequestBody @Valid BaseIdForm form, BindingResult errors){
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		mPandaGoodsService.remove(form.getId());
		return sendAjaxOK();
	}

	/**
	 * 批量删除
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/goodsDels"}, method = RequestMethod.POST)
	public @ResponseBody BaseResponse goodsDels(HttpServletRequest request,
											   @RequestBody @Valid BaseIdsForm form, BindingResult errors){
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldErrors());
		}
		mPandaGoodsService.remove(form.getIds());
		return sendAjaxOK();
	}



	/**
	 * 分页加载
	 * @param request
	 * @return
	 */
	@RequestMapping(value = {"/goodsList"}, method = RequestMethod.GET)
	public @ResponseBody BaseResponse goodsList(HttpServletRequest request,
											   @Valid MPandaGoodsLimitForm form, BindingResult errors) {
		if (errors.hasErrors()){
			return sendAjaxError(errors.getFieldError());
		}

		PageListData<MPandaGoods> pd = mPandaGoodsService.list(form.getKindId(), form.getPageNo(), form.getPageSize());

		return sendAjaxOK(pd);
	}
}
