package com.wx.web.form;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 设置微信参数form
 * @author jiahuijie
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class WxConfigSet implements java.io.Serializable{

	private static final long serialVersionUID = -1021860167597666337L;

	/**
	 * 应用Id
	 */
	@NotBlank
	private String appKey;
	
	/**
	 * 应用密钥 
	 */
	@NotBlank
	private String appSecret;
	
	/**
	 * 令牌
	 */
	@NotBlank
	private String token;
	
	
	/**
	 * 默认构造方法
	 */
	public WxConfigSet() {
	}


	public String getAppKey() {
		return appKey;
	}


	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}


	public String getAppSecret() {
		return appSecret;
	}


	public void setAppSecret(String appSecret) {
		this.appSecret = appSecret;
	}


	public String getToken() {
		return token;
	}


	public void setToken(String token) {
		this.token = token;
	}

	
}
