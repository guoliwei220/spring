package com.wx.exception;

/**
 * 业务层处理异常
 * @author jiahuijie
 *
 */
public class ServiceErrorException extends RuntimeException {

	private static final long serialVersionUID = 7312060988977054762L;

	/**
	 * 错误信息
	 */
	private String msg;
	
	public ServiceErrorException(String msg) {
		this.msg = msg;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	
}
