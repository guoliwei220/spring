package com.wx.exception;

/**
 * 数据参数异常
 * @author jiahuijie
 *
 */
public class DataFiledErrorException extends RuntimeException {

	private static final long serialVersionUID = 7062590069416223906L;

	/**
	 * 参数列
	 */
	private String field;
	
	/**
	 * 错误信息
	 */
	private String msg;
	
	
	public DataFiledErrorException(String field, String msg) {
		this.field = field;
		this.msg = msg;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	
}
