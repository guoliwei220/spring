package com.wx.vo;

import java.util.List;

/**
 * 分类树节点
 * @author jiahuijie
 *
 */

public class TreeNode<T> {
	
	/**
	 * 节点id
	 */
	private Long id;

	/**
	 * 父节点ID。
	 */
	private Long parentId;
	
	/**
	 * 本节点标签上的文本。
	 */
	private String label;
	
	/**
	 * 是否是根
	 */
	private boolean root;

	/**
	 * 节点内容
	 */
	private T data;
	
	/**
	 * 子节点数组
	 */
	private List<TreeNode<T>> children;


	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public List<TreeNode<T>> getChildren() {
		return children;
	}

	public void setChildren(List<TreeNode<T>> children) {
		this.children = children;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
	public void setRoot(boolean root) {
		this.root = root;
	}
	
	public boolean isRoot() {
		return root;
	}
}
