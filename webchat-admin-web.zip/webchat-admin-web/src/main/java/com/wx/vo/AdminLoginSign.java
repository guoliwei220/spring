package com.wx.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * 管理员登陆标记
 * @author Administrator
 *
 */
public class AdminLoginSign implements Serializable{

	private static final long serialVersionUID = 5463204495508788145L;

	/**
	 * 用户ID
	 */
	private Long adminId;
	
	/**
	 * 昵称
	 */
	private String nickname;
	
	/**
	 * 用户名
	 */
	private String username;
	
	/**
	 * 头像
	 */
	private String imgshow;
	
	/**
	 * 登陆时间
	 */
	private Date lastLoginTime;
	
	/**
	 * 上次登录IP
	 */
	private String lastLoginIP;
	
	public AdminLoginSign() {
	}
	
	public String getNickname() {
		return nickname;
	}
	
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Date getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public Long getAdminId() {
		return adminId;
	}

	public void setAdminId(Long adminId) {
		this.adminId = adminId;
	}

	public String getLastLoginIP() {
		return lastLoginIP;
	}

	public void setLastLoginIP(String lastLoginIP) {
		this.lastLoginIP = lastLoginIP;
	}
	
	public String getImgshow() {
		return imgshow;
	}
	
	public void setImgshow(String imgshow) {
		this.imgshow = imgshow;
	}
}
