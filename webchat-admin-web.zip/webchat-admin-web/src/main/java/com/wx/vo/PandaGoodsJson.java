package com.wx.vo;

/**
 * 熊猫币商品Json对象
 *
 * @author liaoqiang
 * @create 2017-06-07 9:50
 */
public class PandaGoodsJson {
    Long kindId;
    String goodsId;
    String shortDesc;

    public PandaGoodsJson(Long kindId, String goodsId, String shortDesc) {
        this.kindId = kindId;
        this.goodsId = goodsId;
        this.shortDesc = shortDesc;
    }

    public Long getKindId() {
        return kindId;
    }

    public void setKindId(Long kindId) {
        this.kindId = kindId;
    }

    public String getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(String goodsId) {
        this.goodsId = goodsId;
    }

    public String getShortDesc() {
        return shortDesc;
    }

    public void setShortDesc(String shortDesc) {
        this.shortDesc = shortDesc;
    }
}
