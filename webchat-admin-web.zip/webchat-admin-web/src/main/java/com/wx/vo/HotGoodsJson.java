package com.wx.vo;

/**
 * 热销商品json对象
 *
 * @author liaoqiang
 * @create 2017-06-06 15:15
 */
public class HotGoodsJson {

    String id ;
    String image;
    String isOpen;

    public HotGoodsJson(String id, String image, String isOpen) {
        this.id = id;
        this.image = image;
        this.isOpen = isOpen;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getIsOpen() {
        return isOpen;
    }

    public void setIsOpen(String isOpen) {
        this.isOpen = isOpen;
    }
}
