package com.wx.vo;

import java.util.List;

/**
 * 分类树节点
 * @author jiahuijie
 *
 */

public class SimpleTreeNode {
	
	/**
	 * 节点id
	 */
	private Long id;

	/**
	 * 父节点ID。
	 */
	private Long parentId;
	
	/**
	 * 本节点标签上的文本。
	 */
	private String label;

	/**
	 * 是否是根
	 */
	private boolean root;
	
	/**
	 * 子节点数组
	 */
	private List<SimpleTreeNode> children;

	public SimpleTreeNode() {
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
	public boolean isRoot() {
		return root;
	}
	
	public void setRoot(boolean root) {
		this.root = root;
	}

	public List<SimpleTreeNode> getChildren() {
		return children;
	}

	public void setChildren(List<SimpleTreeNode> children) {
		this.children = children;
	}


	
}
