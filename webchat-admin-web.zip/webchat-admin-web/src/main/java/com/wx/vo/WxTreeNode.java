package com.wx.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * 微信树节点
 * @author jiahuijie
 *
 */
@JsonInclude(Include.NON_NULL)
public class WxTreeNode{
	
	/**
	 * 节点id
	 */
	@JsonIgnore
	private Long id;

	/**
	 * 父节点ID。
	 */
	@JsonIgnore
	private Long parentId;
	
	/**
	 * 是否是根
	 */
	@JsonIgnore
	private boolean root;
	
	/**
	 * 菜单名称
	 */
	private String name;
	
	/**
	 * 菜单类型
	 */
	private String type;
	
	/**
	 * 事件key
	 */
	private String key;
	
	/**
	 * 跳转url
	 */
	private String url;

	/**
	 * 子节点数组
	 */
	@JsonInclude(Include.NON_NULL)
	private List<WxTreeNode> sub_button;
	

	public WxTreeNode() {
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Long getParentId() {
		return parentId;
	}


	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	
	public boolean isRoot() {
		return root;
	}

	public void setRoot(boolean root) {
		this.root = root;
	}
	

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getType() {
		return type;
	}
	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public List<WxTreeNode> getSub_button() {
		return sub_button;
	}

	public void setSub_button(List<WxTreeNode> sub_button) {
		this.sub_button = sub_button;
	}
	
}
