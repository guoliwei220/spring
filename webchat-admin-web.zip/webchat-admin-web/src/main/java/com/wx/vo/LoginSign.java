package com.wx.vo;

import java.io.Serializable;

/**
 * 微信用户登陆标记
 * @author Administrator
 *
 */
public class LoginSign implements Serializable{

	private static final long serialVersionUID = 5463204495508788145L;

	/**
	 * 用户id
	 */
	private Long id;
	
	/**
	 * 用户标识
	 */
	private String openId;
	
	/**
	 * 用户昵称
	 */
	private String nickname;
	
	/**
	 * 用户头像链接
	 */
	private String headImgUrl;
	
	/**
	 * 审核状态
	 */
	private String state;
	
	/**
	 * 会员类型
	 */
	private String type;
	
	public LoginSign() {
	}
	
	public String getNickname() {
		return nickname;
	}
	
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	public String getHeadImgUrl() {
		return headImgUrl;
	}

	public void setHeadImgUrl(String headImgUrl) {
		this.headImgUrl = headImgUrl;
	}

	public String getState() {
		return state;
	}
	
	public void setState(String state) {
		this.state = state;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	
}
