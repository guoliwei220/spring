package com.wx.vo;

/**
 * ua参数
 * @author jiahuijie
 *
 */
public class UA {

	private String fromIP;
	
	private String toIP;
	
	private String deviceType;
	
	private String os;
	
	private String browerType;
	
	private String browser;
	
	public UA() {
	}

	public String getFromIP() {
		return fromIP;
	}

	public void setFromIP(String fromIP) {
		this.fromIP = fromIP;
	}

	public String getToIP() {
		return toIP;
	}

	public void setToIP(String toIP) {
		this.toIP = toIP;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getOs() {
		return os;
	}

	public void setOs(String os) {
		this.os = os;
	}

	public String getBrowerType() {
		return browerType;
	}

	public void setBrowerType(String browerType) {
		this.browerType = browerType;
	}

	public String getBrowser() {
		return browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}
}
