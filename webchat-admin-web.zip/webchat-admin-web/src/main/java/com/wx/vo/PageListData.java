package com.wx.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PageListData<T> implements Serializable{

	private static final long serialVersionUID = 6987301613445589238L;

	/**
	 * 统计总量
	 */
	private long countAll;
	
	/**
	 * 列表内容
	 */
	private List<T> list = new ArrayList<T>();

	public long getCountAll() {
		return countAll;
	}

	public void setCountAll(long countAll) {
		this.countAll = countAll;
	}

	public List<T> getList() {
		return list;
	}

	public void setList(List<T> list) {
		this.list = list;
	}
	
	
}
