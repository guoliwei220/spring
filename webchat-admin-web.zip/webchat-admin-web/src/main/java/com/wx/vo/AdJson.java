package com.wx.vo;

/**
 * 广告json对象
 *
 * @author liaoqiang
 * @create 2017-06-06 14:19
 */
public class AdJson {
    String link;
    String image;

    public AdJson(String link, String image) {
        this.link = link;
        this.image = image;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
