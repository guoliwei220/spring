package com.wx.vo;

/**
 * 熊猫币种类json对象
 *
 * @author liaoqiang
 * @create 2017-06-07 9:17
 */
public class PandaKindJson {
    String id ;
    String title;

    public PandaKindJson(String id, String title) {
        this.id = id;
        this.title = title;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
