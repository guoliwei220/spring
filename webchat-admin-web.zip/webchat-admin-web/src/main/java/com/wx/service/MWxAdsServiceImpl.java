package com.wx.service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.wx.config.Constants;
import com.wx.mobileDomain.MWxAds;
import com.wx.mobileDomain.MWxAdsExample;
import com.wx.mobileDomain.MWxAdsPosition;
import com.wx.mobileDomain.MWxAdsPositionExample;
import com.wx.mobileMapper.MWxAdsMapper;
import com.wx.mobileMapper.MWxAdsPositionMapper;
import com.wx.util.CommonUtil;
import com.wx.util.JedisUtil;
import com.wx.vo.AdJson;
import com.wx.vo.PageListData;
import com.wx.web.form.MWxAdsFormAdd;
import com.wx.web.form.MWxAdsFormDel;
import com.wx.web.form.MWxAdsFormUpdate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import redis.clients.jedis.Jedis;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by jiahuijie on 2015/11/25.
 */
@Service
public class MWxAdsServiceImpl implements MWxAdsService {

    private static Logger logger = LoggerFactory.getLogger(MWxAdsServiceImpl.class);

    @Autowired
    private MWxAdsMapper mWxAdsMapper;

    @Autowired
    private MWxAdsPositionMapper mWxAdsPositionMapper;

    @Override
    public List<MWxAdsPosition> selectAdsPostionList() {
        return mWxAdsPositionMapper.selectByExample(new MWxAdsPositionExample());
    }


    @Override
    public PageListData<Map<String,Object>> list(int pageNo, int pageSize) {

        Page<Map<String,Object>> page = PageHelper.startPage(pageNo, pageSize);
        mWxAdsMapper.getList();
        PageListData<Map<String,Object>> result = new PageListData<Map<String,Object>>();
        result.setList(page.getResult());
        result.setCountAll(page.getTotal());
        return result;
    }

    @Override
    public MWxAds load(Long id) {
        return mWxAdsMapper.selectByPrimaryKey(id);
    }

    @Override
    public void save(MWxAdsFormAdd form) {
        MWxAds ads = new MWxAds();
        ads.setImage(form.getImage());
        ads.setAdsPosition(form.getAdsPosition());
        ads.setCreateTime(new Date());
        ads.setLink(form.getLink());
        ads.setSequence(form.getSequence());
        ads.setTitle(form.getTitle());
        mWxAdsMapper.insert(ads);

        this.syncAdsToRedis();
    }

    @Override
    public void update(MWxAdsFormUpdate form) {
        MWxAds ads = load(form.getId());
        ads.setId(form.getId());
        ads.setImage(form.getImage());
        ads.setAdsPosition(form.getAdsPosition());
        ads.setTs(new Date());
        ads.setLink(form.getLink());
        ads.setSequence(form.getSequence());
        ads.setTitle(form.getTitle());
        mWxAdsMapper.updateByPrimaryKey(ads);

        this.syncAdsToRedis();

    }

    @Override
    public void delete(MWxAdsFormDel form) {
        mWxAdsMapper.deleteByPrimaryKey(form.getId());

        this.syncAdsToRedis();
    }

    @Override
    public void deletes(List<Long> ids) {
        MWxAdsExample mWxAdsExample = new MWxAdsExample();
        mWxAdsExample.or().andIdIn(ids);
        mWxAdsMapper.deleteByExample(mWxAdsExample);

        this.syncAdsToRedis();
    }

    /**
     * 同步广告信息至redis
     */
    private void syncAdsToRedis(){
        Jedis jedis = null;
        List<Map<String,Object>> orderedWxAds  = mWxAdsMapper.getOrderedList();
        try {
            jedis = JedisUtil.getInstance().getJedis(Constants.REDIS_DB_3);
            //删除原来的广告
            jedis.del(Constants.Key_HomePage_Ads_Slide);
            jedis.del(Constants.Key_HomePage_Ads_Normal);
            jedis.del(Constants.Key_PandaPage_Ads_Slide);
            jedis.del(Constants.Key_MemoryPage_Ads_Normal);
            jedis.del(Constants.Key_MemoryPage_Ads_Slide);

            for(Map<String,Object> map : orderedWxAds){

                String adPosition = map.get("adsPosition")!=null?map.get("adsPosition").toString():"";
                String image = map.get("image")!=null?map.get("image").toString():"";
                String link = map.get("link")!=null?map.get("link").toString():"";
                AdJson adJason = new AdJson(link,image);
                String adJson = CommonUtil.ObjectToJSON(adJason);

                //首页轮播
                if(Constants.Key_HomePage_AdsPosition_Slide.equals(adPosition)){
                    jedis.rpush(Constants.Key_HomePage_Ads_Slide, adJson);
                }
                //首页广告
                else if(Constants.Key_HomePage_AdsPosition_Normal.equals(adPosition)){
                    jedis.rpush(Constants.Key_HomePage_Ads_Normal, adJson);
                }
                //熊猫币频道页轮播
                else if(Constants.Key_PandaPage_AdsPosition_Slide.equals(adPosition)){
                    jedis.rpush(Constants.Key_PandaPage_Ads_Slide, adJson);
                }
                //纪念币频道广告
                else if(Constants.Key_MemoryPage_AdsPosition_Normal.equals(adPosition)){
                    jedis.rpush(Constants.Key_MemoryPage_Ads_Normal,adJson);
                }
                //纪念币轮播广告
                else if(Constants.Key_MemoryPage_AdsPosition_Slide.equals(adPosition)){
                    jedis.rpush(Constants.Key_MemoryPage_Ads_Slide,adJson);
                }else{
                    logger.info("广告位不存在:"+adPosition);
                }
            }
        } catch (Exception e) {
            logger.error("syncAdsToRedis方法同步广告信息至redis异常"+e.getMessage(),e);
        } finally {
            JedisUtil.getInstance().destroy(jedis);
        }

    }
}
