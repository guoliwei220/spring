package com.wx.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wx.domain.WxScanLogin;
import com.wx.domain.WxScanLoginExample;
import com.wx.domain.WxUser;
import com.wx.domain.WxUserExample;
import com.wx.exception.ServiceErrorException;
import com.wx.mapper.WxScanLoginMapper;
import com.wx.mapper.WxUserMapper;

/**
 * 微信扫码登陆实现
 * @author jiahuijie
 *
 */
@Service
public class WxScanLoginServiceImpl implements WxScanLoginService{

	@Autowired
	private WxScanLoginMapper wxScanLoginMapper;
	
	@Autowired
	private WxUserMapper wxUserMapper;

	@Autowired
	private RedisTemplate<String, Object> redisTemplate;

	@Transactional
	@Override
	public void createTicket(WxScanLogin wxScanLogin) {
		Date now = new Date();
		wxScanLogin.setCreateTime(now);
		wxScanLogin.setUpdateTime(now);
		wxScanLogin.setIsLogin(false);
		
		wxScanLoginMapper.insert(wxScanLogin);
	}
	
	@Transactional
	@Override
	public Map<String, Object> check(String ticket) throws ServiceErrorException {
		
		WxScanLogin wxScanLogin = (WxScanLogin)redisTemplate.opsForValue().get(ticket);
		
		if (wxScanLogin == null){
			throw new ServiceErrorException("二维码已过期");
		}
		
		Date now = new Date();
		if (wxScanLogin.getExpiresTime().getTime() <= now.getTime()){
			throw new ServiceErrorException("二维码已过期");
		}
		
		if (wxScanLogin.getOpenid() == null){
			return null;//尚未扫描
		}
		
		if (!wxScanLogin.getIsLogin()){
			WxUserExample wxUserExample = new WxUserExample();
			wxUserExample.or().andOpenidEqualTo(wxScanLogin.getOpenid());
			List<WxUser> users = wxUserMapper.selectByExample(wxUserExample);
			
			if (users.isEmpty()){
				throw new ServiceErrorException("用户信息不存在");
			}
			
			WxUser user = users.get(0);
			
			Map<String, Object> data = new HashMap<String,Object>();
			data.put("callbackurl", wxScanLogin.getCallbackurl());
			data.put("openid", wxScanLogin.getOpenid());
			data.put("nickname", user.getNickname());
			data.put("imgshow", user.getImgshow());

			redisTemplate.delete(wxScanLogin.getTicket());

			return data;
		}
		throw new ServiceErrorException("二维码无效");
	}

	@Transactional
	@Override
	public void scan(String openid, String ticket) throws ServiceErrorException {

		WxScanLogin wxScanLogin = (WxScanLogin)redisTemplate.opsForValue().get(ticket);

		if (wxScanLogin == null){
			throw new ServiceErrorException("二维码不存在");
		}
		
		if (wxScanLogin.getOpenid() == null){
			wxScanLogin.setTicket(ticket);
			wxScanLogin.setOpenid(openid);
			redisTemplate.opsForValue().set(ticket, wxScanLogin);
		}
	}
	
}
