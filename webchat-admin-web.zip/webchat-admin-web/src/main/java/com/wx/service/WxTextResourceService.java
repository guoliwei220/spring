package com.wx.service;

import com.wx.domain.WxResourceText;

/**
 * 微信文本资源接口
 * @author jiahuijie
 *
 */
public interface WxTextResourceService {

	/**
	 * 添加文本回复
	 * @param callback
	 * @param text
	 */
	public Long add(String text);
	
	/**
	 * 通过id加载
	 * @param id
	 * @return
	 */
	public WxResourceText loadById(Long id);
}
