package com.wx.service;

import com.wx.domain.WxCallback;
import com.wx.mobileDomain.MPandaKind;
import com.wx.exception.ServiceErrorException;

import java.util.List;

/**
 * 熊猫币频道
 * @author jiahuijie
 *
 */
public interface MPandaKindService {

	/**
	 * 添加菜单类别
	 * @param pandaKind
	 */
	public void add(MPandaKind pandaKind) throws ServiceErrorException;
	
	/**
	 * 删除菜单
	 * @param id
	 */
	void remove(Long id) throws ServiceErrorException;
	
	/**
	 * 修改菜单
	 * @param pandaKind
	 */
	void update(MPandaKind pandaKind) throws ServiceErrorException;
	
	/**
	 * 加载指定菜单信息
	 * @param id
	 * @return
	 */
	MPandaKind load(Long id);
	
	/**
	 * 加载所有菜单
	 * @return
	 */
	List<MPandaKind> loadMenu();
}
