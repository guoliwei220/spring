package com.wx.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wx.domain.WxConfig;
import com.wx.domain.WxConfigExample;
import com.wx.mapper.WxConfigMapper;

/**
 * 微信配置实现
 * @author jiahuijie
 *
 */
@Service
public class WxConfigServiceImpl implements WxConfigService{

	@Autowired
	private WxConfigMapper wxConfigMapper;
	
	@Override
	public WxConfig getConfig() {
		
		WxConfigExample wxConfigExample = new WxConfigExample();
		wxConfigExample.setLimitEnd(0);
		wxConfigExample.setLimitEnd(1);
		List<WxConfig> wxConfigs = wxConfigMapper.selectByExample(wxConfigExample);
		
		if (wxConfigs.isEmpty()){
			return null;
		}
		
		return wxConfigs.get(0);
	}

	@Transactional(rollbackFor=Exception.class)
	@Override
	public void setConfig(WxConfig wxConfig) {
		WxConfigExample wxConfigExample = new WxConfigExample();
		long count = wxConfigMapper.countByExample(wxConfigExample);
		if (count > 0){
			wxConfigMapper.updateByExampleSelective(wxConfig, wxConfigExample);
		} else {
			Date date = new Date();
			wxConfig.setCreateTime(date);
			wxConfig.setUpdateTime(date);
			wxConfigMapper.insert(wxConfig);
		}
	}
}
