package com.wx.service;

import java.io.IOException;

import com.wechat.exception.WxErrorException;
import com.wechat.exception.WxNetException;
import com.wx.domain.WxJsTicket;
import com.wx.exception.ServiceErrorException;

/**
 * 微信Token接口
 * @author jiahuijie
 *
 */
public interface WxJsTicketService {

	//token key 锁
	public static final String LOCK_JS_TOKEN_KEY = "lock_js_token_key";

	//token key
	public static final String JS_TOKEN_KEY = "js_token_key";

	/**
	 * 获取Token
	 * @return
	 * @throws ServiceErrorException
	 * @throws WxErrorException
	 * @throws WxNetException
	 * @throws IOException
	 */
	public WxJsTicket getJsTicket() throws ServiceErrorException, WxErrorException, WxNetException;

	/**
	 * 初始化
	 * @return
	 * @throws ServiceErrorException
	 */
	public void init() throws ServiceErrorException;
}
