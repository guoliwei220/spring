package com.wx.service;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import com.wx.util.SpringRedisLockUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import com.wechat.exception.WxErrorException;
import com.wechat.exception.WxNetException;
import com.wechat.service.WeChatService;
import com.wechat.wsdata.WebChatToken;
import com.wx.domain.WxAccessToken;
import com.wx.domain.WxAccessTokenExample;
import com.wx.domain.WxConfig;
import com.wx.exception.ServiceErrorException;
import com.wx.mapper.WxAccessTokenMapper;

/**
 * 微信Token实现
 * @author jiahuijie
 *
 */
@Service
public class WxAccessTokenServiceImpl implements WxAccessTokenService{

	@Autowired
	private WxAccessTokenMapper wxAccessTokenMapper;
	
	@Autowired
	private WxConfigService wxConfigService;

	@Autowired
	private RedisTemplate<String, Object> redisTemplate;
	
	@Override
	public WxAccessToken getAccessToken() throws ServiceErrorException, WxErrorException, WxNetException{

		WxAccessToken wxAccessToken = null;

		//判断token是否存在
		if(redisTemplate.hasKey(TOKEN_KEY)){
			wxAccessToken = (WxAccessToken) redisTemplate.opsForValue().get(TOKEN_KEY);
		} else {
			boolean lockSuc = false;
			try {
				if (SpringRedisLockUtil.lock(redisTemplate, LOCK_TOKEN_KEY, 10, TimeUnit.SECONDS)) { //启用锁
					//执行业务逻辑
					lockSuc = true;

					//加载微信参数配置
					WxConfig wxConfig = wxConfigService.getConfig();
					if (wxConfig == null){
						throw new ServiceErrorException("微信对接参数尚未配置");
					}

					WebChatToken webChatToken = WeChatService.createAccToken(wxConfig.getAppid(), wxConfig.getAppsecret());

					//插入token到数据库
					Date date = new Date();
					wxAccessToken = new WxAccessToken();
					wxAccessToken.setAccessToken(webChatToken.getAccessToken());
					wxAccessToken.setCreateTime(date);
					wxAccessToken.setExpiresIn(webChatToken.getExpiresIn());
					wxAccessToken.setUpdateTime(date);
					wxAccessTokenMapper.insert(wxAccessToken);

					redisTemplate.opsForValue().set(TOKEN_KEY, wxAccessToken, 6000,TimeUnit.SECONDS);
				} else {
					throw new ServiceErrorException("token生成失败");
				}
			} catch (ServiceErrorException e){
				throw e;
			} catch (Exception e) {
				// 分布式锁异常
				throw new ServiceErrorException("token生成同步锁异常");
			} finally {
				if(lockSuc)//加锁成功，解锁
					SpringRedisLockUtil.unlock(redisTemplate, LOCK_TOKEN_KEY);
			}
		}
		
		return wxAccessToken;
	}


	@Override
	public void init() throws ServiceErrorException {
		redisTemplate.delete(TOKEN_KEY);
	}
}
