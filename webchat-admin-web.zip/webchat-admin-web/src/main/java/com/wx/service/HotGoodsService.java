package com.wx.service;

import com.wx.ecShopDomain.EsGoods;
import com.wx.exception.ServiceErrorException;
import com.wx.mobileDomain.MHotGoods;
import com.wx.vo.PageListData;
import com.wx.web.form.BaseIdsForm;
import com.wx.web.form.HotGoodsFormAdd;
import com.wx.web.form.HotGoodsFormFind;
import com.wx.web.form.HotGoodsUpdateSqForm;

/**
 * Created by jh on 2015/11/27.
 */
public interface HotGoodsService {

    /**
     * 多条件查询商品
     * @param form
     * @return
     */
    PageListData<EsGoods> list(HotGoodsFormFind form);

    /**
     * 保存热销商品
     * @param form
     */
    void save(HotGoodsFormAdd form) throws ServiceErrorException;

    /**
     * 查询热销商品信息
     * @param id
     * @return
     */
    MHotGoods load(Long id);

    /**
     * 更新热销商品信息
     * @param form
     * @return
     */
    void update(HotGoodsFormAdd form);

    /**
     * 删除热销商品通过IDs
     * @param form
     * @return
     */
    void delete(BaseIdsForm form);

    /**
     * 删除热销商品通过IDs
     * @param id
     * @return
     */
     void delete(Long id);
    /**
     * 多条件查询热销商品
     * @param
     * @return
     */
    PageListData<MHotGoods> listHotGoods(Integer pageNo, Integer pageSize);
    /**
     * 修改热销商品状态
     * @param
     * @return
     */
    void open(Long id);
    /**
     * 修改热销商品权重
     * @param
     * @return
     */
    void updateSequence(HotGoodsUpdateSqForm form);
}
