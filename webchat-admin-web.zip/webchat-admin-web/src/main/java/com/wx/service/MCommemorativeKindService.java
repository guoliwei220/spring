package com.wx.service;

/**
 * Created by jh on 2016/1/5.
 */

import com.wx.exception.ServiceErrorException;
import com.wx.mobileDomain.MCommemorativeKind;

import java.util.List;

/**
 * 纪念币频道页
 */
public interface MCommemorativeKindService {
    /**
     * 添加菜单类别
     * @param mCommemorativeKind
     */
    public void add(MCommemorativeKind mCommemorativeKind) throws ServiceErrorException;

    /**
     * 删除菜单
     * @param id
     */
    void remove(Long id) throws ServiceErrorException;

    /**
     * 修改菜单
     * @param mCommemorativeKind
     */
    void update(MCommemorativeKind mCommemorativeKind) throws ServiceErrorException;

    /**
     * 加载指定菜单信息
     * @param id
     * @return
     */
    MCommemorativeKind load(Long id);

    /**
     * 加载所有菜单
     * @return
     */
    List<MCommemorativeKind> loadMenu();
}
