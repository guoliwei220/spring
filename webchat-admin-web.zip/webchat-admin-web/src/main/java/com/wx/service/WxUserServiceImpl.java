package com.wx.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.wechat.service.WeChatService;
import com.wechat.wsdata.WebChatUserInfo;
import com.wx.domain.WxAccessToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wx.domain.WxUser;
import com.wx.domain.WxUserExample;
import com.wx.exception.ServiceErrorException;
import com.wx.mapper.WxUserMapper;
import com.wx.vo.PageListData;

/**
 * 用户业务实现
 * @author jiahuijie
 *
 */
@Service
public class WxUserServiceImpl implements WxUserService{
	
	@Autowired
	private WxUserMapper wxUserMapper;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private WxAccessTokenService wxAccessTokenService;
	@Transactional
	@Override
	public void createUser(WxUser user) {
		WxUserExample wxUserExample = new WxUserExample();
		wxUserExample.or().andOpenidEqualTo(user.getOpenid());

		List<WxUser> users = wxUserMapper.selectByExample(wxUserExample);

		if (users.size() <= 0){
			Date now = new Date();
			user.setCreateTime(now);
			user.setUpdateTime(now);
			wxUserMapper.insert(user);
		} else {
			users.get(0).setCity(user.getCity());
			users.get(0).setCountry(user.getCountry());
			users.get(0).setProvince(user.getProvince());
			users.get(0).setImgshow(user.getImgshow());
			users.get(0).setIsAttention(user.getIsAttention());
			users.get(0).setNickname(user.getNickname());
			users.get(0).setSex(user.getSex());
			wxUserMapper.updateByPrimaryKeySelective(users.get(0));
		}
	}
	
	@Override
	public WxUser findByOpenId(String openId) {
		WxUserExample wxUserExample = new WxUserExample();
		wxUserExample.or().andOpenidEqualTo(openId);
		List<WxUser> wxUsers = wxUserMapper.selectByExample(wxUserExample);
		if (wxUsers.isEmpty()){
			return null;
		}
		return wxUsers.get(0);
	}
	
	@Override
	public 	PageListData<Map<String,Object>> findBindUsers(String phonenum){
		String sql="SELECT  t.nickname,t.province,t.city,t.createTime,t.openid  FROM db_wx_user t,chngc_mobile.m_user_third"+
		" t2,ctces_test.es_member t3 where  t2.openid=t.openid "+
		"and t3.MEMBER_ID=t2.userid  and  t3.MOBILE='"+phonenum+"'";
		List<Map<String,Object>> list = jdbcTemplate.queryForList(sql);
		PageListData<Map<String,Object>> result = new PageListData<Map<String,Object>>();
		result.setList(list);
		return result;
	}
	@Override
	public void delUserBind(String  openid) {
		wxUserMapper.delUserBind(openid);
	}
	@Transactional
	@Override
	public void updateAttention(String openId, boolean attention) throws ServiceErrorException{
		WxUserExample wxUserExample = new WxUserExample();
		wxUserExample.or().andOpenidEqualTo(openId);
		List<WxUser> wxUsers = wxUserMapper.selectByExample(wxUserExample);
		Date now = new Date();
		WxUser wxUser = null;
		if (wxUsers.isEmpty()){
			wxUser = new WxUser();
			wxUser.setOpenid(openId);
			wxUser.setIsAttention(attention);
			wxUser.setCreateTime(now);
			wxUser.setUpdateTime(now);
			wxUserMapper.insert(wxUser);
		}else{
			wxUser = wxUsers.get(0);
			wxUser.setIsAttention(attention);
			wxUser.setUpdateTime(now);
			wxUserMapper.updateByPrimaryKeySelective(wxUser);
		}
		if(attention)
		try{
			WxAccessToken wat = wxAccessTokenService.getAccessToken();
			final String _accessToken = wat.getAccessToken();
			final String _fromUsername = openId;
			final Long _id = wxUser.getId();
			new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						WebChatUserInfo wcui = WeChatService.getUserInfo(_accessToken, _fromUsername);
						WxUser user = new WxUser();
						user.setId(_id);
						user.setCity(wcui.getCity());
						user.setCountry(wcui.getCountry());
						user.setImgshow(wcui.getHeadImgUrl());
						user.setNickname(wcui.getNickname());
						user.setProvince(wcui.getProvince());
						wxUserMapper.updateByPrimaryKeySelective(user);
					}catch (Exception e){
						e.printStackTrace();
					}
				}
			}).start();
		}catch (Exception e){
			e.printStackTrace();
		}
	}

	/**
	 * 更新关注状态
	 *
	 * @param openId
	 * @param imgShow
	 */
	@Transactional
	@Override
	public void updateImgshow(String openId, String imgShow) throws ServiceErrorException {
		WxUserExample wxUserExample = new WxUserExample();
		wxUserExample.or().andOpenidEqualTo(openId);
		List<WxUser> wxUsers = wxUserMapper.selectByExample(wxUserExample);
		if (wxUsers.isEmpty()){
			throw new ServiceErrorException("openId不存在");
		}
		WxUser wxUser = wxUsers.get(0);
		wxUser.setImgshow(imgShow);
		wxUserMapper.updateByPrimaryKeySelective(wxUser);
	}
}
