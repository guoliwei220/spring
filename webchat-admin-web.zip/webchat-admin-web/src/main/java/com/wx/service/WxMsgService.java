package com.wx.service;

import java.util.List;
import java.util.Map;

import com.wx.domain.WxMsg;
import com.wx.vo.PageListData;

/**
 * 微信消息接口
 * @author jiahuijie
 *
 */
public interface WxMsgService {

	/**
	 * 添加消息
	 * @param callback
	 */
	public void add(WxMsg wxMsg);
	
	/**
	 * 更新回复
	 * @param id
	 * @return
	 */
	public WxMsg updateMsgByCallback(WxMsg wxMsg);
	
	
	/**
	 * 根据id删除消息
	 * @param id
	 */
	public void remove(Long id);
	
	/**
	 * 根据id批量删除消息
	 * @param ids
	 */
	public void remove(List<Long> ids);
	
	/**
	 * 列表
	 * @param pageNo
	 * @param pageSize
	 */
	public PageListData<Map<String,Object>> listUnCallback(int pageNo, int pageSize);
	
	
	/**
	 * 统计未回复的今日消息量
	 * @return
	 */
	public long countUnCallbackToday();
}
