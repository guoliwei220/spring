package com.wx.service;

import com.wx.exception.ServiceErrorException;
import com.wx.mobileDomain.MCommemorativeKind;
import com.wx.mobileDomain.MCommemorativeKindExample;
import com.wx.mobileDomain.MPandaKind;
import com.wx.mobileDomain.MPandaKindExample;
import com.wx.mobileMapper.MCommemorativeGoodsMapper;
import com.wx.mobileMapper.MCommemorativeKindMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * Created by jh on 2016/1/5.
 */
@Component
public class MCommemorativeKindServiceImpl implements MCommemorativeKindService {
    
    @Autowired
    private MCommemorativeGoodsMapper mCommemorativeGoodsMapper;

    @Autowired
    private MCommemorativeKindMapper mCommemorativeKindMapper;

    @Transactional
    @Override
    public void add(MCommemorativeKind mCommemorativeKind) throws ServiceErrorException {
        MCommemorativeKindExample example = new MCommemorativeKindExample();

        if (mCommemorativeKind.getParentId() != null){
            MCommemorativeKind parent = mCommemorativeKindMapper.selectByPrimaryKey(mCommemorativeKind.getParentId());
            if (parent == null)
                throw new ServiceErrorException("父菜单不存在");//父节点不存在

            mCommemorativeKind.setLevel(parent.getLevel() + 1);
            mCommemorativeKind.setTreeStruct((parent.getTreeStruct() == null ? "" + parent.getId() : parent.getTreeStruct() + "," + parent.getId()));
        } else {
            mCommemorativeKind.setParentId(null);
            mCommemorativeKind.setTreeStruct(null);
            mCommemorativeKind.setLevel(1);
        }

        if(mCommemorativeKind.getLevel() > 2){
            throw new ServiceErrorException("菜单最多支持二级");//菜单最多支持2级
        }

        example.clear();
        MCommemorativeKindExample.Criteria criteria = example.or();
        criteria.andNameEqualTo(mCommemorativeKind.getName());
        if (mCommemorativeKind.getParentId() != null)
            criteria.andParentIdEqualTo(mCommemorativeKind.getParentId());
        else
            criteria.andParentIdIsNull();

        if (mCommemorativeKindMapper.countByExample(example) > 0){
            throw new ServiceErrorException("菜单已存在");//分类已存在
        }

        example.clear();
        example.or().andLevelEqualTo(mCommemorativeKind.getLevel());

        example.clear();
        MCommemorativeKindExample.Criteria criteria2 = example.or();
        criteria.andLevelEqualTo(mCommemorativeKind.getLevel());
        if (mCommemorativeKind.getParentId() != null)
            criteria2.andParentIdEqualTo(mCommemorativeKind.getParentId());
        else
            criteria2.andParentIdIsNull();

        Date date = new Date();
        mCommemorativeKind.setIsNode(false);
        mCommemorativeKind.setCreateTime(date);
        mCommemorativeKind.setTs(date);

        mCommemorativeKindMapper.insert(mCommemorativeKind);
    }

    @Transactional
    @Override
    public void remove(Long id) throws ServiceErrorException {

        MCommemorativeKindExample example = new MCommemorativeKindExample();

        MCommemorativeKind pandaKind = mCommemorativeKindMapper.selectByPrimaryKey(id);
        if (pandaKind == null){
            throw new ServiceErrorException("菜单不存在");
        }

        example.clear();
        example.or().andParentIdEqualTo(id);
        if (mCommemorativeKindMapper.countByExample(example) > 0){
            throw new ServiceErrorException("当前菜单下有子菜单");
        }

        mCommemorativeKindMapper.deleteByPrimaryKey(id);
    }

    @Transactional
    @Override
    public void update(MCommemorativeKind mCommemorativeKind) throws ServiceErrorException {
        mCommemorativeKindMapper.updateByPrimaryKeySelective(mCommemorativeKind);
    }

    @Override
    public MCommemorativeKind load(Long id) {
        return mCommemorativeKindMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<MCommemorativeKind> loadMenu() {
        
        return mCommemorativeKindMapper.selectByExample(new MCommemorativeKindExample());
    }
}
