package com.wx.service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.wx.config.Constants;
import com.wx.exception.ServiceErrorException;
import com.wx.mobileDomain.MPandaGoods;
import com.wx.mobileDomain.MPandaGoodsExample;
import com.wx.mobileMapper.MPandaGoodsMapper;
import com.wx.mobileMapper.MPandaKindMapper;
import com.wx.util.CommonUtil;
import com.wx.util.JedisUtil;
import com.wx.vo.HotGoodsJson;
import com.wx.vo.PageListData;
import com.wx.vo.PandaGoodsJson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import redis.clients.jedis.Jedis;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 熊猫币业务层
 * @author jiahuijie
 *
 */
@Service
public class MPandaGoodsServiceImpl implements MPandaGoodsService {

	private static Logger logger = LoggerFactory.getLogger(HotGoodsServiceImpl.class);

	@Autowired
	private MPandaGoodsMapper mPandaGoodsMapper;

	@Autowired
	private MPandaKindMapper mPandaKindMapper;

	@Transactional
	@Override
	public void add(MPandaGoods mPandaGoods) {

		Date date = new Date();
		mPandaGoods.setCreateTime(date);
		mPandaGoods.setTs(date);
		mPandaGoodsMapper.insert(mPandaGoods);

		syncPandaGoodsToRedis(mPandaGoods.getKindId());
	}

	@Transactional
	@Override
	public void update(MPandaGoods mPandaGoods) {
		Date date = new Date();
		mPandaGoods.setCreateTime(date);
		mPandaGoods.setTs(date);
		mPandaGoodsMapper.updateByPrimaryKey(mPandaGoods);

		syncPandaGoodsToRedis(mPandaGoods.getKindId());
	}

	@Override
	public MPandaGoods loadById(Long id) {
		return mPandaGoodsMapper.selectByPrimaryKey(id);
	}


	@Override
	public PageListData<MPandaGoods> list(Long kindId, int pageNo, int pageSize) {
		MPandaGoodsExample mPandaGoodsExample = new MPandaGoodsExample();
		mPandaGoodsExample.or().andKindIdEqualTo(kindId);
		mPandaGoodsExample.setOrderByClause("sequence desc");

		Page<MPandaGoods> page = PageHelper.startPage(pageNo, pageSize);
		mPandaGoodsMapper.selectByExample(mPandaGoodsExample);
		PageListData<MPandaGoods> result = new PageListData<MPandaGoods>();
		result.setList(page.getResult());
		result.setCountAll(page.getTotal());
		return result;
	}

	@Transactional
	@Override
	public void remove(Long id) {
		//删除之前拿到kindid
		MPandaGoods mPandaGoods = mPandaGoodsMapper.selectByPrimaryKey(id);
		if(mPandaGoods==null){
			//如果数据被删除了
			throw new ServiceErrorException("商品不存在");
		}

		mPandaGoodsMapper.deleteByPrimaryKey(id);

		syncPandaGoodsToRedis(mPandaGoods.getKindId());

	}

	@Transactional
	@Override
	public void remove(List<Long> ids) {
		//删除之前拿到kindid
		MPandaGoods mPandaGoods = mPandaGoodsMapper.selectByPrimaryKey(ids.get(0));
		if(mPandaGoods==null){
			//如果数据被删除了
			throw new ServiceErrorException("商品不存在");
		}
		MPandaGoodsExample mPandaGoodsExample = new MPandaGoodsExample();
		mPandaGoodsExample.or().andIdIn(ids);
		mPandaGoodsMapper.deleteByExample(mPandaGoodsExample);

		syncPandaGoodsToRedis(mPandaGoods.getKindId());
	}

	/**
	 * 同步当前熊猫币种类下的商品至redis
	 * @param kindId 当前熊猫币种类id
	 */
	private void syncPandaGoodsToRedis(Long kindId){
		if(kindId==null||kindId<=0){
			//如果字段没有值或者值不对
			throw new ServiceErrorException("参数错误");
		}
		Jedis jedis = null;
		List<Map<String,Object>> pandaGoodsList =  mPandaGoodsMapper.getOrderedListByKindId(kindId);
		try{
			jedis = JedisUtil.getInstance().getJedis(Constants.REDIS_DB_3);
			//删除当前种类下的商品
			jedis.del(Constants.Key_Prefix_PandaGoods+kindId);

			for(Map<String,Object> pandaGoods : pandaGoodsList){
				String goodsId = pandaGoods.get("goodsId")!=null?pandaGoods.get("goodsId").toString():"";
				String shortDesc = pandaGoods.get("shortDesc")!=null?pandaGoods.get("shortDesc").toString():"";
				PandaGoodsJson pandaGoodsJson = new PandaGoodsJson(kindId,goodsId,shortDesc);
				String pandaGoodsJsonStr = CommonUtil.ObjectToJSON(pandaGoodsJson);
				jedis.rpush(Constants.Key_Prefix_PandaGoods+kindId, pandaGoodsJsonStr);
			}
		}catch(Exception e){
			logger.error("syncHotGoodsToRedis方法同步热销商品至redis异常"+e.getMessage(),e);
		}finally {
			JedisUtil.getInstance().destroy(jedis);
		}
	}
}
