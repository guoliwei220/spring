package com.wx.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import com.wx.domain.WxUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wechat.util.CommonUtil;
import com.wx.domain.WxAuth;
import com.wx.domain.WxAuthExample;
import com.wx.exception.ServiceErrorException;
import com.wx.mapper.WxAuthMapper;
import com.wx.vo.PageListData;

/**
 * 微信授权管理实现
 * @author jiahuijie
 *
 */
@Service
public class WxAuthServiceImpl implements WxAuthService{

	@Autowired
	private WxAuthMapper wxAuthMapper;

	@Transactional
	@Override
	public void addAuth(WxAuth auth) throws ServiceErrorException {
		
		WxAuthExample wxAuthExample = new WxAuthExample();
		wxAuthExample.or().andAppidEqualTo(auth.getAppid());
		long count = wxAuthMapper.countByExample(wxAuthExample);
		if (count > 0)
			throw new ServiceErrorException("授权appid已存在");
		
		Date date = new Date();
		auth.setCreateTime(date);
		auth.setUpdateTime(date);
		wxAuthMapper.insert(auth);
	}

	@Transactional
	@Override
	public void removeAuth(Long id) {
		wxAuthMapper.deleteByPrimaryKey(id);
	}

	@Transactional
	@Override
	public void removeAuth(List<Long> ids) {
		WxAuthExample wxAuthExample = new WxAuthExample();
		wxAuthExample.or().andIdIn(ids);
		wxAuthMapper.deleteByExample(wxAuthExample);
	}
	
	@Override
	public WxAuth loadById(Long id) {
		return wxAuthMapper.selectByPrimaryKey(id);
	}


	@Override
	public WxAuth loadByAppId(String appid) {
		WxAuthExample wxAuthExample = new WxAuthExample();
		wxAuthExample.or().andAppidEqualTo(appid);
		List<WxAuth> auths = wxAuthMapper.selectByExample(wxAuthExample);
		if (auths.size() > 0)
			return auths.get(0);
		return null;
	}

	@Override
	public PageListData<WxAuth> list(int pageNo, int pageSize) {
		WxAuthExample wxAuthExample = new WxAuthExample();
		wxAuthExample.setLimitStart((pageNo - 1) * pageSize);
		wxAuthExample.setLimitEnd(pageSize);
		wxAuthExample.setOrderByClause("id desc");
		List<WxAuth> list = wxAuthMapper.selectByExample(wxAuthExample);
		
		wxAuthExample.clear();
		long count = wxAuthMapper.countByExample(wxAuthExample);
		
		PageListData<WxAuth> result = new PageListData<WxAuth>();
		result.setList(list);
		result.setCountAll(count);
		return result;
	}

	@Transactional
	@Override
	public void updateAuth(WxAuth auth) throws ServiceErrorException{
		
		WxAuth wxAuthOld = wxAuthMapper.selectByPrimaryKey(auth.getId());
		
		if (!wxAuthOld.getAppid().equals(auth.getAppid())){
			WxAuthExample wxAuthExample = new WxAuthExample();
			wxAuthExample.or().andAppidEqualTo(auth.getAppid());
			long count = wxAuthMapper.countByExample(wxAuthExample);
			if (count > 0)
				throw new ServiceErrorException("授权appid已存在");
		}
		
		wxAuthMapper.updateByPrimaryKeySelective(auth);
	}
	
	
	@Override
	public boolean check(String appid, String _timestamp, String _nonce,
			String _signature) throws ServiceErrorException {
		
		if (Math.abs(new Date().getTime() - Long.parseLong(_timestamp)) > 60 * 1000){
			return false;
		}
		
		WxAuthExample wxAuthExample = new WxAuthExample();
		wxAuthExample.or().andAppidEqualTo(appid);
		
		List<WxAuth> auths = wxAuthMapper.selectByExample(wxAuthExample);
		
		if (auths.isEmpty()){
			return false;
		}
		
		WxAuth auth = auths.get(0);
		
		//1. 将token、timestamp、nonce三个参数进行字典序排序
		List<String> list = new ArrayList<String>();
		list.add(auth.getSecret());
		list.add(_timestamp);
		list.add(_nonce);
		
		Collections.sort(list);
		
		//2. 将三个参数字符串拼接成一个字符串进行sha1加密
		StringBuffer signatureBuffer = new StringBuffer();
		for (String str : list){
			signatureBuffer.append(str);
		}
		
		//3. 签名加密
		String signature = CommonUtil.SHA1(signatureBuffer.toString());
		
		//4. 开发者获得加密后的字符串可与signature对比，标识该请求来源于微信
		if (signature != null && signature.equalsIgnoreCase(_signature))
			return true;
		return false;
	}
}
