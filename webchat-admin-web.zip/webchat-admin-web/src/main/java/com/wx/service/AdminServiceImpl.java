package com.wx.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wx.domain.AuthAdmin;
import com.wx.domain.AuthAdminExample;
import com.wx.domain.AuthAdminInfo;
import com.wx.domain.AuthAdminInfoExample;
import com.wx.domain.AuthLoginLog;
import com.wx.domain.AuthLoginLogExample;
import com.wx.exception.DataFiledErrorException;
import com.wx.mapper.AuthAdminInfoMapper;
import com.wx.mapper.AuthAdminMapper;
import com.wx.mapper.AuthLoginLogMapper;
import com.wx.util.CommonUtil;
import com.wx.vo.AdminLoginSign;

/**
 * 管理员业务实现
 * @author jiahuijie
 *
 */
@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	private AuthAdminMapper authAdminMapper;
	
	@Autowired
	private AuthAdminInfoMapper authAdminInfoMapper;
	
	@Autowired
	private AuthLoginLogMapper authLoginLogMapper;
	
	@Transactional
	@Override
	public AdminLoginSign login(String username, String password)
			throws DataFiledErrorException {
		
		AuthAdminExample example = new AuthAdminExample();
		example.or().andUsernameEqualTo(username);
		
		//判断账号存在
		List<AuthAdmin> authAdmins =  authAdminMapper.selectByExample(example);
		if (authAdmins.size() <= 0){
			throw new DataFiledErrorException("username", "账号不存在");
		}
		
		//判断密码存在
		AuthAdmin authAdmin = authAdmins.get(0);
		if (!authAdmin.getPassword().equalsIgnoreCase(CommonUtil.MD5(password))){
			throw new DataFiledErrorException("password", "密码不正确");
		}
		
		//账号已锁定
		if (authAdmin.getStatus().equals(AuthAdmin.STATUS_LOCK)){
			throw new DataFiledErrorException("username", "账号已锁定");
		}
		
		AdminLoginSign als = new AdminLoginSign();
		als.setAdminId(authAdmin.getId());
		als.setUsername(authAdmin.getUsername());
		
		AuthAdminInfoExample authAdminInfoexample = new AuthAdminInfoExample();
		authAdminInfoexample.or().andAdminIdEqualTo(authAdmin.getId());
		List<AuthAdminInfo> authAdminInfos = authAdminInfoMapper.selectByExample(authAdminInfoexample);
		
		if (authAdminInfos.size() > 0){
			AuthAdminInfo authAdminInfo = authAdminInfos.get(0);
			als.setNickname(authAdminInfo.getNickname());
			als.setImgshow(authAdminInfo.getFaceimg());
		}
		
		AuthLoginLogExample authLoginLogExample = new AuthLoginLogExample();
		authLoginLogExample.or().andUserIdEqualTo(authAdmin.getId());
		authLoginLogExample.setLimitStart(0);
		authLoginLogExample.setLimitEnd(1);
		authLoginLogExample.setOrderByClause("id desc");
		List<AuthLoginLog> authLoginLogs = authLoginLogMapper.selectByExample(authLoginLogExample);
		
		if (authLoginLogs.size() > 0){
			AuthLoginLog authLoginLog = authLoginLogs.get(0);
			als.setLastLoginIP(authLoginLog.getFromIP());
			als.setLastLoginTime(authLoginLog.getCreateTime());
		}
		
		return als;
	}
	
	
	@Override
	public void loginLog(AuthLoginLog log){
		Date date = new Date();
		log.setCreateTime(date);
		log.setUpdateTime(date);
		authLoginLogMapper.insert(log);
	}

	@Transactional
	@Override
	public void updatePassword(Long id, String oldPassword, String newPassword) throws DataFiledErrorException {
		AuthAdmin admin = authAdminMapper.selectByPrimaryKey(id);
		if (!admin.getPassword().equals(oldPassword)){
			throw new DataFiledErrorException("oldPassword", "旧密码输入有误");
		}
		
		admin.setPassword(newPassword);
		authAdminMapper.updateByPrimaryKey(admin);
	}
}
