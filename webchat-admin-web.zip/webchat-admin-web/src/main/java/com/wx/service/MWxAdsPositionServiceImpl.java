package com.wx.service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.wx.exception.ServiceErrorException;
import com.wx.mobileDomain.MWxAdsPosition;
import com.wx.mobileDomain.MWxAdsPositionExample;
import com.wx.mobileMapper.MWxAdsPositionMapper;
import com.wx.vo.PageListData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * Created by jiahuijie on 2015/11/25.
 */
@Service
public class MWxAdsPositionServiceImpl implements MWxAdsPositionService {

    @Autowired
    private MWxAdsPositionMapper mMWxAdsPositionMapper;

    @Transactional
    @Override
    public void add(MWxAdsPosition mWxAdsPosition) throws ServiceErrorException {

        MWxAdsPositionExample mWxAdsPositionExample = new MWxAdsPositionExample();
        mWxAdsPositionExample.or().andAdsPositionEqualTo(mWxAdsPosition.getAdsPosition());
        long count = mMWxAdsPositionMapper.countByExample(mWxAdsPositionExample);
        if (count > 0)
            throw new ServiceErrorException("广告位key已经存在");

        Date date = new Date();
        mWxAdsPosition.setCreateTime(date);
        mWxAdsPosition.setTs(date);
        mMWxAdsPositionMapper.insert(mWxAdsPosition);
    }

    @Transactional
    @Override
    public void remove(Long id) {
        mMWxAdsPositionMapper.deleteByPrimaryKey(id);
    }

    @Transactional
    @Override
    public void remove(List<Long> ids) {
        MWxAdsPositionExample mWxAdsPositionExample = new MWxAdsPositionExample();
        mWxAdsPositionExample.or().andIdIn(ids);
        mMWxAdsPositionMapper.deleteByExample(mWxAdsPositionExample);
    }

    @Override
    public MWxAdsPosition loadById(Long id) {
        return mMWxAdsPositionMapper.selectByPrimaryKey(id);
    }

    @Override
    public PageListData<MWxAdsPosition> list(int pageNo, int pageSize) {
        MWxAdsPositionExample example = new MWxAdsPositionExample();

        Page<MWxAdsPosition> page = PageHelper.startPage(pageNo, pageSize);
        List<MWxAdsPosition> list =  mMWxAdsPositionMapper.selectByExample(example);

        PageListData<MWxAdsPosition> result = new PageListData<MWxAdsPosition>();
        result.setList(page.getResult());
        result.setCountAll(page.getTotal());
        return result;
    }

    @Transactional
    @Override
    public void update(MWxAdsPosition mMWxAdsPosition) throws ServiceErrorException{

        MWxAdsPosition mWxAdsPositionOld = mMWxAdsPositionMapper.selectByPrimaryKey(mMWxAdsPosition.getId());

        if (!mWxAdsPositionOld.getAdsPosition().equals(mMWxAdsPosition.getAdsPosition())){
            MWxAdsPositionExample mWxAdsPositionExample = new MWxAdsPositionExample();
            mWxAdsPositionExample.or().andAdsPositionEqualTo(mMWxAdsPosition.getAdsPosition());
            long count = mMWxAdsPositionMapper.countByExample(mWxAdsPositionExample);
            if (count > 0)
                throw new ServiceErrorException("广告位key已经存在");
        }

        mMWxAdsPositionMapper.updateByPrimaryKeySelective(mMWxAdsPosition);
    }
}
