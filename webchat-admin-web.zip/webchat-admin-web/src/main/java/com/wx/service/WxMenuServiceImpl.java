package com.wx.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wx.domain.WxCallback;
import com.wx.domain.WxCallbackExample;
import com.wx.domain.WxMenu;
import com.wx.domain.WxMenuExample;
import com.wx.exception.ServiceErrorException;
import com.wx.mapper.WxCallbackMapper;
import com.wx.mapper.WxMenuMapper;
import com.wx.util.CommonUtil;
import com.wx.vo.WxTreeNode;

/**
 * 微信菜单实现
 * @author jiahuijie
 *
 */
@Service
public class WxMenuServiceImpl implements WxMenuService{

	@Autowired
	private WxMenuMapper wxMenuMapper;
	
	@Autowired
	private WxCallbackMapper wxCallbackMapper;
	
	@Autowired
	private WxCallbackService wxCallbackService;
	
	@Transactional
	@Override
	public WxMenu add(WxMenu wxMenu) throws ServiceErrorException{
		
		WxMenuExample example = new WxMenuExample();
		
		if (wxMenu.getParentId() != null){
			WxMenu parent = wxMenuMapper.selectByPrimaryKey(wxMenu.getParentId());
			if (parent == null)
				throw new ServiceErrorException("父菜单不存在");//父节点不存在
			
			wxMenu.setLevel(parent.getLevel() + 1);
			wxMenu.setTreeStruct((parent.getTreeStruct() == null ? "" + parent.getId() : parent.getTreeStruct() + "," + parent.getId()));
		} else {
			wxMenu.setParentId(null);
			wxMenu.setTreeStruct(null);
			wxMenu.setLevel(1);
		}
		
		if(wxMenu.getLevel() > 2){
			throw new ServiceErrorException("菜单最多支持二级");//菜单最多支持2级
		}
		
		example.clear();
		com.wx.domain.WxMenuExample.Criteria criteria = example.or();
		criteria.andNameEqualTo(wxMenu.getName());
		if (wxMenu.getParentId() != null)
			criteria.andParentIdEqualTo(wxMenu.getParentId());
		else
			criteria.andParentIdIsNull();
		
		if (wxMenuMapper.countByExample(example) > 0){
			throw new ServiceErrorException("菜单已存在");//分类已存在
		}
		
		example.clear();
		example.or().andLevelEqualTo(wxMenu.getLevel());
		
		example.clear();
		com.wx.domain.WxMenuExample.Criteria criteria2 = example.or();
		criteria.andLevelEqualTo(wxMenu.getLevel());
		if (wxMenu.getParentId() != null)
			criteria2.andParentIdEqualTo(wxMenu.getParentId());
		else
			criteria2.andParentIdIsNull();
		
		long levelCount = wxMenuMapper.countByExample(example);
		if (wxMenu.getLevel() == 1 && levelCount >= 3){//数量超出限制
			throw new ServiceErrorException("一级菜单最多三个");
		} else if (wxMenu.getLevel() == 2 && levelCount >= 5){
			throw new ServiceErrorException("二级菜单最多五个");
		}
		
		Date date = new Date();
		wxMenu.setIsNode(false);
		wxMenu.setCreateTime(date);
		wxMenu.setUpdateTime(date);
		
		wxMenuMapper.insert(wxMenu);
		
		return wxMenu;
	}
	
	@Transactional
	@Override
	public void remove(Long id) throws ServiceErrorException{
		WxMenuExample example = new WxMenuExample();
		
		WxMenu wxMenu = wxMenuMapper.selectByPrimaryKey(id);
		if (wxMenu == null){
			throw new ServiceErrorException("菜单不存在");
		}
		
		example.clear();
		example.or().andParentIdEqualTo(id);
		if (wxMenuMapper.countByExample(example) > 0){
			throw new ServiceErrorException("当前菜单下有子菜单");
		}
		
		wxMenuMapper.deleteByPrimaryKey(id);
	}
	
	@Transactional
	@Override
	public WxMenu update(WxMenu wxMenu) throws ServiceErrorException{
		wxMenuMapper.updateByPrimaryKeySelective(wxMenu);
		WxMenu wx = wxMenuMapper.selectByPrimaryKey(wxMenu.getId());
		return wx;
	}
	
	@Transactional
	@Override
	public void addLink(long id, String url) throws ServiceErrorException{
		
		WxMenuExample example = new WxMenuExample();
		
		WxMenu wxMenu = wxMenuMapper.selectByPrimaryKey(id);
		if (wxMenu == null){
			throw new ServiceErrorException("菜单不存在");
		}
		
		example.clear();
		example.or().andParentIdEqualTo(id);
		if (wxMenuMapper.countByExample(example) > 0){
			throw new ServiceErrorException("当前菜单下有子菜单");
		}
		
		if (WxMenu.TYPE_CLICK.equals(wxMenu.getType())){
			WxCallbackExample wxCallbackExample = new WxCallbackExample();
			wxCallbackExample.or().andBtnKeyEqualTo(wxMenu.getBtnKey());
			wxCallbackMapper.deleteByExample(wxCallbackExample);
			wxMenu.setBtnKey(null);
		}
		
		wxMenu.setType(WxMenu.TYPE_VIEW);
		wxMenu.setUrl(url);
		
		wxMenuMapper.updateByPrimaryKey(wxMenu);
	}
	
	
	@Transactional
	@Override
	public void addMsg(long id, WxCallback wxCallback) throws ServiceErrorException{
		
		WxMenuExample example = new WxMenuExample();
		
		WxMenu wxMenu = wxMenuMapper.selectByPrimaryKey(id);
		if (wxMenu == null){
			throw new ServiceErrorException("菜单不存在");
		}
		
		example.clear();
		example.or().andParentIdEqualTo(id);
		if (wxMenuMapper.countByExample(example) > 0){
			throw new ServiceErrorException("当前菜单下有子菜单");
		}
		
		if (WxMenu.TYPE_CLICK.equals(wxMenu.getType())){
			WxCallbackExample wxCallbackExample = new WxCallbackExample();
			wxCallbackExample.or().andBtnKeyEqualTo(wxMenu.getBtnKey());
			wxCallbackMapper.deleteByExample(wxCallbackExample);
			wxMenu.setBtnKey(null);
		}
		
		wxCallback.setScene(WxCallback.SCENE_MENU);
		wxCallbackService.add(wxCallback);
		
		String btnKey = "BTN_" + wxCallback.getId();
		
		WxCallback wcb = new WxCallback();
		wcb.setId(wxCallback.getId());
		wcb.setBtnKey(btnKey);
		wxCallbackMapper.updateByPrimaryKeySelective(wcb);
		
		wxCallback.setBtnKey(btnKey);
		
		wxMenu.setBtnKey(btnKey);
		wxMenu.setType(WxMenu.TYPE_CLICK);
		
		wxMenuMapper.updateByPrimaryKey(wxMenu);
	}
	
	
	@Override
	public void resetAction(Long id) throws ServiceErrorException {
		WxMenuExample example = new WxMenuExample();
		
		WxMenu wxMenu = wxMenuMapper.selectByPrimaryKey(id);
		if (wxMenu == null){
			throw new ServiceErrorException("菜单不存在");
		}
		
		example.clear();
		example.or().andParentIdEqualTo(id);
		if (wxMenuMapper.countByExample(example) > 0){
			throw new ServiceErrorException("当前菜单下有子菜单");
		}
		
		if (WxMenu.TYPE_CLICK.equals(wxMenu.getType())){
			WxCallbackExample wxCallbackExample = new WxCallbackExample();
			wxCallbackExample.or().andBtnKeyEqualTo(wxMenu.getBtnKey());
			wxCallbackMapper.deleteByExample(wxCallbackExample);
			wxMenu.setBtnKey(null);
		}
		
		wxMenu.setType(null);
		wxMenu.setUrl(null);
		wxMenu.setBtnKey(null);
		
		wxMenuMapper.updateByPrimaryKey(wxMenu);
	}
	
	
	@Override
	public WxMenu load(Long id) {
		return wxMenuMapper.selectByPrimaryKey(id);
	}
	
	@Override
	public List<WxMenu> loadMenu() {
		WxMenuExample example = new WxMenuExample();
		return wxMenuMapper.selectByExample(example);
	}
	
	@Transactional
	@Override
	public WxTreeNode apply() throws ServiceErrorException {
		WxMenuExample example = new WxMenuExample();
		List<WxMenu> menus = wxMenuMapper.selectByExample(example);
		
		if (menus.size() <= 0){
			throw new ServiceErrorException("当前没有菜单");
		}
		
		
		WxTreeNode baseNode = new WxTreeNode();
		baseNode.setRoot(true);
		
		List<WxTreeNode> treeNodes = new ArrayList<WxTreeNode>();
		for (WxMenu wxMenu : menus){
			WxTreeNode node = new WxTreeNode();
			node.setId(wxMenu.getId());
			node.setKey(wxMenu.getBtnKey());
			node.setName(wxMenu.getName());
			node.setParentId(wxMenu.getParentId());
			node.setRoot(false);
			node.setType(wxMenu.getType());
			node.setUrl(wxMenu.getUrl());
			treeNodes.add(node);
		}
		
		baseNode = CommonUtil.formatWxTree(baseNode, treeNodes);
		
		for (WxTreeNode node : baseNode.getSub_button()){
			if (node.getSub_button().size() <= 0){
				if (StringUtils.isBlank(node.getType())){
					throw new ServiceErrorException("[" + node.getName() + "]缺少类型");
				} else if (node.getType().equals(WxMenu.TYPE_VIEW)){
					if(StringUtils.isBlank(node.getUrl())){
						throw new ServiceErrorException("[" + node.getName() + "]缺少url");
					}
				} else if (StringUtils.isBlank(node.getKey())){
					throw new ServiceErrorException("[" + node.getName() + "]缺少key");
				}
			}
			
			for (WxTreeNode child : node.getSub_button()){
				if (StringUtils.isBlank(child.getType())){
					throw new ServiceErrorException("[" + child.getName() + "]缺少类型");
				} else if (child.getType().equals(WxMenu.TYPE_VIEW)){
					if(StringUtils.isBlank(child.getUrl())){
						throw new ServiceErrorException("[" + child.getName() + "]缺少url");
					}
				} else if (StringUtils.isBlank(child.getKey())){
					throw new ServiceErrorException("[" + child.getName() + "]缺少key");
				}
			}
		}
		
		return baseNode;
	}
}
