package com.wx.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.wx.domain.WxMsg;
import com.wx.domain.WxMsgExample;
import com.wx.mapper.WxMsgMapper;
import com.wx.vo.PageListData;

/**
 * 微信消息实现
 * @author jiahuijie
 *
 */
@Service
public class WxMsgServiceImpl implements WxMsgService{

	@Autowired
	private WxMsgMapper wxMsgMapper;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public void add(WxMsg wxMsg){
		Date date = new Date();
		wxMsg.setCreateTime(date);
		wxMsg.setUpdateTime(date);
		wxMsgMapper.insert(wxMsg);
	}

	@Override
	public WxMsg updateMsgByCallback(WxMsg wxMsg) {
		WxMsg record = new WxMsg();
		record.setId(wxMsg.getId());
		record.setCallback(wxMsg.getCallback());
		record.setIsReply(true);
		record.setCallbackMode(wxMsg.getCallbackMode());
		wxMsgMapper.updateByPrimaryKeySelective(record);
		
		return wxMsgMapper.selectByPrimaryKey(wxMsg.getId());
	}

	@Override
	public void remove(Long id) {
		wxMsgMapper.deleteByPrimaryKey(id);
	}

	@Override
	public void remove(List<Long> ids) {
		WxMsgExample example = new WxMsgExample();
		example.or().andIdIn(ids);
		
		wxMsgMapper.deleteByExample(example);
	}
	
	@Override
	public PageListData<Map<String,Object>> listUnCallback(int pageNo, int pageSize) {
		String sql = "select m.id id, m.fromOpenId, m.toOpenId, m.msg, m.callback, m.msgType, m.callbackMode, m.isReply, m.createTime, " + 
				"m.updateTime, u.nickname, u.imgshow " +
				"from db_wx_msg m, db_wx_user u where m.fromOpenId = u.openId and m.msgType != 'event' order by m.id desc limit ?,?";
		
		List<Map<String,Object>> list = jdbcTemplate.queryForList(sql, (pageNo - 1) * pageSize, pageSize);
		
		sql = "select count(*) from db_wx_msg m, db_wx_user u where m.fromOpenId = u.openId and m.msgType != 'event'";
		
		long count = jdbcTemplate.queryForObject(sql, Long.class);
		
		PageListData<Map<String,Object>> result = new PageListData<Map<String,Object>>();
		result.setList(list);
		result.setCountAll(count);
		
		return result;
	}
	
	
	@Override
	public long countUnCallbackToday() {
		
		Date now  = new Date();
		Date startDate = DateUtils.truncate(now, Calendar.DAY_OF_MONTH);
		
		WxMsgExample wxMsgExample = new WxMsgExample();
		wxMsgExample.or()
			.andIsReplyEqualTo(false)
			.andCreateTimeGreaterThanOrEqualTo(startDate);
		long count = wxMsgMapper.countByExample(wxMsgExample);
		return count;
	}
}
