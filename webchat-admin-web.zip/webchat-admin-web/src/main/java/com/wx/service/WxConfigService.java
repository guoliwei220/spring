package com.wx.service;

import com.wx.domain.WxConfig;

/**
 * 微信配置接口
 * @author jiahuijie
 *
 */
public interface WxConfigService {

	/**
	 * 微信配置
	 * @return
	 */
	WxConfig getConfig();
	
	/**
	 * 配置参数
	 * @param wxConfig
	 */
	void setConfig(WxConfig wxConfig);
}
