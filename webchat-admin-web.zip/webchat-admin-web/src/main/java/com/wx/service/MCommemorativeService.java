package com.wx.service;

import com.wx.mobileDomain.MCommemorativeGoods;
import com.wx.vo.PageListData;

import java.util.List;

/**
 * Created by jh on 2016/1/6.
 */
public interface MCommemorativeService {

    public void add(MCommemorativeGoods mCommemorativeGoods);

    void remove(Long id);

    void remove(List<Long> ids);

    public void update(MCommemorativeGoods mCommemorativeGoods);

    public MCommemorativeGoods loadById(Long id);

    public PageListData<MCommemorativeGoods> list(Long kindId, int pageNo, int pageSize);
}
