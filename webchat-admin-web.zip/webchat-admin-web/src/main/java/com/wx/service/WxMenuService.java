package com.wx.service;

import java.util.List;

import com.wx.domain.WxCallback;
import com.wx.domain.WxMenu;
import com.wx.exception.ServiceErrorException;
import com.wx.vo.WxTreeNode;

/**
 * 微信菜单接口
 * @author jiahuijie
 *
 */
public interface WxMenuService {

	/**
	 * 添加菜单类别
	 * @param wxMenu
	 */
	public WxMenu add(WxMenu wxMenu) throws ServiceErrorException;
	
	/**
	 * 删除菜单
	 * @param id
	 */
	void remove(Long id) throws ServiceErrorException;
	
	/**
	 * 修改菜单
	 * @param wxMenu
	 */
	WxMenu update(WxMenu wxMenu) throws ServiceErrorException;
	
	
	/**
	 * 重设菜单动作
	 */
	void resetAction(Long id) throws ServiceErrorException;
	
	
	/**
	 * 添加菜单链接
	 * @param id
	 * @param url
	 * @throws ServiceErrorException
	 */
	void addLink(long id, String url) throws ServiceErrorException;
	
	/**
	 * 添加菜单消息
	 * @param id
	 * @param wxCallback
	 * @throws ServiceErrorException
	 */
	void addMsg(long id, WxCallback wxCallback) throws ServiceErrorException;
	
	
	/**
	 * 加载指定菜单信息
	 * @param id
	 * @return
	 */
	WxMenu load(Long id);
	
	/**
	 * 加载所有菜单
	 * @return
	 */
	List<WxMenu> loadMenu();
	
	/**
	 * 发布菜单
	 */
	WxTreeNode apply() throws ServiceErrorException;
}
