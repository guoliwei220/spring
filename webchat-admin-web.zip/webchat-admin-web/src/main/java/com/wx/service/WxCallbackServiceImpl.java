package com.wx.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wechat.message.WeChatCallbackMessage;
import com.wx.domain.WxCallback;
import com.wx.domain.WxCallbackExample;
import com.wx.mapper.WxCallbackMapper;
import com.wx.mapper.WxResourceNewsMapper;
import com.wx.mapper.WxResourceTextMapper;

/**
 * 微信自动回复实现
 * @author jiahuijie
 *
 */
@Service
public class WxCallbackServiceImpl implements WxCallbackService{

	@Autowired
	private WxCallbackMapper wxCallbackMapper;
	
	@Autowired
	private WxResourceNewsMapper wxResourceNewsMapper;
	
	@Autowired
	private WxResourceTextMapper wxResourceTextMapper;

	@Transactional
	@Override
	public void add(WxCallback wxCallback){
		
		WxCallbackExample wxCallbackExample = new WxCallbackExample();
		
		if (wxCallback.getId() != null){
			Date date = new Date();
			wxCallback.setCreateTime(date);
			wxCallback.setUpdateTime(date);
			wxCallbackMapper.updateByPrimaryKeySelective(wxCallback);
			return;
		}
		
		String scene = wxCallback.getScene();
		if (scene.equals(WxCallback.SCENE_SUBSCRIBE) || scene.equals(WxCallback.SCENE_CALLBACK)){
			wxCallbackExample.clear();
			wxCallbackExample.or().andSceneEqualTo(scene);
			List<WxCallback> callbackList = wxCallbackMapper.selectByExample(wxCallbackExample);
			
			if (callbackList.size() > 0){
				WxCallback oldWxCallback = callbackList.get(0);
				oldWxCallback.setBtnKey(wxCallback.getBtnKey());
				oldWxCallback.setResourceId(wxCallback.getResourceId());
				oldWxCallback.setResourceType(wxCallback.getResourceType());
				oldWxCallback.setScene(wxCallback.getScene());
				oldWxCallback.setWords(wxCallback.getWords());
				wxCallbackMapper.updateByPrimaryKey(oldWxCallback);
				
				return;
			}
		}
		
		Date date = new Date();
		wxCallback.setCreateTime(date);
		wxCallback.setUpdateTime(date);
		wxCallbackMapper.insert(wxCallback);
	}
	
	
	@Override
	public Object loadResourceByCallbackId(Long id) {
		WxCallback callback = wxCallbackMapper.selectByPrimaryKey(id);
		
		if (callback == null)
			return null;
		
		if (callback.getResourceType().equals(WeChatCallbackMessage.MSG_TYPE_TEXT)){
			return wxResourceTextMapper.selectByPrimaryKey(callback.getResourceId());
		} else if (callback.getResourceType().equals(WeChatCallbackMessage.MSG_TYPE_NEWS)){
			return wxResourceNewsMapper.selectByPrimaryKey(callback.getResourceId());
		}
		
		return null;
	}
	
	@Override
	public Object loadResourceByScence(String scene) {
		WxCallbackExample wxCallbackExample = new WxCallbackExample();
		wxCallbackExample.or().andSceneEqualTo(scene);
		List<WxCallback> callbacks = wxCallbackMapper.selectByExample(wxCallbackExample);
		
		if (callbacks == null || callbacks.isEmpty())
			return null;
		
		WxCallback callback = callbacks.get(0);
		
		if (callback.getResourceType().equals(WeChatCallbackMessage.MSG_TYPE_TEXT)){
			return wxResourceTextMapper.selectByPrimaryKey(callback.getResourceId());
		} else if (callback.getResourceType().equals(WeChatCallbackMessage.MSG_TYPE_NEWS)){
			return wxResourceNewsMapper.selectByPrimaryKey(callback.getResourceId());
		}
		
		return null;
	}
	
	@Override
	public Object loadResourceByBtnKey(String btnKey) {
		WxCallbackExample wxCallbackExample = new WxCallbackExample();
		wxCallbackExample.or().andBtnKeyEqualTo(btnKey);
		List<WxCallback> callbacks = wxCallbackMapper.selectByExample(wxCallbackExample);
		
		if (callbacks == null || callbacks.isEmpty())
			return null;
		
		WxCallback callback = callbacks.get(0);
		
		if (callback.getResourceType().equals(WeChatCallbackMessage.MSG_TYPE_TEXT)){
			return wxResourceTextMapper.selectByPrimaryKey(callback.getResourceId());
		} else if (callback.getResourceType().equals(WeChatCallbackMessage.MSG_TYPE_NEWS)){
			return wxResourceNewsMapper.selectByPrimaryKey(callback.getResourceId());
		}
		
		return null;
	}
	
	
	@Override
	public Object loadResourceByWords(String words) {
		WxCallbackExample wxCallbackExample = new WxCallbackExample();
		wxCallbackExample.setLimitStart(0);
		wxCallbackExample.setLimitEnd(3);
		wxCallbackExample.setOrderByClause("id desc");
		wxCallbackExample.or().andWordsEqualTo(words);
		wxCallbackExample.or().andWordsLike("% " + words + " %");
		wxCallbackExample.or().andWordsLike(words + " %");
		wxCallbackExample.or().andWordsLike("% " + words);
		List<WxCallback> callbacks = wxCallbackMapper.selectByExample(wxCallbackExample);
		
		if (callbacks == null || callbacks.isEmpty())
			return null;
		
		WxCallback callback = callbacks.get(0);
		
		if (callback.getResourceType().equals(WeChatCallbackMessage.MSG_TYPE_TEXT)){
			return wxResourceTextMapper.selectByPrimaryKey(callback.getResourceId());
		} else if (callback.getResourceType().equals(WeChatCallbackMessage.MSG_TYPE_NEWS)){
			return wxResourceNewsMapper.selectByPrimaryKey(callback.getResourceId());
		}
		
		return null;
	}
	
	@Override
	public List<WxCallback> listForWords() {
		WxCallbackExample wxCallbackExample = new WxCallbackExample();
		wxCallbackExample.or().andSceneEqualTo(WxCallback.SCENE_WORDS);
		List<WxCallback> list = wxCallbackMapper.selectByExample(wxCallbackExample);
		
		return list;
	}
	
	@Override
	public WxCallback loadCallbackByBtnKey(String btnKey) {
		WxCallbackExample wxCallbackExample = new WxCallbackExample();
		wxCallbackExample.or().andBtnKeyEqualTo(btnKey);
		List<WxCallback> callbacks = wxCallbackMapper.selectByExample(wxCallbackExample);
		
		if (callbacks == null || callbacks.isEmpty())
			return null;
		
		WxCallback callback = callbacks.get(0);
		return callback;
	}
	
	@Override
	public WxCallback loadCallbackByScene(String scene) {
		WxCallbackExample wxCallbackExample = new WxCallbackExample();
		wxCallbackExample.or().andSceneEqualTo(scene);
		List<WxCallback> callbacks = wxCallbackMapper.selectByExample(wxCallbackExample);
		
		if (callbacks == null || callbacks.isEmpty())
			return null;
		
		WxCallback callback = callbacks.get(0);
		return callback;
	}

	@Transactional
	@Override
	public void removeByScene(String scene) {
		WxCallbackExample example = new WxCallbackExample();
		example.or().andSceneEqualTo(scene);
		wxCallbackMapper.deleteByExample(example);
	}

	@Transactional
	@Override
	public void removeById(Long id) {
		wxCallbackMapper.deleteByPrimaryKey(id);
	}
}
