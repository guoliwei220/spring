package com.wx.service;

import java.util.List;
import java.util.Map;

import com.wx.domain.WxUser;
import com.wx.exception.ServiceErrorException;
import com.wx.vo.PageListData;


/**
 * 用户接口
 * @author jiahuijie
 *
 */
public interface WxUserService {

	/**
	 * 创建用户
	 * @param user
	 */
	void createUser(WxUser user);
	
	/**
	 * 查找用户
	 * @param openId
	 * @return
	 */
	WxUser findByOpenId(String openId);
	
	
	/**
	 * 列表
	 * @param phonenum
	 * 
	 */
	public PageListData<Map<String,Object>> findBindUsers(String phonenum);
	
	/**
	 * 解绑
	 * @param openid
	 * 
	 */
	public void delUserBind(String openid);
	/**
	 * 更新关注状态
	 * @param openId
	 * @param Attention
	 */
	void updateAttention(String openId, boolean Attention) throws ServiceErrorException;

	/**
	 * 更新关注状态
	 * @param openId
	 * @param imgShow
	 */
	void updateImgshow(String openId, String imgShow) throws ServiceErrorException;
}
