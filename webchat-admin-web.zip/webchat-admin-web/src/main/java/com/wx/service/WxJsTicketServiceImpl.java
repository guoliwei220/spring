package com.wx.service;

import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import com.wechat.wsdata.WebChatToken;
import com.wx.domain.WxConfig;
import com.wx.util.SpringRedisLockUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import com.wechat.exception.WxErrorException;
import com.wechat.exception.WxNetException;
import com.wechat.service.WeChatService;
import com.wechat.wsdata.WebChatJsTicket;
import com.wx.domain.WxAccessToken;
import com.wx.domain.WxJsTicket;
import com.wx.domain.WxJsTicketExample;
import com.wx.exception.ServiceErrorException;
import com.wx.mapper.WxJsTicketMapper;

/**
 * 微信Token实现
 * @author jiahuijie
 *
 */
@Service
public class WxJsTicketServiceImpl implements WxJsTicketService{

	@Autowired
	private WxJsTicketMapper wxJsTicketMapper;
	
	@Autowired
	private WxAccessTokenService wxAccessTokenService;

	@Autowired
	private RedisTemplate<String, Object> redisTemplate;
	
	@Override
	public WxJsTicket getJsTicket() throws ServiceErrorException, WxErrorException, WxNetException{

		WxJsTicket wxJsTicket = null;

		//判断token是否存在
		if(redisTemplate.hasKey(JS_TOKEN_KEY)){
			wxJsTicket = (WxJsTicket) redisTemplate.opsForValue().get(JS_TOKEN_KEY);
		} else {
			boolean lockSuc = false;
			try {
				if (SpringRedisLockUtil.lock(redisTemplate, LOCK_JS_TOKEN_KEY, 10, TimeUnit.SECONDS)) { //启用锁
					//执行业务逻辑
					lockSuc = true;

					//加载微信token
					WxAccessToken wxAccessToken = wxAccessTokenService.getAccessToken();

					//获取ticket
					WebChatJsTicket wcjt = WeChatService.getJsTicket(wxAccessToken.getAccessToken());

					//插入token到数据库
					Date date = new Date();
					wxJsTicket = new WxJsTicket();
					wxJsTicket.setTicket(wcjt.getTicket());
					wxJsTicket.setCreateTime(date);
					wxJsTicket.setExpiresIn(wcjt.getExpires_in());
					wxJsTicket.setUpdateTime(date);
					wxJsTicketMapper.insert(wxJsTicket);

					redisTemplate.opsForValue().set(JS_TOKEN_KEY, wxJsTicket, 7000,TimeUnit.SECONDS);
				} else {
					throw new ServiceErrorException("js_token生成失败");
				}
			} catch (ServiceErrorException e){
				throw e;
			} catch (Exception e) {
				// 分布式锁异常
				throw new ServiceErrorException("js_token生成同步锁异常");
			} finally {
				if(lockSuc)	//加锁成功，解锁
					SpringRedisLockUtil.unlock(redisTemplate, LOCK_JS_TOKEN_KEY);
			}
		}

		return wxJsTicket;
	}

	@Override
	public void init() throws ServiceErrorException {
		redisTemplate.delete(JS_TOKEN_KEY);
	}
}
