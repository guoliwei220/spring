package com.wx.service;

import java.util.Map;

import com.wx.domain.WxScanLogin;
import com.wx.exception.ServiceErrorException;


/**
 * 微信扫码登陆接口
 * @author jiahuijie
 *
 */
public interface WxScanLoginService {

	/**
	 * 创建扫码登陆ticket
	 * @param wxScanLogin
	 */
	void createTicket(WxScanLogin wxScanLogin);
	
	/**
	 * 登陆状态监测
	 * @param ticket
	 * @throws ServiceErrorException
	 */
	Map<String, Object> check(String ticket) throws ServiceErrorException;
	
	/**
	 * 扫描方法
	 * @param openid
	 * @param ticket
	 * @throws ServiceErrorException
	 */
	void scan(String openid, String ticket) throws ServiceErrorException;
}
