package com.wx.service;

import java.io.IOException;

import com.wechat.exception.WxErrorException;
import com.wechat.exception.WxNetException;
import com.wx.domain.WxAccessToken;
import com.wx.exception.ServiceErrorException;

/**
 * 微信Token接口
 * @author jiahuijie
 *
 */
public interface WxAccessTokenService {

	//token key 锁
	public static final String LOCK_TOKEN_KEY = "lock_token_key";

	//token key
	public static final String TOKEN_KEY = "token_key";

	/**
	 * 获取Token
	 * @return
	 * @throws ServiceErrorException
	 * @throws WxErrorException
	 * @throws WxNetException
	 * @throws IOException
	 */
	public WxAccessToken getAccessToken() throws ServiceErrorException, WxErrorException, WxNetException;

	/**
	 * 初始化
	 * @return
	 * @throws ServiceErrorException
	 */
	public void init() throws ServiceErrorException;
}
