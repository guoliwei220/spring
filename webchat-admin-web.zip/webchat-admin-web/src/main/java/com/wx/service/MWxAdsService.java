package com.wx.service;

import com.wx.mobileDomain.MWxAds;
import com.wx.mobileDomain.MWxAdsPosition;
import com.wx.vo.PageListData;
import com.wx.web.form.MWxAdsFormAdd;
import com.wx.web.form.MWxAdsFormDel;
import com.wx.web.form.MWxAdsFormUpdate;

import java.util.List;
import java.util.Map;

/**
 * Created by jiahuijie on 2015/11/25.
 */
public interface MWxAdsService {

    /**
     * 查询所有的广告位
     * @return
     */
    List<MWxAdsPosition> selectAdsPostionList();

    /**
     * 微信广告列表
     * @param pageNo
     * @param pageSize
     */
    public PageListData<Map<String,Object>> list(int pageNo, int pageSize);

    /**
     * 保存广告
     * @param form
     */
    void save(MWxAdsFormAdd form);

    /**
     * 加载广告
     * @param id
     */
    MWxAds load(Long id);

    /**
     * 更新广告
     * @param form
     */
    void update(MWxAdsFormUpdate form);
    /**
     * 删除广告
     * @param form
     */
    void delete(MWxAdsFormDel form);
    /**
     * 批量删除广告
     * @param ids
     */
    void deletes(List<Long> ids);
}
