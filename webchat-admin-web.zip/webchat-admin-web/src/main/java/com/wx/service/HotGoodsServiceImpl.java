package com.wx.service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.wx.config.Constants;
import com.wx.ecShopDomain.EsGoods;
import com.wx.ecShopDomain.EsGoodsExample;
import com.wx.ecShopMapper.EsGoodsMapper;
import com.wx.exception.ServiceErrorException;
import com.wx.mobileDomain.MHotGoods;
import com.wx.mobileDomain.MHotGoodsExample;
import com.wx.mobileMapper.MHotGoodsMapper;
import com.wx.util.CommonUtil;
import com.wx.util.JedisUtil;
import com.wx.vo.HotGoodsJson;
import com.wx.vo.PageListData;
import com.wx.web.form.BaseIdsForm;
import com.wx.web.form.HotGoodsFormAdd;
import com.wx.web.form.HotGoodsFormFind;
import com.wx.web.form.HotGoodsUpdateSqForm;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by jh on 2015/11/27.
 */
@Component
public class HotGoodsServiceImpl implements HotGoodsService{

    private static Logger logger = LoggerFactory.getLogger(HotGoodsServiceImpl.class);

    @Autowired
    private EsGoodsMapper esGoodsMapper;

    @Autowired
    private MHotGoodsMapper mHotGoodsMapper;

    @Override
    public PageListData<EsGoods> list(HotGoodsFormFind form) {
        EsGoodsExample esGoodsExample = new EsGoodsExample();
        EsGoodsExample.Criteria criteria = esGoodsExample.createCriteria();
        criteria.andAliveEqualTo(1l);//查询上架商品
        if(form.getGoodsId() != null){
            criteria.andGoodsIdEqualTo(form.getGoodsId());
        } else if(!StringUtils.isBlank(form.getGoodsName())){
            criteria.andGoodsNameLike("%" + form.getGoodsName() + "%");
        }

        esGoodsExample.or(criteria);
        Page<EsGoods> page = PageHelper.startPage(form.getPageNo(), form.getPageSize());
        esGoodsMapper.selectByExampleWithBLOBs(esGoodsExample);
        PageListData<EsGoods> result = new PageListData<EsGoods>();
        result.setList(page.getResult());
        result.setCountAll(page.getTotal());
        return result;
    }

    @Override
    public void save(HotGoodsFormAdd form) throws ServiceErrorException{
        MHotGoodsExample example = new MHotGoodsExample();
        example.or().andGoodsIdEqualTo(form.getGoodsId());

        if(mHotGoodsMapper.countByExample(example) > 0){
            throw new ServiceErrorException("该商品已存在，不能重复添加!");
        }

        MHotGoods mHotGoods = new MHotGoods();
        mHotGoods.setGoodsTitle(form.getGoodsTitle());
        mHotGoods.setImage(form.getImage());
        mHotGoods.setGoodsId(form.getGoodsId());
        mHotGoods.setSequence(form.getSequence());
        mHotGoods.setCreateTime(new Date());
        mHotGoods.setIsOpen(form.getIsOpen());// 0 表示关闭，1表示开启
        mHotGoodsMapper.insert(mHotGoods);

        syncHotGoodsToRedis();
    }

    @Override
    public MHotGoods load(Long id) {

        MHotGoods mHotGoods = mHotGoodsMapper.selectByPrimaryKey(id);
        return mHotGoods;
    }

    @Override
    public void update(HotGoodsFormAdd form) {
        MHotGoodsExample example = new MHotGoodsExample();
        MHotGoods mHotGoods = new MHotGoods();
        mHotGoods.setGoodsTitle(form.getGoodsTitle());
        mHotGoods.setGoodsId(form.getGoodsId());
        mHotGoods.setImage(form.getImage());
        mHotGoods.setSequence(form.getSequence());
        mHotGoods.setTs(new Date());
        mHotGoods.setIsOpen(form.getIsOpen());// 0 表示关闭，1表示开启
        mHotGoodsMapper.updateByPrimaryKey(mHotGoods);

        syncHotGoodsToRedis();
    }

    @Override
    public void delete(BaseIdsForm form) {
        MHotGoodsExample example = new MHotGoodsExample();
        example.or().andIdIn(form.getIds());
        mHotGoodsMapper.deleteByExample(example);

        syncHotGoodsToRedis();
    }

    @Override
    public void delete(Long id) {
        mHotGoodsMapper.deleteByPrimaryKey(id);

        syncHotGoodsToRedis();
    }

    @Override
    public PageListData<MHotGoods> listHotGoods(Integer pageNo, Integer pageSize) {
        MHotGoodsExample example = new MHotGoodsExample();
        example.setOrderByClause("sequence desc");
        Page<MHotGoods> page = PageHelper.startPage(pageNo, pageSize);
        mHotGoodsMapper.selectByExample(example);
        PageListData<MHotGoods> result = new PageListData<MHotGoods>();
        result.setList(page.getResult());
        result.setCountAll(page.getTotal());
        return result;
    }

    @Override
    public void open(Long id) {
        MHotGoods mHotGoods =load(id);
        if(mHotGoods.getIsOpen().equals("1")){
            mHotGoods.setIsOpen("0");
        }else {
            mHotGoods.setIsOpen("1");
        }
        mHotGoods.setTs(new Date());
        mHotGoodsMapper.updateByPrimaryKey(mHotGoods);

        syncHotGoodsToRedis();
    }

    @Override
    public void updateSequence(HotGoodsUpdateSqForm form) {
        MHotGoods mHotGoods =load(form.getId());
        mHotGoods.setSequence(form.getSequence());
        mHotGoods.setTs(new Date());
        mHotGoodsMapper.updateByPrimaryKey(mHotGoods);

        syncHotGoodsToRedis();
    }

    /**
     * 同步热销商品至redis
     */
    private void syncHotGoodsToRedis(){
        Jedis jedis = null;
        //1.查询未禁用的热销商品，并按权重降序排序
        List<Map<String,Object>> orderedHotGoods =  mHotGoodsMapper.getOrderedList();
        try{
            jedis = JedisUtil.getInstance().getJedis(Constants.REDIS_DB_3);
            jedis.del(Constants.Key_HomePage_HotGoods);

            for(Map<String,Object> hotGoods : orderedHotGoods){
                String goodsId = hotGoods.get("goodsId")!=null?hotGoods.get("goodsId").toString():"";
                String image = hotGoods.get("image")!=null?hotGoods.get("image").toString():"";
                String isOpen = hotGoods.get("isOpen")!=null?hotGoods.get("isOpen").toString():"";
                HotGoodsJson hotGoodsJson = new HotGoodsJson(goodsId,image,isOpen);
                String hotGoodsJsonStr = CommonUtil.ObjectToJSON(hotGoodsJson);
                jedis.rpush(Constants.Key_HomePage_HotGoods, hotGoodsJsonStr);
            }
        }catch(Exception e){
            logger.error("syncHotGoodsToRedis方法同步热销商品至redis异常"+e.getMessage(),e);
        }finally {
            JedisUtil.getInstance().destroy(jedis);
        }

    }
}
