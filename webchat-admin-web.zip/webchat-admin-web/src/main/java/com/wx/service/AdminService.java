package com.wx.service;

import com.wx.domain.AuthLoginLog;
import com.wx.exception.DataFiledErrorException;
import com.wx.exception.ServiceErrorException;
import com.wx.vo.AdminLoginSign;

/**
 * 管理员接口
 * @author jiahuijie
 *
 */
public interface AdminService {

	/**
	 * 管理员登陆
	 * @param username
	 * @param password
	 * @return
	 * @throws DataFiledErrorException
	 * @throws ServiceErrorException
	 */
	AdminLoginSign login(String username, String password) throws DataFiledErrorException;

	/**
	 * 管理员登陆日志记录
	 * @param log
	 */
	void loginLog(AuthLoginLog log);
	
	
	/**
	 * 修改密码
	 * @param id 用户id
	 * @param oldPassword 旧密码
	 * @param newPassword 新密码
	 * @throws DataFiledErrorException
	 */
	void updatePassword(Long id, String oldPassword, String newPassword) throws DataFiledErrorException;
}
