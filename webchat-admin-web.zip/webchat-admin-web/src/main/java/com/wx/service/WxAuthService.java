package com.wx.service;

import java.util.List;

import com.wx.domain.WxAuth;
import com.wx.exception.ServiceErrorException;
import com.wx.vo.PageListData;

/**
 * 微信授权管理接口
 * @author jiahuijie
 *
 */
public interface WxAuthService {

	/**
	 * 增加授权
	 * @param auth
	 * @throws ServiceErrorException
	 */
	void addAuth(WxAuth auth) throws ServiceErrorException;
	
	/**
	 * 删除授权
	 * @param id
	 */
	void removeAuth(Long id);
	
	/**
	 * 删除授权
	 * @param ids
	 */
	void removeAuth(List<Long> ids);
	
	/**
	 * 加载指定id数据
	 * @param id
	 * @return
	 */
	WxAuth loadById(Long id);
	
	/**
	 * 分页查询
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	PageListData<WxAuth> list(int pageNo, int pageSize);
	
	/**
	 * 修改配置
	 * @param auth
	 */
	void updateAuth(WxAuth auth) throws ServiceErrorException;

	/**
	 * 检查授权
	 * @param appid
	 * @throws ServiceErrorException
	 */
	WxAuth loadByAppId(String appid);
	
	
	/**
	 * 检查授权
	 * @param appid
	 * @param timestamp
	 * @param nonce
	 * @param signature
	 * @throws ServiceErrorException
	 */
	boolean check(String appid, String timestamp, String nonce, String signature) throws ServiceErrorException;
}
