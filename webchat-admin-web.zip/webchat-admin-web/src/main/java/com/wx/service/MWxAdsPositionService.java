package com.wx.service;

import com.wx.exception.ServiceErrorException;
import com.wx.mobileDomain.MWxAdsPosition;
import com.wx.vo.PageListData;

import java.util.List;

/**
 * Created by jiahuijie on 2015/11/25.
 */
public interface MWxAdsPositionService {

    /**
     * 增加
     * @param mWxAdsPosition
     * @throws ServiceErrorException
     */
    void add(MWxAdsPosition mWxAdsPosition) throws ServiceErrorException;

    /**
     * 删除
     * @param id
     */
    void remove(Long id);

    /**
     * 删除
     * @param ids
     */
    void remove(List<Long> ids);

    /**
     * 加载指定id数据
     * @param id
     * @return
     */
    MWxAdsPosition loadById(Long id);

    /**
     * 分页查询
     * @param pageNo
     * @param pageSize
     * @return
     */
    public PageListData<MWxAdsPosition> list(int pageNo, int pageSize);

    /**
     * 修改配置
     * @param mWxAdsPosition
     */
    void update(MWxAdsPosition mWxAdsPosition) throws ServiceErrorException;
}
