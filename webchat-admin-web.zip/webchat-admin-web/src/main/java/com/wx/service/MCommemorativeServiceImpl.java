package com.wx.service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.wx.mobileDomain.MCommemorativeGoods;
import com.wx.mobileDomain.MCommemorativeGoodsExample;
import com.wx.mobileMapper.MCommemorativeGoodsMapper;
import com.wx.vo.PageListData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * Created by jh on 2016/1/6.
 */
@Component
public class MCommemorativeServiceImpl implements MCommemorativeService {

    @Autowired
    private MCommemorativeGoodsMapper mCommemorativeGoodsMapper;

    @Transactional
    @Override
    public void add(MCommemorativeGoods mCommemorativeGoods) {
        Date date = new Date();
        mCommemorativeGoods.setCreateTime(date);
        mCommemorativeGoods.setTs(date);
        mCommemorativeGoodsMapper.insert(mCommemorativeGoods);
    }

    @Transactional
    @Override
    public void remove(Long id) {
        mCommemorativeGoodsMapper.deleteByPrimaryKey(id);
    }

    @Transactional
    @Override
    public void remove(List<Long> ids) {
        MCommemorativeGoodsExample mCommemorativeGoodsExample = new MCommemorativeGoodsExample();
        mCommemorativeGoodsExample.or().andIdIn(ids);
        mCommemorativeGoodsMapper.deleteByExample(mCommemorativeGoodsExample);
    }

    @Transactional
    @Override
    public void update(MCommemorativeGoods mCommemorativeGoods) {
        Date date = new Date();
        mCommemorativeGoods.setCreateTime(date);
        mCommemorativeGoods.setTs(date);
        mCommemorativeGoodsMapper.updateByPrimaryKey(mCommemorativeGoods);

    }

    @Override
    public MCommemorativeGoods loadById(Long id) {
        return mCommemorativeGoodsMapper.selectByPrimaryKey(id);
    }

    @Override
    public PageListData<MCommemorativeGoods> list(Long kindId, int pageNo, int pageSize) {
        MCommemorativeGoodsExample mCommemorativeGoodsExample = new MCommemorativeGoodsExample();
        if (kindId !=null){
            mCommemorativeGoodsExample.or().andKindIdEqualTo(kindId);
        }else {
            mCommemorativeGoodsExample.or().andKindIdIsNull();
        }
        mCommemorativeGoodsExample.setOrderByClause("sequence desc");

        Page<MCommemorativeGoods> page = PageHelper.startPage(pageNo, pageSize);
        mCommemorativeGoodsMapper.selectByExample(mCommemorativeGoodsExample);

        PageListData<MCommemorativeGoods> pageListData = new PageListData<MCommemorativeGoods>();
        pageListData.setCountAll(page.getTotal());
        pageListData.setList(page.getResult());

        return pageListData;
    }
}
