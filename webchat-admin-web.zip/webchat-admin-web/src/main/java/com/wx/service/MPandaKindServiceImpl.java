package com.wx.service;

import com.wx.config.Constants;
import com.wx.mobileDomain.MPandaKind;
import com.wx.mobileDomain.MPandaKindExample;
import com.wx.exception.ServiceErrorException;
import com.wx.mapper.WxCallbackMapper;
import com.wx.mobileMapper.MPandaKindMapper;
import com.wx.util.CommonUtil;
import com.wx.util.JedisUtil;
import com.wx.vo.HotGoodsJson;
import com.wx.vo.PandaKindJson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import redis.clients.jedis.Jedis;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 熊猫币频道业务
 * @author jiahuijie
 *
 */
@Service
public class MPandaKindServiceImpl implements MPandaKindService {

	private static Logger logger = LoggerFactory.getLogger(HotGoodsServiceImpl.class);

	@Autowired
	private MPandaKindMapper pandaKindMapper;

	@Autowired
	private WxCallbackMapper wxCallbackMapper;

	@Autowired
	private WxCallbackService wxCallbackService;

	@Transactional
	@Override
	public void add(MPandaKind pandaKind) throws ServiceErrorException{

		MPandaKindExample example = new MPandaKindExample();

		if (pandaKind.getParentId() != null){
			MPandaKind parent = pandaKindMapper.selectByPrimaryKey(pandaKind.getParentId());
			if (parent == null)
				throw new ServiceErrorException("父菜单不存在");//父节点不存在

			pandaKind.setLevel(parent.getLevel() + 1);
			pandaKind.setTreeStruct((parent.getTreeStruct() == null ? "" + parent.getId() : parent.getTreeStruct() + "," + parent.getId()));
		} else {
			pandaKind.setParentId(null);
			pandaKind.setTreeStruct(null);
			pandaKind.setLevel(1);
		}

		if(pandaKind.getLevel() > 2){
			throw new ServiceErrorException("菜单最多支持二级");//菜单最多支持2级
		}

		example.clear();
		MPandaKindExample.Criteria criteria = example.or();
		criteria.andNameEqualTo(pandaKind.getName());
		if (pandaKind.getParentId() != null)
			criteria.andParentIdEqualTo(pandaKind.getParentId());
		else
			criteria.andParentIdIsNull();

		if (pandaKindMapper.countByExample(example) > 0){
			throw new ServiceErrorException("菜单已存在");//分类已存在
		}

		example.clear();
		example.or().andLevelEqualTo(pandaKind.getLevel());

		example.clear();
		MPandaKindExample.Criteria criteria2 = example.or();
		criteria.andLevelEqualTo(pandaKind.getLevel());
		if (pandaKind.getParentId() != null)
			criteria2.andParentIdEqualTo(pandaKind.getParentId());
		else
			criteria2.andParentIdIsNull();
		
		Date date = new Date();
		pandaKind.setIsNode(false);
		pandaKind.setCreateTime(date);
		pandaKind.setTs(date);
		
		pandaKindMapper.insert(pandaKind);

		syncPandaKindToRedis();
	}
	
	@Transactional
	@Override
	public void remove(Long id) throws ServiceErrorException{
		MPandaKindExample example = new MPandaKindExample();
		
		MPandaKind pandaKind = pandaKindMapper.selectByPrimaryKey(id);
		if (pandaKind == null){
			throw new ServiceErrorException("菜单不存在");
		}
		
		example.clear();
		example.or().andParentIdEqualTo(id);
		if (pandaKindMapper.countByExample(example) > 0){
			throw new ServiceErrorException("当前菜单下有子菜单");
		}
		
		pandaKindMapper.deleteByPrimaryKey(id);

		syncPandaKindToRedis();
	}
	
	@Transactional
	@Override
	public void update(MPandaKind pandaKind) throws ServiceErrorException{
		pandaKindMapper.updateByPrimaryKeySelective(pandaKind);

		syncPandaKindToRedis();
	}
	
	@Override
	public MPandaKind load(Long id) {
		return pandaKindMapper.selectByPrimaryKey(id);
	}
	
	@Override
	public List<MPandaKind> loadMenu() {
		MPandaKindExample example = new MPandaKindExample();
		return pandaKindMapper.selectByExample(example);
	}

	/**
	 * 同步熊猫币商品种类至redis
	 */
	private void syncPandaKindToRedis(){

		Jedis jedis = null;
		//1.查询熊猫币商品种类，并按权重降序排序
		List<Map<String,Object>> pandaKindList = pandaKindMapper.getOrderedList();
		try{
			jedis = JedisUtil.getInstance().getJedis(Constants.REDIS_DB_3);
			jedis.del(Constants.Key_PandaKind);

			for(Map<String,Object> pandaKind : pandaKindList){
				String id = pandaKind.get("id")!=null?pandaKind.get("id").toString():"";
				String title = pandaKind.get("title")!=null?pandaKind.get("title").toString():"";
				PandaKindJson pandaKindJson = new PandaKindJson(id,title);
				String pandaKindJsonStr = CommonUtil.ObjectToJSON(pandaKindJson);
				jedis.rpush(Constants.Key_PandaKind, pandaKindJsonStr);
			}
		}catch(Exception e){
			logger.error("syncPandaKindToRedis方法同步熊猫币种类至redis异常"+e.getMessage(),e);
		}finally {
			JedisUtil.getInstance().destroy(jedis);
		}
	}
}
