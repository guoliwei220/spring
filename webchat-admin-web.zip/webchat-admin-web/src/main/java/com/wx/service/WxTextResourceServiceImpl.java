package com.wx.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wx.domain.WxResourceText;
import com.wx.mapper.WxResourceTextMapper;

/**
 * 微信文本回复实现
 * @author jiahuijie
 *
 */
@Service
public class WxTextResourceServiceImpl implements WxTextResourceService{

	@Autowired
	private WxResourceTextMapper wxResourceTextMapper;

	@Transactional
	@Override
	public Long add(String text) {
		WxResourceText wxText = new WxResourceText();
		Date date = new Date();
		wxText.setContent(text);
		wxText.setCreateTime(date);
		wxText.setUpdateTime(date);
		wxResourceTextMapper.insert(wxText);
		return wxText.getId();
	}

	@Override
	public WxResourceText loadById(Long id) {
		return wxResourceTextMapper.selectByPrimaryKey(id);
	}
	

	

}
