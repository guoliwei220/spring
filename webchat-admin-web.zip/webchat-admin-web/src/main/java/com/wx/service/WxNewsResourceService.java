package com.wx.service;

import java.util.List;

import com.wx.domain.WxResourceNews;
import com.wx.vo.PageListData;

/**
 * 微信新闻资源接口
 * @author jiahuijie
 *
 */
public interface WxNewsResourceService {

	/**
	 * 添加新闻资源
	 * @param callback
	 * @param wxResourceNews
	 */
	public void add(WxResourceNews wxResourceNews);
	
	/**
	 * 删除新闻资源
	 * @param id
	 */
	void remove(Long id);
	
	/**
	 * 批量删除新闻资源
	 * @param ids
	 */
	void remove(List<Long> ids);
	
	/**
	 * 修改新闻回复
	 * @param callback
	 * @param wxResourceNews
	 */
	public void update(WxResourceNews wxResourceNews);
	
	/**
	 * 通过id加载
	 * @param id
	 * @return
	 */
	public WxResourceNews loadById(Long id);
	
	/**
	 * 分页查询
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public PageListData<WxResourceNews> list(int pageNo, int pageSize);
}
