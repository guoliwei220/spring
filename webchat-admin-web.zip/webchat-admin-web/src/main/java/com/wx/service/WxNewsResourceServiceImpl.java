package com.wx.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wx.domain.WxResourceNews;
import com.wx.domain.WxResourceNewsExample;
import com.wx.mapper.WxResourceNewsMapper;
import com.wx.vo.PageListData;

/**
 * 微信新闻回复实现
 * @author jiahuijie
 *
 */
@Service
public class WxNewsResourceServiceImpl implements WxNewsResourceService{

	@Autowired
	private WxResourceNewsMapper wxResourceNewsMapper;

	@Transactional
	@Override
	public void add(WxResourceNews wxResourceNews) {
		Date date = new Date();
		wxResourceNews.setCreateTime(date);
		wxResourceNews.setUpdateTime(date);
		wxResourceNewsMapper.insert(wxResourceNews);
	}
	
	@Transactional
	@Override
	public void update(WxResourceNews wxResourceNews) {
		Date date = new Date();
		wxResourceNews.setCreateTime(date);
		wxResourceNews.setUpdateTime(date);
		wxResourceNewsMapper.updateByPrimaryKey(wxResourceNews);
	}

	@Override
	public WxResourceNews loadById(Long id) {
		return wxResourceNewsMapper.selectByPrimaryKey(id);
	}
	

	@Override
	public PageListData<WxResourceNews> list(int pageNo, int pageSize) {
		WxResourceNewsExample wxResourceNewsExample = new WxResourceNewsExample();
		wxResourceNewsExample.setLimitStart((pageNo - 1) * pageSize);
		wxResourceNewsExample.setLimitEnd(pageSize);
		wxResourceNewsExample.setOrderByClause("id desc");
		List<WxResourceNews> list = wxResourceNewsMapper.selectByExample(wxResourceNewsExample);
		
		wxResourceNewsExample.clear();
		long count = wxResourceNewsMapper.countByExample(wxResourceNewsExample);
		
		PageListData<WxResourceNews> result = new PageListData<WxResourceNews>();
		result.setList(list);
		result.setCountAll(count);
		return result;
	}

	@Transactional
	@Override
	public void remove(Long id) {
		wxResourceNewsMapper.deleteByPrimaryKey(id);
	}

	@Transactional
	@Override
	public void remove(List<Long> ids) {
		WxResourceNewsExample wxResourceNewsExample = new WxResourceNewsExample();
		wxResourceNewsExample.or().andIdIn(ids);
		wxResourceNewsMapper.deleteByExample(wxResourceNewsExample);
	}
}
