package com.wx.service;

import java.util.List;

import com.wx.domain.WxCallback;

/**
 * 微信自动回复接口
 * @author jiahuijie
 *
 */
public interface WxCallbackService {

	/**
	 * 添加回复
	 * @param callback
	 */
	public void add(WxCallback wxCallback);
	
	/**
	 * 通过回复id查询资源
	 * @param id
	 * @return
	 */
	public Object loadResourceByCallbackId(Long id);
	
	/**
	 * 通过场景查询资源
	 * @param scene
	 * @return
	 */
	public Object loadResourceByScence(String scene);
	
	/**
	 * 通过btnKey查询资源
	 * @param btnKey
	 * @return
	 */
	public Object loadResourceByBtnKey(String btnKey);
	
	/**
	 * 通过words查询资源
	 * @param words
	 * @return
	 */
	public Object loadResourceByWords(String words);
	
	
	/**
	 * 关键词分页
	 * @return
	 */
	public List<WxCallback> listForWords();
	
	/**
	 * 加载回复
	 * @return
	 */
	public WxCallback loadCallbackByBtnKey(String btnKey);
	
	/**
	 * 加载回复
	 * @return
	 */
	public WxCallback loadCallbackByScene(String scene);
	
	
	/**
	 * 删除某种自动回复
	 * @param scene
	 */
	public void removeByScene(String scene);
	
	/**
	 * 根据id删除自动回复
	 * @param id
	 */
	public void removeById(Long id);
}
