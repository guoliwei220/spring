package com.wx.service;

import com.wx.mobileDomain.MPandaGoods;
import com.wx.vo.PageListData;

import java.util.List;

/**
 * 熊猫币业务层
 * @author jiahuijie
 *
 */
public interface MPandaGoodsService {
	
	public void add(MPandaGoods mPandaGoods);
	
	void remove(Long id);
	
	void remove(List<Long> ids);
	
	public void update(MPandaGoods mPandaGoods);
	
	public MPandaGoods loadById(Long id);
	
	public PageListData<MPandaGoods> list(Long kindId, int pageNo, int pageSize);
}
