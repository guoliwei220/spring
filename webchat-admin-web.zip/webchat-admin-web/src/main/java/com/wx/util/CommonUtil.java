package com.wx.util;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wx.vo.SimpleTreeNode;
import com.wx.vo.TreeNode;
import com.wx.vo.WxTreeNode;
public class CommonUtil {
	
	private static ObjectMapper objectMapper = new ObjectMapper();    
	
	private static final String[] valCodeChars = { "0","1", "2", "3", "4", "5",
		"6", "7", "8", "9","q", "w","e", "r", "t", "y", "u", "i", "p", "a", 
		"s", "d", "f","h","j", "k", "l", "z", "x", "c", "v", "b", "n", "m" };

	
	private static String Encrypt(String strSrc,String encName) {
		MessageDigest md = null;
		String strDes = null;
		
		byte[] bt = strSrc.getBytes();
		try {
                if (encName == null || encName.equals("")) {
                    encName="MD5";
                }
				md = MessageDigest.getInstance(encName);
				md.update(bt);
		        strDes = bytes2Hex(md.digest());  //to HexString
		} catch (NoSuchAlgorithmException e) {
			return null;
		}
		return strDes;
	}
	
	
	private static String bytes2Hex(byte[]bts) {
		String hs="";
	     String stmp="";
	     for (int n=0; n < bts.length; n++){
	         stmp=(java.lang.Integer.toHexString(bts[n] & 0xFF));
	         if (stmp.length()==1) hs=hs+"0"+stmp;
	             else hs=hs+stmp;
	     }
	     return hs;
	}

	public static String getRandomStr(int length){
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < length; i++) {
			sb.append(valCodeChars[(int)(Math.random() * valCodeChars.length)]);
		}
		return sb.toString();
	}
	
	/**
	 * MD5加密
	 * @param str
	 * @return
	 */
	public static String MD5(String str){
		return Encrypt(str, "MD5");
	}
	
	/**
	 * SHA1加密
	 * @param str
	 * @return
	 */
	public static String SHA1(String str){
		return Encrypt(str, "SHA-1");
	}
	
	/**
	 * SHA256加密
	 * @param str
	 * @return
	 */
	public static String SHA256(String str){
		return Encrypt(str, "SHA-256");
	}
	


	/**
	 * BASE64 编码  
	 * @param str
	 * @return
	 */
	@SuppressWarnings("restriction")
	public static String BASE64Encode(String str) {
		if (str == null) 
			return null;
		return (new sun.misc.BASE64Encoder()).encode(str.getBytes());
	}  

  
	/**
	 * BASE64解码  
	 * @param str
	 * @return
	 */
	@SuppressWarnings("restriction")
	public static String BASE64Decode(String str) {
		if (str == null) 
			return null;
		sun.misc.BASE64Decoder decoder = new sun.misc.BASE64Decoder(); 
		try {
			byte[] b = decoder.decodeBuffer(str);
			return new String(b);  
		} catch (IOException e) {
			return null;
		}
	} 
	
	
	/**
	 * 正则验证字符串
	 * @param regex 正则
	 * @param str 字符串
	 * @return
	 */
	public static boolean StringRegexVal(String regex, String str){
		if (Pattern.compile(regex).matcher(str).matches())
			return true;
		else
			return false;
	}
	
	/**
	 * 校验手机号
	 * @param str
	 * @return
	 */
	public static boolean checkPhone(String str){
		String regex = "^[0-9]{11}$";
		if (Pattern.compile(regex).matcher(str).matches())
			return true;
		else
			return false;
	}
	
	/**
	 * 校验邮箱
	 * @param str
	 * @return
	 */
	public static boolean checkEmail(String str){
		String regex = "^([a-zA-Z0-9_\\.\\-])+\\@(([a-zA-Z0-9\\-])+\\.)+([a-zA-Z0-9]{1,5})+$";
		if (Pattern.compile(regex).matcher(str).matches())
			return true;
		else
			return false;
	}
	
	/**
	 * 计算字符串长度，中文为两个字符长度
	 * @param str 字符串
	 * @return
	 */
	public static int StringCharLength(String str){
		Matcher matcher = Pattern.compile("\\u4e00-\\u9fa5").matcher(str);
		return matcher.groupCount() + str.length();
	}
	
	/**
	 * 产生验证码
	 * @param length 验证码位数
	 * @return
	 */
	public static String produceValCode(int length){
		
		StringBuffer msgCode = new StringBuffer();
		
		for (int i = 0; i < length; i++) {
			int a = (int) (Math.random() * valCodeChars.length);
			msgCode.append(valCodeChars[a]);
		}
		
		return msgCode.toString();	
	}
	
	
	/***
	 * 将时间按照指定格式字符串转换
	 * @param time 日期
	 * @param formatStr 格式化字符串
	 * @return 结果
	 */
	public static String DateFormat(String formatStr,Long time){
		return new SimpleDateFormat(formatStr).format(time);
	}
	
	/***
	 * 将时间按照指定格式字符串转换
	 * @param dateStr 日期
	 * @param formatStr 格式化字符串
	 * @return 结果
	 * @throws ParseException 
	 */
	public static Date DateFormat(String formatStr, String dateStr) throws ParseException{
		return new SimpleDateFormat(formatStr).parse(dateStr);
	}
	
	
	/**
	 * 格式化树
	 * @param node
	 * @param list
	 * @return
	 */
	public static <T> TreeNode<T> formatTree(TreeNode<T> node, List<TreeNode<T>> list){
		if (node.isRoot()) {
			if (node.getChildren() == null){
				node.setChildren(new ArrayList<TreeNode<T>>());
			}
			for (TreeNode<T> child : list) {
				if (child.getParentId() == null){
					node.getChildren().add(child);
					formatTree(child, list);
				}
			}
		} else {
			if (node.getChildren() == null){
				node.setChildren(new ArrayList<TreeNode<T>>());
			}
			for (TreeNode<T> child : list) {
				if (node.getId().equals(child.getParentId())) {
					node.getChildren().add(child);
					formatTree(child, list);
				}
			}
		}
		return node;
	}
	
	
	/**
	 * 格式化微信菜单树
	 * @param node
	 * @param list
	 * @return
	 */
	public static WxTreeNode formatWxTree(WxTreeNode node, List<WxTreeNode> list){
		if (node.isRoot()) {
			if (node.getSub_button() == null){
				node.setSub_button(new ArrayList<WxTreeNode>());
			}
			for (WxTreeNode child : list) {
				if (child.getParentId() == null){
					node.getSub_button().add(child);
					formatWxTree(child, list);
				}
			}
		} else {
			if (node.getSub_button() == null){
				node.setSub_button(new ArrayList<WxTreeNode>());
			}
			for (WxTreeNode child : list) {
				if (node.getId().equals(child.getParentId())) {
					node.getSub_button().add(child);
					formatWxTree(child, list);
				}
			}
		}
		return node;
	}
	
	
	/**
	 * 格式化简易树
	 * @param node
	 * @param list
	 * @return
	 */
	public static SimpleTreeNode formatSimpleTree(SimpleTreeNode node, List<SimpleTreeNode> list){
		
		if (node.isRoot()) {
			if (node.getChildren() == null){
				node.setChildren(new ArrayList<SimpleTreeNode>());
			}
			for (SimpleTreeNode child : list) {
				if (child.getParentId() == null){
					node.getChildren().add(child);
					formatSimpleTree(child, list);
				}
			}
		} else {
			if (node.getChildren() == null){
				node.setChildren(new ArrayList<SimpleTreeNode>());
			}
			for (SimpleTreeNode child : list) {
				if (node.getId().equals(child.getParentId())) {
					node.getChildren().add(child);
					formatSimpleTree(child, list);
				}
			}
		}
		
		return node;
	}
	
	/**
	 * 产生随机uuid路径
	 * @return
	 */
	public static String getRandomFilePath(){
		return UUID.randomUUID().toString().replaceAll("-", "") + "/";
	}
	
	/**
	 * 产生随机时间戳文件名路径
	 * @return
	 */
	public static String getRandomFileName(){
		return UUID.randomUUID().toString().replaceAll("-", "");
	}
	
	/**
	 * 补位
	 * @param sno
	 * @param length
	 * @return
	 */
	public static StringBuffer coverNumber(StringBuffer sno, int length){
		if (sno.length() >= length){
			return sno;
		}
		int coverLength = length - sno.length();
		for (int i = 0; i < coverLength; i++){
			sno.insert(0, '0');
		}
		
		return sno;
	}
	
	/**
	 * jsong字符串
	 * @param obj
	 * @return
	 */
	public static String ObjectToJSON(Object obj){
		try {
			return objectMapper.writeValueAsString(obj);
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 字符串转对象
	 * @param json
	 * @return
	 */
	public static JsonNode JSONToObject(String json){
		try {
			return objectMapper.readTree(json);
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 对象转map
	 * @param json
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static HashMap<String, Object> ObjectToMap(Object obj){
		try {
			return objectMapper.convertValue(obj, HashMap.class);
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 字符串转对象
	 * @param json
	 * @return
	 */
	public static JSONObject JSONToJSONObject(String json){
		try {
			return JSONObject.fromObject(json);
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 字符串转对象
	 * @param json
	 * @return
	 */
	public static JSONArray JSONToJSONArray(String json){
		try {
			return JSONArray.fromObject(json);
		} catch (Exception e) {
			return null;
		}
	}
}
