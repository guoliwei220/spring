package com.wx.util;

import java.util.LinkedHashMap;
import java.util.Map;

public class NBCacheUtil {

	/**
	 * 系统cache缓存堆栈
	 */
	private static Map<String, Object> cache = new LinkedHashMap<String, Object>();

	//私有构造，单利实现
	private NBCacheUtil(){
	}
	
	/**
	 * 设置缓存
	 * @param key
	 * @param value
	 */
	public static void set(String key, Object value){
		synchronized (NBCacheUtil.class) {
			cache.put(key, value);
		}
	}
	
	/**
	 * 删除缓存
	 * @param key
	 * @param value
	 */
	public static void remove(String key){
		synchronized (NBCacheUtil.class) {
			cache.remove(key);
		}
	}
	
	/**
	 * 获取缓存值
	 * @param key
	 * @return
	 */
	public static Object get(String key){
		return cache.get(key);
	}
	
	/**
	 * 检测是否存在该缓存
	 * @param key
	 * @return
	 */
	public static boolean containsKey(String key){
		return cache.containsKey(key);
	}
	
	/**
	 * 清空缓存
	 * @param key
	 * @param value
	 */
	public static void clear(){
		synchronized (NBCacheUtil.class) {
			cache.clear();
		}
	}
}
