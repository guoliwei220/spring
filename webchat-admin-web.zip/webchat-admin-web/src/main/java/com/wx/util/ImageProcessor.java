/***
 * 
 */
package com.wx.util;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.imageio.ImageIO;


/***
 * 图片处理类
 * @author jiahuijie
 *
 */
public class ImageProcessor {
	
	/***
	 * 私有构造 禁止实例化
	 */
	private ImageProcessor() {};
	
	/**
	 * 缩放图片
	 * @param oldFilePath 原图路径(包含图片名称的完整路径)
	 * @param newFilePath 新图路径(包含图片名称的完整路径)
	 * @param width 生成新图宽度
	 * @param height 生成新图高度
	 * @param fileType 图片类型 png,gif,jpg...
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public static void scaleImage(String oldFilePath, String newFilePath, 
			String newFileType, int targetW, int targetH,  boolean equalProportion) throws FileNotFoundException, IOException {
		
		BufferedImage srcImage = ImageIO.read(new File(oldFilePath));
		
		int type = srcImage.getType();
		
		BufferedImage newImage = null;
		
		double sx = (double)targetW / srcImage.getWidth();
		double sy = (double)targetH / srcImage.getHeight();
		
		//这里想实现在targetW，targetH范围内实现等比例的缩放
		//如果不需要等比例的缩放则下面的if else语句注释调即可
		if(equalProportion){
			if(sx>sy){
				sx=sy;
				targetW=(int)(sx * srcImage.getWidth());
			}else{
				sy=sx;
				targetH=(int)(sx * srcImage.getHeight());
			}
		}
		if(type == BufferedImage.TYPE_CUSTOM){
			ColorModel cm = srcImage.getColorModel();
			WritableRaster raster = cm.createCompatibleWritableRaster(targetW, targetH);
		    boolean alphaPremultiplied = cm.isAlphaPremultiplied();
		    newImage = new BufferedImage(cm, raster, alphaPremultiplied, null);
		}else{
			newImage = new BufferedImage(targetW, targetH, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = newImage.createGraphics();
			
			// 设置“抗锯齿”的属性  
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);  
			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);  
			
			g.drawImage(srcImage.getScaledInstance(targetW, targetH, Image.SCALE_SMOOTH), 0, 0, Color.WHITE, null);
			g.dispose();
		}
		
		OutputStream os = new FileOutputStream(new File(newFilePath));
		ImageIO.write(newImage, newFileType, os);
		os.close();
	}
	
	
	
	/**
	 * 缩放图片
	 * @param oldFilePath 原图路径(包含图片名称的完整路径)
	 * @param newFilePath 新图路径(包含图片名称的完整路径)
	 * @param width 生成新图宽度
	 * @param height 生成新图高度
	 * @param fileType 图片类型 png,gif,jpg...
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public static void scaleImage(String oldFilePath, OutputStream os, 
			String newFileType, int targetW, int targetH,  boolean equalProportion) throws FileNotFoundException, IOException {
		
		BufferedImage srcImage = ImageIO.read(new File(oldFilePath));
		
		int type = srcImage.getType();
		
		BufferedImage newImage = null;
		
		double sx = (double)targetW / srcImage.getWidth();
		double sy = (double)targetH / srcImage.getHeight();
		
		//这里想实现在targetW，targetH范围内实现等比例的缩放
		//如果不需要等比例的缩放则下面的if else语句注释调即可
		if(equalProportion){
			if(sx>sy){
				sx=sy;
				targetW=(int)(sx * srcImage.getWidth());
			}else{
				sy=sx;
				targetH=(int)(sx * srcImage.getHeight());
			}
		}
		if(type == BufferedImage.TYPE_CUSTOM){
			ColorModel cm = srcImage.getColorModel();
			WritableRaster raster = cm.createCompatibleWritableRaster(targetW, targetH);
		    boolean alphaPremultiplied = cm.isAlphaPremultiplied();
		    newImage = new BufferedImage(cm, raster, alphaPremultiplied, null);
		}else{
			newImage = new BufferedImage(targetW, targetH, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = newImage.createGraphics();
			
			// 设置“抗锯齿”的属性  
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);  
			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);  
			
			g.drawImage(srcImage.getScaledInstance(targetW, targetH, Image.SCALE_SMOOTH), 0, 0, Color.WHITE, null);
			g.dispose();
		}
		
		ImageIO.write(newImage, newFileType, os);
	}
	
	
	/**
	 * 缩放图片
	 * @param oldFilePath 原图路径(包含图片名称的完整路径)
	 * @param newFilePath 新图路径(包含图片名称的完整路径)
	 * @param width 生成新图宽度
	 * @param height 生成新图高度
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	public static void scaleImage(String oldFilePath, String newFilePath, int targetW, int targetH,  boolean equalProportion) throws FileNotFoundException, IOException {
		
		BufferedImage srcImage = ImageIO.read(new File(oldFilePath));
		
		int type = srcImage.getType();
		String typeStr = oldFilePath.substring(oldFilePath.lastIndexOf(".") + 1);
		
		BufferedImage newImage = null;
		
		double sx = (double)targetW / srcImage.getWidth();
		double sy = (double)targetH / srcImage.getHeight();
		
		//这里想实现在targetW，targetH范围内实现等比例的缩放
		//如果不需要等比例的缩放则下面的if else语句注释调即可
		if(equalProportion){
			if(sx>sy){
				sx=sy;
				targetW=(int)(sx * srcImage.getWidth());
			}else{
				sy=sx;
				targetH=(int)(sx * srcImage.getHeight());
			}
		}
		if(type == BufferedImage.TYPE_CUSTOM){
			ColorModel cm = srcImage.getColorModel();
			WritableRaster raster = cm.createCompatibleWritableRaster(targetW, targetH);
		    boolean alphaPremultiplied = cm.isAlphaPremultiplied();
		    newImage = new BufferedImage(cm, raster, alphaPremultiplied, null);
		}else{
			newImage = new BufferedImage(targetW, targetH, type);
			Graphics2D g = newImage.createGraphics();
			
			// 设置“抗锯齿”的属性  
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);  
			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);  
			
			g.drawImage(srcImage.getScaledInstance(targetW, targetH, Image.SCALE_SMOOTH), 0, 0, Color.WHITE, null);
			g.dispose();
		}
		
		OutputStream os = new FileOutputStream(new File(newFilePath));
		ImageIO.write(newImage, typeStr, os);
		os.close();
	}
	
	
	/**
	 * 截取图片
	 * @param oldFilePath 原图路径(包含图片名称的完整路径)
	 * @param newFilePath 新图路径(包含图片名称的完整路径)
	 * @param x 截取x坐标
	 * @param y 截取y坐标
	 * @param width 截取宽度
	 * @param height 截取高度
	 * @throws IOException 
	 */
	public static void clipImage(String oldFilePath, String newFilePath, 
			int x, int y, int width, int height) throws IOException{
		
		BufferedImage srcImage = ImageIO.read(new File(oldFilePath));
		
		int type = srcImage.getType();
		String typeStr = oldFilePath.substring(oldFilePath.lastIndexOf(".") + 1);
		
		BufferedImage newImage = null;
		
		if(type == BufferedImage.TYPE_CUSTOM){
			ColorModel cm = srcImage.getColorModel();
			WritableRaster raster = cm.createCompatibleWritableRaster(width, height);
		    boolean alphaPremultiplied = cm.isAlphaPremultiplied();
		    newImage = new BufferedImage(cm, raster, alphaPremultiplied, null);
		} else {
			newImage = new BufferedImage(width, height, type);
			Graphics2D g = newImage.createGraphics();
			
			// 设置“抗锯齿”的属性  
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);  
			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);  
			
			g.drawImage(srcImage.getSubimage(x, y, width, height), 0, 0, Color.WHITE, null);
			g.dispose();
		}
		
		OutputStream os = new FileOutputStream(new File(newFilePath));
		ImageIO.write(newImage, typeStr, os);
		os.close();
	}
	
	
	/**
	 * 截取图片
	 * @param oldFilePath 原图路径(包含图片名称的完整路径)
	 * @param newFilePath 新图路径(包含图片名称的完整路径)
	 * @param x 截取x坐标
	 * @param y 截取y坐标
	 * @param width 截取宽度
	 * @param height 截取高度
	 * @throws IOException 
	 */
	public static void clipImage(String oldFilePath, String newFilePath, String newType,
			int x, int y, int width, int height) throws IOException{
		
		BufferedImage srcImage = ImageIO.read(new File(oldFilePath));
		
		int type = srcImage.getType();
		
		BufferedImage newImage = null;
		
		if(type == BufferedImage.TYPE_CUSTOM){
			ColorModel cm = srcImage.getColorModel();
			WritableRaster raster = cm.createCompatibleWritableRaster(width, height);
		    boolean alphaPremultiplied = cm.isAlphaPremultiplied();
		    newImage = new BufferedImage(cm, raster, alphaPremultiplied, null);
		} else {
			newImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = newImage.createGraphics();
			
			// 设置“抗锯齿”的属性  
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);  
			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
			
			g.drawImage(srcImage.getSubimage(x, y, width, height), 0, 0, Color.WHITE, null);
			g.dispose();
		}
		
		OutputStream os = new FileOutputStream(new File(newFilePath));
		ImageIO.write(newImage, newType, os);
		os.close();
	}
//	
//	/***
//	 * 给图片添加水印
//	 * @param oldFilePath 源图片地址
//	 * @param newFilePath 新图片地址
//	 * @param sealFilePath 水印图片地址
//	 */
//	public static void sealImage(String oldFilePath, String newFilePath,
//			String sealFilePath){
//		
//		try {
//			//读取原图
//			Image oldImage = ImageIO.read(new File(oldFilePath));
//			//获取原宽度
//			int oldWidth = oldImage.getWidth(null);
//			//获取原高度
//			int oldHeight = oldImage.getHeight(null);
//			
//			//读取水印
//			Image sealImage = ImageIO.read(new File(sealFilePath));
//			//获取水印宽度
//			int sealWidth = sealImage.getWidth(null);
//			//获取水印高度
//			int sealHeight = sealImage.getHeight(null);
//			
//			//创建新图
//			BufferedImage newBufferedImage = new BufferedImage(oldWidth,
//					oldHeight, BufferedImage.TYPE_INT_RGB);
//			
//			//绘制新图
//			newBufferedImage.getGraphics().drawImage(oldImage, 0, 0, null);
//			newBufferedImage.getGraphics().drawImage(sealImage,
//					oldWidth-sealWidth, oldHeight-sealHeight, null);
//			
//			newBufferedImage.getGraphics().dispose();
//			
//			// 生成新图片
//			FileOutputStream newimage = new FileOutputStream(newFilePath);
//			JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(newimage);
//
//			//压缩质量 
//			//JPEGEncodeParam jep = 
//			//JPEGCodec.getDefaultJPEGEncodeParam(newBufferedImage);
//			//jep.setQuality(per, true);
//			//encoder.encode(tag, jep);
//			
//			encoder.encode(newBufferedImage);
//			
//			// 近JPEG编码
//			newimage.close();
//			
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
}
