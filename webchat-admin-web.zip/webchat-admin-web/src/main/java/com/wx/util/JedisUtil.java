package com.wx.util;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisSentinelPool;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @FileName: JedisUtil 此类注入的是新的redis哨兵
 * @Version: 1.0
 * @Author: beishuai
 * @Date: 2016/5/24 16:32
 */
public class JedisUtil {

    private static Logger log = LoggerFactory.getLogger(JedisUtil.class);

    private static JedisSentinelPool jedisSentinelPool;

    /**
     * 默认超时时间
     */
    private static final Integer DEFAULT_SINGLE_EXPIRE_TIME = 10;


    @Resource(name = "jedisSentinelPool")
    public void setJedisSentinelPool(JedisSentinelPool jedisSentinelPool) {
        JedisUtil.jedisSentinelPool = jedisSentinelPool;
    }

    private JedisUtil() {
    }

    public static JedisUtil getInstance() {
        return jedisUtil;
    }

    private static JedisUtil jedisUtil = new JedisUtil();

    /**
     * 获取redis连接
     * @param dbNum 选库
     * @return jedis连接
     */
    public Jedis getJedis(int dbNum) {
        Jedis jedis = null;
        try {
            jedis = jedisSentinelPool.getResource();
            jedis.select(dbNum);
        } catch (Exception e) {
            //e.printStackTrace();
            log.error("JedisUtil 获取redis连接异常" + e.getMessage(), e);
        }
        return jedis;
    }

    /**
     * 关闭jedis连接
     * @param jedis
     */
    public void destroy(Jedis jedis) {
        try {
            if (jedis != null) {
                jedis.close();
            }
        } catch (Exception e) {
            log.error("JedisUtil 关闭jedis连接异常" + e.getMessage(), e);
        }
    }

    /**
    * 获取redis库中的string值 get
    * @param dbNum 选库
    * @param key
    * @return 返回 key 的值，如果 key 不存在时，返回 nil。 如果 key 不是字符串类型，那么返回一个错误。
    */
    public static String get(int dbNum, String key) {
        String returnValue = null;
        Jedis jedis = null;
        try {
            jedis = getInstance().getJedis(dbNum);
            returnValue = jedis.get(key);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("JedisUtil get方法异常" + e.getMessage(), e);
        } finally {
            getInstance().destroy(jedis);
        }
        return returnValue;
    }

    /**
    * 向redis库中存入string值 set
    * @param dbNum 选库
    * @param key
    * @param value
    * @param time 失效时间（单位秒）：0不失效，>0 time秒后失效
    * @return 操作成功返回OK
    */
    public static String set(int dbNum, String key, String value, int time) {
        Jedis jedis = null;
        String result = null;
        try {
            jedis = getInstance().getJedis(dbNum);
            result = jedis.set(key, value);
            //添加失效时间 单位秒，失效时间要大于0
            if(time > 0){
                jedis.expire(key,time);
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("JedisUtil set方法异常" + e.getMessage(), e);
        } finally {
            getInstance().destroy(jedis);
        }
        return result;
    }

    /**
    * 删除redis库中的值
    * @param dbNum 选库
    * @param key
    * @return 被删除 key 的数量
    */
    public static Long del(int dbNum, String key) {
        Jedis jedis = null;
        Long result = null;
        try {
            jedis = getInstance().getJedis(dbNum);
            result = jedis.del(key);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("JedisUtil del方法异常" + e.getMessage(), e);
        } finally {
            getInstance().destroy(jedis);
        }
        return result;
    }

    /**
     * redis库中是否存在key
     * @param dbNum 选库
     * @param key
     * @return true存在，false不存在
     */
    public static boolean exists(int dbNum, String key) {
        Jedis jedis = null;
        boolean result = false;
        try {
            jedis = getInstance().getJedis(dbNum);
            result = jedis.exists(key);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("JedisUtil exists方法异常" + e.getMessage(), e);
        } finally {
            getInstance().destroy(jedis);
        }
        return result;
    }


    /**
     * 从Redis库中，将一个或多个值插入到列表的尾部(最右边)。
     * @param dbNum 选库
     * @param key
     * @return 执行 RPUSH 操作后，列表的长度
     */
    public static Long rpush(int dbNum, String key, String value) {
        Jedis jedis = null;
        Long result = null;
        try {
            jedis = getInstance().getJedis(dbNum);
            result = jedis.rpush(key, value);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("JedisUtil rpush方法异常" + e.getMessage(), e);
        } finally {
            getInstance().destroy(jedis);
        }
        return result;
    }
    /**
     * 从Redis库中获取List数据
     * 其中 0 表示列表的第一个元素， 1 表示列表的第二个元素，以此类推。
     * 你也可以使用负数下标，以 -1 表示列表的最后一个元素， -2 表示列表的倒数第二个元素，以此类推。
     * @param dbNum 选库
     * @param key
     * @param start 开始
     * @param end 结束
     * @return 一个列表，包含指定区间内的元素
     */
    public static List<String> lrange(int dbNum, String key, int start, int end) {
        Jedis jedis = null;
        List<String> result = null;
        try {
            jedis = getInstance().getJedis(dbNum);
            result = jedis.lrange(key, start, end);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("JedisUtil lrange方法异常" + e.getMessage(), e);
        } finally {
            getInstance().destroy(jedis);
        }
        return result;
    }

    /**
     * 从Redis库中获取Hash所有数据key和value
     * @param dbNum 选库
     * @param key
     * @return 返回哈希表的字段及字段值。 若 key 不存在，返回空。
     */
    public static Map<String, String> hgetAll(int dbNum, String key) {
        Jedis jedis = null;
        Map<String, String> result = null;
        try {
            jedis = getInstance().getJedis(dbNum);
            result = jedis.hgetAll(key);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("JedisUtil hgetAll方法异常" + e.getMessage(), e);
        } finally {
            getInstance().destroy(jedis);
        }
        return result;
    }

    /**
     * 从Redis库中获取Hash某个字段的值
     * @param dbNum 选库
     * @param key
     * @param field 字段名
     * @return 返回给定字段的值。如果给定的字段或 key 不存在时，返回 nil 。
     */
    public static String hget(int dbNum, String key, String field) {
        Jedis jedis = null;
        String result = null;
        try {
            jedis = getInstance().getJedis(dbNum);
            result = jedis.hget(key, field);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("JedisUtil hget方法异常" + e.getMessage(), e);
        } finally {
            getInstance().destroy(jedis);
        }
        return result;
    }

    /**
    * 从redis 库 设置指定 key 的值，并返回 key 旧的值。
    * @param dbNum 选库
    * @param key
    * @param value
    * @return 返回给定 key 的旧值。 当 key 没有旧值时，即 key 不存在时，返回 nil 。
    * 当 key 存在但不是字符串类型时，返回一个错误。
    */
    public static String getSet(int dbNum, String key, String value) {
        String returnValue = null;
        Jedis jedis = null;
        try {
            jedis = getInstance().getJedis(dbNum);
            returnValue = jedis.getSet(key, value);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("JedisUtil getset方法异常" + e.getMessage(), e);
        } finally {
            getInstance().destroy(jedis);
        }
        return returnValue;
    }

}
