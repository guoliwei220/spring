package com.wx.config;


public class Constants {
	
	/**
	 * 服务器域名
	 */
	public static final String KEY_SERVER = "server";
	
	/**
	 * 图片服务器key
	 */
	public static final String KEY_IMG_SERVER = "img_server";
	
	/**
	 * 服务器域
	 */
	public static final String KEY_SERVER_DOMAIN = "server_domain";
	
	/**
	 * 文件基路径
	 */
	public static final String KEY_FILE_UPLOAD_BASE_DIR = "file_upload_base_dir";
	
	/**
	 * 图片缓存目录
	 */
	public static final String KEY_IMG_CACHE_BASE_DIR = "img_cache_base_dir";
	
	/**
	 * 用户上传路径
	 */
	public static final String USER_DIR = "user_dir";
	
	/**
	 * 内容传路径
	 */
	public static final String CMS_DIR = "cms_dir";
	
	/**
	 * 权限资源路径
	 */
	public static final String AUTH_DIR = "auth_dir";
	
	
	/**
	 * 微信通知模板id
	 */
	public static final String WX_NOTICE_TMP_ID = "wx_notice_tmp_id";


	/**
	 * 首页热销商品key
	 * 类型：List
	 */
	public static final  String Key_HomePage_HotGoods = "m_hot_goods";

	/**
	 * 首页轮播广告位key
	 * 类型：String
	 */
	public static final  String Key_HomePage_AdsPosition_Slide = "index1";

	/**
	 * 首页普通广告位key
	 * 类型：String
	 */
	public static final  String Key_HomePage_AdsPosition_Normal = "index2";

	/**
	 * 熊猫币频道轮播广告位key
	 * 类型：String
	 */
	public static final  String Key_PandaPage_AdsPosition_Slide = "pandaIndex1";

	/**
	 * 纪念币频道普通广告位key
	 * 类型：String
	 */
	public static final  String Key_MemoryPage_AdsPosition_Normal = "commemorativeList";
	/**
	 * 纪念币频道轮播广告位key
	 * 类型：String
	 */
	public static final  String Key_MemoryPage_AdsPosition_Slide = "commemorativeIndex1";


	/**
	 * 首页轮播广告key
	 * 类型:List
	 */
	public static final  String Key_HomePage_Ads_Slide = "m_wx_ads_index1";

	/**
	 * 首页广告key
	 * 类型:List
	 */
	public static final  String Key_HomePage_Ads_Normal = "m_wx_ads_index2";

	/**
	 * 熊猫币频道轮播广告key
	 * 类型:List
	 */
	public static final  String Key_PandaPage_Ads_Slide = "m_wx_ads_pandaIndex1";

	/**
	 * 纪念币频道广告key
	 * 类型:List
	 */
	public static final  String Key_MemoryPage_Ads_Normal = "m_wx_ads_commemorativeList";

	/**
	 * 纪念币频道轮播广告key
	 * 类型:List
	 */
	public static final  String Key_MemoryPage_Ads_Slide = "m_wx_ads_commemorativeIndex1";

	/**
	 * 熊猫币商品种类列表key
	 * 类型:List
	 */
	public static final  String Key_PandaKind = "m_panda_kind";

	/**
	 * 熊猫币商品key前缀
	 *
	 */
	public static  final String Key_Prefix_PandaGoods = "m_panda_goods_";

	//redis数据库
	//db0:临时数据等
	public static final int REDIS_DB_0 = 0;
	//db1:系统参数等
	public static final int REDIS_DB_1 = 1;
	//db3:微信数据
	public static final int REDIS_DB_3 = 3;
	//db6:商品数据
	public static final int REDIS_DB_6 = 6;
	//db8:会员数据
	public static final int REDIS_DB_8 = 8;
}
