app.controller('pandaCtr', ['$scope','$state','$http','$timeout', function($scope,$state,$http,$timeout) {

    var setting = {
        view: {
            dblClickExpand: true,
            showLine: true,
            selectedMulti: false
        },
        data: {
            simpleData: {
                enable:true,
                idKey: "id",
                pIdKey: "parentId",
                rootPId: null
            },
            key: {
                name: "label"
            }
        },
        callback: {
            beforeClick: function(treeId, treeNode) {
                $scope.$apply(function(){
                    $scope.selectMenuNode = treeNode;
                    $scope.pageData.params = {kindId: treeNode.id};
                    $scope.paginationConf.onChange = function(){
                        loadPageData();
                    }
                    loadPageData();
                });
            }
        }
    };

    var zNodes = [];
    var t = $("#tree");
    var zTree;

    $http.get(app.api.host + app.api.operating.pandaKindList)
        .success(function(data,status,header,config){
            if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                $.toaster({priority : 'error', title : '提示', message :data.msg});
            } else if (data.code == '000000'){
                zNodes = data.data.root;
                t = $.fn.zTree.init(t, setting, zNodes);
                zTree = $.fn.zTree.getZTreeObj("tree");
            }
        });

    //导向添加菜单
    $scope.toAddMenu = function(isSecond){

        if (!isSecond){

            $scope.addFormWin = {
                formTitle : "添加一级菜单"
            };

            $scope.addMenuForm = {};
        } else {

            if ($scope.selectMenuNode == null){
                $.toaster({priority : 'error', title : '提示', message :'请先选择一个节点'});
                return;
            }

            $scope.addFormWin = {
                formTitle : "添加 " + $scope.selectMenuNode.label + " 的子菜单"
            };

            $scope.addMenuForm = {
                name:"",
                title:"",
                parentId: $scope.selectMenuNode.id
            };
        }

        $("#addMenuWindow").modal('show');
    }

    //添加菜单
    $scope.addMenu = function(){
        $http.post(app.api.host + app.api.operating.pandaKindAdd, $scope.addMenuForm)
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $.toaster({priority : 'success', title : '提示', message : '操作成功'});
                    $("#addMenuWindow").modal('hide');

                    if ($scope.addMenuForm.parentId == null){
                        zTree.addNodes(null, data.data.node);
                    } else {
                        zTree.addNodes($scope.selectMenuNode, data.data.node);
                    }
                }
            });
    }

    //导向修改菜单
    $scope.toUpdateMenu = function(){

        if ($scope.selectMenuNode == null){
            $.toaster({priority : 'error', title : '提示', message :'请先选择一个系列'});
            return;
        }

        if (!$scope.selectMenuNode.parentid){
            $scope.updateFormWin = {
            };

        } else {
            $scope.updateFormWin = {
            };
        }


        $http.get(app.api.host + app.api.operating.pandaKindUpdate,{params:{id: $scope.selectMenuNode.id}})
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $scope.updateMenuForm = {
                        id: data.data.mPandaKind.id,
                        name:  data.data.mPandaKind.name,
                        parentId:  data.data.mPandaKind.parentId,
                        title:  data.data.mPandaKind.title
                    };

                    $("#updateMenuWindow").modal('show');
                }
            });
    }

    //修改菜单
    $scope.updateMenu = function(){
        $http.post(app.api.host + app.api.operating.pandaKindUpdate,$scope.updateMenuForm)
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $.toaster({priority : 'success', title : '提示', message : '操作成功'});
                    $("#updateMenuWindow").modal('hide');

                    delete data.data.node.children;
                    $.extend($scope.selectMenuNode, data.data.node);
                    zTree.updateNode($scope.selectMenuNode);
                }
            });
    }

    //删除菜单
    $scope.delMenu = function(){

        if ($scope.selectMenuNode == null){
            $.toaster({priority : 'error', title : '提示', message :'请先选择一个系列'});
            return;
        }

        $.messager.confirm("提示", "你确定要删除吗", function() {
            $http.post(app.api.host + app.api.operating.pandaKindDel,{id:$scope.selectMenuNode.id})
                .success(function(data,status,header,config){
                    if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                        $.toaster({priority : 'error', title : '提示', message :data.msg});
                    } else if (data.code == '000000'){
                        $.toaster({priority : 'success', title : '提示', message : '操作成功'});

                        var temp = $scope.selectMenuNode.getParentNode();
                        zTree.removeNode($scope.selectMenuNode);
                        $scope.selectMenuNode = null;
                        if (temp != null){
                            zTree.selectNode(temp);
                        } else {
                            zTree.selectNode(zTree.getNodes()[0]);
                        }
                    }
                });
        });
    }















    $scope.pageData = {
        api:app.api.host + app.api.operating.pandaGoodsList,
        list:[],
        checkModel:{selectAll:false,datas:[]},
        params:{}
    };


    //页码栏初始化
    $scope.paginationConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 20,
        pagesLength: 15,
        perPageOptions: [10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function(){
            if ($scope.selectMenuNode != null)
                loadPageData();
        }
    };

    //加载分页数据
    var loadPageData = function(){

        var params = {
            'pageSize' : $scope.paginationConf.itemsPerPage,
            'pageNo' : $scope.paginationConf.currentPage
        };

        params = $.extend({},params,$scope.pageData.params);

        $http.get($scope.pageData.api,{params:params})
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $scope.pageData.list = data.data.list;
                    $scope.paginationConf.totalItems = data.data.countAll;
                    $scope.pageData.checkModel.selectAll = false;
                    $scope.pageData.checkModel.datas = [];
                    $.each(data.data.list,function(i,n){
                        $scope.pageData.checkModel.datas.push(false);
                    });
                }
            });
    }

    //删除商品
    $scope.delGoods = function(id){

        $.messager.confirm("提示", "你确定要删除吗", function() {
            $http.post(app.api.host + app.api.operating.pandaGoodsDel,{id:id})
                .success(function(data,status,header,config){
                    if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                        $.toaster({priority : 'error', title : '提示', message :data.msg});
                    } else if (data.code == '000000'){
                        $.toaster({priority : 'success', title : '提示', message :'操作成功'});
                        loadPageData();
                    }
                });
        });
    }


    //导向修改权重
    $scope.toUpdateGoodsSequence = function(id){

        $http.get(app.api.host + app.api.operating.pandaGoodsUpdate,{params:{id: id}})
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $scope.updateGoodsForm = data.data.mPandaGoods;
                    $("#goodsSequenceWindow").modal('show');
                }
            });
    }

    //修改权重
    $scope.updateGoodsSequence = function(){

        $http.post(app.api.host + app.api.operating.pandaGoodsUpdate, $scope.updateGoodsForm)
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $("#goodsSequenceWindow").modal('hide');
                    $.toaster({priority : 'success', title : '提示', message :'操作成功'});
                    loadPageData();
                }
            });
    }


    //批量删除
    $scope.delsGoods = function(){

        var ids = [];
        $.each($scope.pageData.checkModel.datas,function(i,n){
            if (n){
                ids.push($scope.pageData.list[i].id);
            }
        });

        if (ids.length <= 0){
            $.toaster({priority : 'error', title : '提示', message : '当前没有选择数据！'});
            return;
        }

        $.messager.confirm("提示", "你确定要删除吗", function() {
            $http.post(app.api.host + app.api.operating.pandaGoodsDels,{ids:ids})
                .success(function(data,status,header,config){
                    if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                        $.toaster({priority : 'error', title : '提示', message :data.msg});
                    } else if (data.code == '000000'){
                        $.toaster({priority : 'success', title : '提示', message :'操作成功'});
                        loadPageData();
                    }
                });
        });
    }



    //全选
    $scope.selectAllGoods = function(){
        $scope.pageData.checkModel.selectAll = true;
        $.each($scope.pageData.checkModel.datas,function(i,n){
            $scope.pageData.checkModel.datas[i] = true;
        });
    }

    //反选
    $scope.selectTurnAllGoods = function(){
        var isSelectAll = true;
        $.each($scope.pageData.checkModel.datas,function(i,n){
            $scope.pageData.checkModel.datas[i] = !n;
            if (n){
                isSelectAll = false;
            }
        });
        $scope.pageData.checkModel.selectAll = isSelectAll;
    }

    //取消选择
    $scope.selectCancelGoods = function(){
        $scope.pageData.checkModel.selectAll = false;
        $.each($scope.pageData.checkModel.datas,function(i,n){
            $scope.pageData.checkModel.datas[i] = false;
        });
    }

    //选择
    $scope.checkBoxSelectAllGoods = function(){
        if ($scope.pageData.checkModel.selectAll){
            $scope.selectAllGoods();
        } else {
            $scope.selectCancelGoods();
        }
    }

    //单选
    $scope.checkBoxSelectGoods = function(i){
        var isSelectAll = true;
        $.each($scope.pageData.checkModel.datas,function(i,n){
            if (!n){
                isSelectAll = false;
                return false;
            }
        });
        $scope.pageData.checkModel.selectAll = isSelectAll;
    }

















    $scope.hotGoodsPageData = {
        api:app.api.host + app.api.operating.goodsFind,
        list:[],
        params:{goodsId: '', goodsName: ''}
    };

    //页码栏初始化
    $scope.hotGoodsPaginationConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 5,
        pagesLength: 15,
        perPageOptions: [5, 10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function(){
            hotGoodsLoadPageData();
        }
    };

    //加载分页数据
    var hotGoodsLoadPageData = function(){

        var params = {
            'pageSize' : $scope.hotGoodsPaginationConf.itemsPerPage,
            'pageNo' : $scope.hotGoodsPaginationConf.currentPage
        };

        params = $.extend({},params,$scope.hotGoodsPageData.params);

        $http.get($scope.hotGoodsPageData.api,{params:params})
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $scope.hotGoodsPageData.list = data.data.list;
                    $scope.hotGoodsPaginationConf.totalItems = data.data.countAll;
                }
            });
    }

    //搜索商品
    $scope.findGoods = function(){
        hotGoodsLoadPageData();
    }



    //去增加商品
    $scope.toAddGoods = function(){

        if ($scope.selectMenuNode == null){
            $.toaster({priority : 'error', title : '提示', message :'请先选择一个系列'});
            return;
        }

        hotGoodsLoadPageData();
        $scope.addGoodsForm={}
        $("#addGoodsWindow").modal('show');
    }

    // 添加商品到右侧显示
    $scope.addGoods = function(esGoods){
        $scope.addGoodsForm={
            goodsTitle: esGoods.goodsName,
            image: esGoods.goodsImg,
            goodsId: esGoods.goodsId,
            kindId: $scope.selectMenuNode.id,
            shortDesc:'',
            sequence: 0
        };
    }

    //保存商品
    $scope.saveGoods = function(){
        $http.post(app.api.host + app.api.operating.pandaGoodsAdd, $scope.addGoodsForm)
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $.toaster({priority : 'success', title : '提示', message :'操作成功'});
                    $("#addGoodsWindow").modal('hide');
                    loadPageData();
                }
            });
    }
}]);