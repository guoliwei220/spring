app.controller('configCtr', ['$scope','$state','$http', function($scope,$state,$http) {
	
	$scope.wxConfigForm = {
			appKey:"",
			appSecret:"",
			token:""
	};
	
	//初始化加载参数
	$scope.init = function(){
		$http.get(app.api.host + app.api.base.getWxConfig)
        .success(function(data,status,header,config){
              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
				 $.toaster({priority : 'error', title : '提示', message :data.msg});
              } else if (data.code == '000000'){
            	  $scope.wxConfigForm = {
            				appKey:data.data.wxConfig.appid,
            				appSecret:data.data.wxConfig.appsecret,
            				token:data.data.wxConfig.token
            		};
              }
     });
	}
	$scope.init();
	
	$scope.submit = function(){
        $http.post(app.api.host + app.api.base.setWxConfig,$scope.wxConfigForm)
            .success(function(data,status,header,config){
                  if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
                  } else if (data.code == '000000'){
                	  $.toaster({priority : 'success', title : '提示', message : "操作成功！"});
                  }
         });
	}
	
}]);