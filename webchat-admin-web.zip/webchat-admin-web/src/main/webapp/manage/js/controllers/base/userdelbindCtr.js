app.controller('configCtr', ['$scope','$state','$http', function($scope,$state,$http) {
	
	$scope.wxUserBindForm = {
			phonenum:""
	};
	$scope.pageData = {
			api:"",
			list:[],
			checkModel:{selectAll:false,datas:[]},
			params:{}
		};
	$scope.submit = function(){
        $http.post(app.api.host + app.api.base.wxUserBind,$scope.wxUserBindForm)
            .success(function(data,status,header,config){
                  if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
                  } else if (data.code == '000000'){
                	  	$scope.pageData.list = data.data.list;
	            	  	$scope.pageData.checkModel.datas = [];
	            	  	$.each(data.data.list,function(i,n){
	            	  		$scope.pageData.checkModel.datas.push(false);
	            	  	});
                  }
         });
	}
	//删除
	$scope.del = function(id){
		if(confirm("确定解绑？"))
		 {
		$http.post(app.api.host + app.api.base.userDelBind,{openid:id})
	        .success(function(data,status,header,config){
	              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
	              } else if (data.code == '000000'){
	            	  $.toaster({priority : 'success', title : '提示', message :'操作成功'});
	            	  loadPageData();
	              }
	     });}
	}
}]);