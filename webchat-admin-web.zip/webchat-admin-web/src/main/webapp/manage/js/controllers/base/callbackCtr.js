app.controller('callbackCtr', ['$scope','$state','$http','$timeout','$element', function($scope,$state,$http,$timeout,$element) {
	
	//订阅资源
	$scope.subscribeResource = {
			type:null,
			val:null
	};
	
	$scope.initSubscribeCallbackTabFlag = false;
	
	//订阅面板初始化
	$scope.initSubscribeCallbackTab = function(){
		if (!$scope.initSubscribeCallbackTabFlag){
			$http.get(app.api.host + app.api.base.wxResourceLoad, {params:{scene: 'subscribe'}})
		    	.success(function(data,status,header,config){
		          if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
		          } else if (data.code == '000000'){
		        	  $scope.initSubscribeCallbackTabFlag = true;
		        	
		        	  if (!$.isEmptyObject(data.data)){
		        		  $scope.subscribeResource.type = data.data.type;
		        		  $scope.subscribeResource.val = data.data.resource;
		        	  }
		          }
		    });
		}
	}
	
	$scope.initSubscribeCallbackTab();
	
	//订阅回复
	$scope.addAttentionCallback = function(){
		$http.post(app.api.host + app.api.base.wxCallbackAdd, {scene: 'subscribe',resourceType: $scope.subscribeResource.type, resourceId: $scope.subscribeResource.val.id})
        	.success(function(data,status,header,config){
              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
				 $.toaster({priority : 'error', title : '提示', message :data.msg});
              } else if (data.code == '000000'){
            	  $.toaster({priority : 'success', title : '提示', message :data.msg});
              }
        });
	}
	
	//删除订阅
	$scope.clearAttentionCallback = function(){
		$http.post(app.api.host + app.api.base.wxCallbackDel, {scene: 'subscribe'})
        	.success(function(data,status,header,config){
              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
				 $.toaster({priority : 'error', title : '提示', message :data.msg});
              } else if (data.code == '000000'){
            	  $.toaster({priority : 'success', title : '提示', message :data.msg});
            	  $scope.subscribeResource.type = null;
        		  $scope.subscribeResource.val = null;
              }
        });
	}
	
	
	//全部回复
	$scope.callbackResource = {
			type:null,
			val:null
	};
	
	$scope.initCallbackTabFlag = false;
	
	//全部回复面板初始化
	$scope.initCallbackTab = function(){
		if (!$scope.initCallbackTabFlag){
			$http.get(app.api.host + app.api.base.wxResourceLoad, {params:{scene: 'callback'}})
		    	.success(function(data,status,header,config){
		          if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
		          } else if (data.code == '000000'){
		        	  $scope.initCallbackTabFlag = true;
		        	
		        	  if (!$.isEmptyObject(data.data)){
		        		  $scope.callbackResource.type = data.data.type;
		        		  $scope.callbackResource.val = data.data.resource;
		        	  }
		          }
		    });
		}
	}
	
	//全部回复
	$scope.addCallbackCallback = function(){
		$http.post(app.api.host + app.api.base.wxCallbackAdd, {scene: 'callback',resourceType: $scope.callbackResource.type, resourceId: $scope.callbackResource.val.id})
        	.success(function(data,status,header,config){
              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
				 $.toaster({priority : 'error', title : '提示', message :data.msg});
              } else if (data.code == '000000'){
            	  $.toaster({priority : 'success', title : '提示', message :data.msg});
              }
        });
	}
	
	//删除全部回复
	$scope.clearCallbackCallback = function(){
		$http.post(app.api.host + app.api.base.wxCallbackDel, {scene: 'callback'})
        	.success(function(data,status,header,config){
              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
				 $.toaster({priority : 'error', title : '提示', message :data.msg});
              } else if (data.code == '000000'){
            	  $.toaster({priority : 'success', title : '提示', message :data.msg});
            	  $scope.callbackResource.type = null;
        		  $scope.callbackResource.val = null;
              }
        });
	}
	
	
	
	
	
	
	
	$scope.wordCallbackResource = {
			type:null,
			val:null
	};
	
	//初始化关键词回复面板
	$scope.initWordCallbackTabFlag = false;
	$scope.callbackWordsList = [];
	$scope.editWordsCallbackFlag = true;
	$scope.selectNode = null;
	
	$scope.initWordCallbackTab = function(){
		
		if (!$scope.initWordCallbackTabFlag){
			
			$http.get(app.api.host + app.api.base.wxCallbackListForWords)
		    	.success(function(data,status,header,config){
		          if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
		          } else if (data.code == '000000'){
		        	  $scope.initWordCallbackTabFlag = true;
		        	  $scope.callbackWordsList = data.data.wxCallbacks;
		        	  $.each($scope.callbackWordsList, function(i,n){
		        		  n.words = n.words.split(' ');
		        	  });
		          }
		    });
			
		}
	}
	
	//选择回复
	$scope.selectCallbackWords = function(callback){
		$scope.editWordsCallbackFlag = true;
		
		$scope.selectNode = callback;
		
		$.extend($scope.wordCallbackResource, {
			type:null,
			val:null
		});
		
		if (callback.id){
			$http.get(app.api.host + app.api.base.wxResourceLoad, {params:{id:callback.resourceId, type:callback.resourceType}})
		    	.success(function(data,status,header,config){
		          if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
		          } else if (data.code == '000000'){
		        	  $scope.wordCallbackResource.type = data.data.type;
		        	  $scope.wordCallbackResource.val = data.data.resource;
		        	  
		        	  $scope.editWordsCallbackFlag = false;
		          }
	    	});
		} else {
			$scope.editWordsCallbackFlag = false;
		}
	}
	
	
	//添加新规则
	$scope.addWordsCallback = function(){
		var b = true;
		$.each($scope.callbackWordsList, function(i,n){
			if (n.id == null){
				 $.toaster({priority : 'warning', title : '提示', message :'[' + n.name + ']尚未保存'});
				 b = false;
				 return false;
			}
   	  	});
		
		if (b){
			$scope.callbackWordsList.push({
				name:'新规则',
				resourceId:null,
				resourceType:'',
				words:[]
			});
			
			$.extend($scope.wordCallbackResource, {
					type:null,
					val:null
			});
			
			$scope.selectCallbackWords($scope.callbackWordsList[$scope.callbackWordsList.length - 1]);
		}
	}
	
	//保存规则
	$scope.saveWordsCallback = function(){
		var params = {
				id: $scope.selectNode.id,
				scene: 'words',
				resourceType: $scope.wordCallbackResource.type, 
				resourceId: $scope.wordCallbackResource.val ? $scope.wordCallbackResource.val.id : null,
				words:$scope.selectNode.words,
				name: $scope.selectNode.name
		};
		
		if ($scope.wordCallbackResource.type == null){
			$.toaster({priority : 'error', title : '提示', message : "请选择回复内容"});
			return;
		}
		
		$http.post(app.api.host + app.api.base.wxCallbackAdd, params)
	    	.success(function(data,status,header,config){
	          if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
				 $.toaster({priority : 'error', title : '提示', message :data.msg});
	          } else if (data.code == '000000'){
	        	  $.toaster({priority : 'success', title : '提示', message :data.msg});
	        	  if (!$scope.selectNode.id){
	        		  var addPro = {
	        				  id:data.data.id,
	        				  resourceType: $scope.wordCallbackResource.type, 
	        				  resourceId: $scope.wordCallbackResource.val.id,
	        				  name: $scope.selectNode.name
	        		  };
	        		  $.extend($scope.callbackWordsList[$scope.callbackWordsList.length - 1], addPro);
	        		  $.extend($scope.selectNode, addPro);
	        	  }
	          }
    	});
	}
	
	//删除规则
	$scope.delWordsCallback = function(){
		$http.post(app.api.host + app.api.base.wxCallbackDel, {scene: 'words', id: $scope.selectNode.id})
	    	.success(function(data,status,header,config){
	          if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
				 $.toaster({priority : 'error', title : '提示', message :data.msg});
	          } else if (data.code == '000000'){
	        	$.toaster({priority : 'success', title : '提示', message :data.msg});
	        	  
	        	$scope.callbackWordsList = $.grep($scope.callbackWordsList, function(n,i){
								        		  if ($scope.selectNode == n)
								        			  return false;
								        		  return true;
								        	  });
	        	 
	        	$scope.selectNode = null;
	        	
      			$.extend($scope.wordCallbackResource, {
      					type:null,
      					val:null
      			});
      			
      			$scope.editWordsCallbackFlag = true;
	          }
	    });
	}
	
	//添加关键词
	$scope.addWord = function(e){
		if (e.key == "Enter"){
			if (e.target.value != ''){
				$scope.selectNode.words.push(e.target.value);
				e.target.value = '';
			}
		}
	}
	
	//删除关键词
	$scope.delWord = function(index){
		$scope.selectNode.words.splice(index,1);
	}
}]);