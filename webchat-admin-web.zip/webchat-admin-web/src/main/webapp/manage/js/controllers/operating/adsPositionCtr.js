app.controller('adsPositionCtr', ['$scope','$state','$http','$timeout', function($scope,$state,$http,$timeout) {
	
	$scope.pageData = {
		api:app.api.host + app.api.operating.mAdsPositionList,
		list:[],
		checkModel:{selectAll:false,datas:[]},
		params:{}
	};
	
	
	//页码栏初始化
	$scope.paginationConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 20,
        pagesLength: 15,
        perPageOptions: [10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function(){
        	loadPageData();
        }
    };
	
	//加载分页数据
	var loadPageData = function(){
		
		var params = {
			'pageSize' : $scope.paginationConf.itemsPerPage,
			'pageNo' : $scope.paginationConf.currentPage
		};
		
		params = $.extend({},params,$scope.pageData.params);
		
		$http.get($scope.pageData.api,{params:params})
	        .success(function(data,status,header,config){
	              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
	              } else if (data.code == '000000'){
	            	  	$scope.pageData.list = data.data.list;
	            	  	$scope.paginationConf.totalItems = data.data.countAll;
	            	  	$scope.pageData.checkModel.selectAll = false;
	            	  	$scope.pageData.checkModel.datas = [];
	            	  	$.each(data.data.list,function(i,n){
	            	  		$scope.pageData.checkModel.datas.push(false);
	            	  	});
	              }
	     });
	}












	//导向添加
	$scope.toAdd = function(){
		$scope.addForm = {
		};
		$("#addWindow").modal('show');
	}


	//添加
	$scope.add = function(){
		$http.post(app.api.host + app.api.operating.mAdsPositionAdd, $scope.addForm)
			.success(function(data,status,header,config){
				if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					$.toaster({priority : 'error', title : '提示', message :data.msg});
				} else if (data.code == '000000'){
					$.toaster({priority : 'success', title : '提示', message :'操作成功'});
					$("#addWindow").modal('hide');
					loadPageData();
				}
			});
	}

	//导向修改
	$scope.toUpdate = function(id){
		$http.get(app.api.host + app.api.operating.mAdsPositionUpdate, {params:{id:id}})
			.success(function(data,status,header,config){
				if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					$.toaster({priority : 'error', title : '提示', message :data.msg});
				} else if (data.code == '000000'){
					$scope.updateForm = data.data.wxAdsPosition;
					$("#updateWindow").modal('show');
				}
			});
	}

	//修改
	$scope.update = function(){
		$http.post(app.api.host + app.api.operating.mAdsPositionUpdate,$scope.updateForm)
			.success(function(data,status,header,config){
				if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					$.toaster({priority : 'error', title : '提示', message :data.msg});
				} else if (data.code == '000000'){
					$.toaster({priority : 'success', title : '提示', message :'操作成功'});
					$("#updateWindow").modal('hide');
					loadPageData();
				}
			});
	}

	//删除
	$scope.del = function(id){
		$http.post(app.api.host + app.api.operating.mAdsPositionDel,{id:id})
			.success(function(data,status,header,config){
				if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					$.toaster({priority : 'error', title : '提示', message :data.msg});
				} else if (data.code == '000000'){
					$.toaster({priority : 'success', title : '提示', message :'操作成功'});
					loadPageData();
				}
			});
	}


	//批量删除
	$scope.dels = function(){

		var ids = [];
		$.each($scope.pageData.checkModel.datas,function(i,n){
			if (n){
				ids.push($scope.pageData.list[i].id);
			}
		});

		if (ids.length <= 0){
			$.toaster({priority : 'error', title : '提示', message : '当前没有选择数据！'});
			return;
		}

		$http.post(app.api.host + app.api.operating.mAdsPositionDels,{ids:ids})
			.success(function(data,status,header,config){
				if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					$.toaster({priority : 'error', title : '提示', message :data.msg});
				} else if (data.code == '000000'){
					$.toaster({priority : 'success', title : '提示', message :'操作成功'});
					loadPageData();
				}
			});
	}

	











	//全选
	$scope.selectAll = function(){
		$scope.pageData.checkModel.selectAll = true;
		$.each($scope.pageData.checkModel.datas,function(i,n){
			$scope.pageData.checkModel.datas[i] = true;
		});
	}
	
	//反选
	$scope.selectTurnAll = function(){
		var isSelectAll = true;
		$.each($scope.pageData.checkModel.datas,function(i,n){
			$scope.pageData.checkModel.datas[i] = !n;
			if (n){
				isSelectAll = false;
			}
		});
		$scope.pageData.checkModel.selectAll = isSelectAll;
	}
	
	//取消选择
	$scope.selectCancel = function(){
		$scope.pageData.checkModel.selectAll = false;
		$.each($scope.pageData.checkModel.datas,function(i,n){
			$scope.pageData.checkModel.datas[i] = false;
		});
	}
	
	//选择
	$scope.checkBoxSelectAll = function(){
		if ($scope.pageData.checkModel.selectAll){
			$scope.selectAll();
		} else {
			$scope.selectCancel();
		}
	}

	//单选
	$scope.checkBoxSelect = function(i){
		var isSelectAll = true;
		$.each($scope.pageData.checkModel.datas,function(i,n){
			if (!n){
				isSelectAll = false;
				return false;
			}
		});
		$scope.pageData.checkModel.selectAll = isSelectAll;
	}
	
	
}]);