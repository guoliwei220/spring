app.controller('dashboardCtr', ['$scope','$state','$http', function($scope,$state,$http) {
	
}]);