app.controller('commemorativeCtr', ['$scope','$state','$http','$timeout','nbFileupload', function($scope,$state,$http,$timeout,nbFileupload) {

    var setting = {
        view: {
            dblClickExpand: true,
            showLine: true,
            selectedMulti: false
        },
        data: {
            simpleData: {
                enable:true,
                idKey: "id",
                pIdKey: "parentId",
                rootPId: null
            },
            key: {
                name: "label"
            }
        },
        callback: {
            beforeClick: function(treeId, treeNode) {
                $scope.$apply(function(){
                    $scope.selectMenuNode = treeNode;
                    $scope.pageData.params = {kindId: treeNode.id};
                    $scope.paginationConf.onChange = function(){
                        loadPageData();
                    }
                    loadPageData();
                });
            }
        }
    };

    var zNodes = [];
    var t = $("#tree");
    var zTree;

    $http.get(app.api.host + app.api.operating.commemorativeKindList)
        .success(function(data,status,header,config){
            if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                $.toaster({priority : 'error', title : '提示', message :data.msg});
            } else if (data.code == '000000'){
                zNodes = data.data.root;
                t = $.fn.zTree.init(t, setting, zNodes);
                zTree = $.fn.zTree.getZTreeObj("tree");
            }
        });


    //导向添加菜单
    $scope.toAddMenu = function(isSecond){

        if (!isSecond){

            $scope.addFormWin = {
                formTitle : "添加一级菜单"
            };

            $scope.addMenuForm = {};
        } else {

            if ($scope.selectMenuNode == null){
                $.toaster({priority : 'error', title : '提示', message :'请先选择一个节点'});
                return;
            }

            $scope.addFormWin = {
                formTitle : "添加 " + $scope.selectMenuNode.label + " 的子菜单"
            };

            $scope.addMenuForm = {
                name:"",
                image:"",
                parentId: $scope.selectMenuNode.id
            };
        }

        $("#addMenuWindow").modal('show');
    }

    //添加菜单
    $scope.addMenu = function(){
        $http.post(app.api.host + app.api.operating.commemorativeKindAdd, $scope.addMenuForm)
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $.toaster({priority : 'success', title : '提示', message : '操作成功'});
                    $("#addMenuWindow").modal('hide');

                }

                $scope.initSubscribeCallbackTab();

            });
    }

    //导向修改菜单
    $scope.toUpdateMenu = function(){

        if ($scope.selectMenuNode == null){
            $.toaster({priority : 'error', title : '提示', message :'请先选择一个系列'});
            return;
        }

        if (!$scope.selectMenuNode.parentid){
            $scope.updateFormWin = {
            };

        } else {
            $scope.updateFormWin = {
            };
        }


        $http.get(app.api.host + app.api.operating.commemorativeKindUpdate,{params:{id: $scope.selectMenuNode.id}})
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $scope.updateMenuForm = {
                        id: data.data.mCommemorativeKind.id,
                        name:  data.data.mCommemorativeKind.name,
                        parentId:  data.data.mCommemorativeKind.parentId,
                        image :  data.data.mCommemorativeKind.image
                    };

                    $("#updateMenuWindow").modal('show');
                }
            });
    }

    //修改菜单
    $scope.updateMenu = function(){
        $http.post(app.api.host + app.api.operating.commemorativeKindUpdate,$scope.updateMenuForm)
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $.toaster({priority : 'success', title : '提示', message : '操作成功'});
                    $("#updateMenuWindow").modal('hide');

                    delete data.data.node.children;
                    $.extend($scope.selectMenuNode, data.data.node);
                    $scope.initSubscribeCallbackTab();
                }
            });
    }

    //删除菜单
    $scope.delMenu = function(){

        if ($scope.selectMenuNode == null){
            $.toaster({priority : 'error', title : '提示', message :'请先选择一个系列'});
            return;
        }

        $.messager.confirm("提示", "你确定要删除吗", function() {
            $http.post(app.api.host + app.api.operating.commemorativeKindDel,{id:$scope.selectMenuNode.id})
                .success(function(data,status,header,config){
                    if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                        $.toaster({priority : 'error', title : '提示', message :data.msg});
                    } else if (data.code == '000000'){
                        $.toaster({priority : 'success', title : '提示', message : '操作成功'});

                        $scope.initSubscribeCallbackTab();
                    }
                });
        });
    }

    $scope.initSubscribeCallbackTab = function(){

        var setting = {
            view: {
                dblClickExpand: true,
                showLine: true,
                selectedMulti: false
            },
            data: {
                simpleData: {
                    enable:true,
                    idKey: "id",
                    pIdKey: "parentId",
                    rootPId: null
                },
                key: {
                    name: "label"
                }
            },
            callback: {
                beforeClick: function(treeId, treeNode) {
                    $scope.$apply(function(){
                        $scope.selectMenuNode = treeNode;
                        $scope.pageData.params = {kindId: treeNode.id};
                        $scope.paginationConf.onChange = function(){
                            loadPageData();
                        }
                        loadPageData();
                    });
                }
            }
        };

        var zNodes = [];
        var t = $("#tree");
        var zTree;

        $http.get(app.api.host + app.api.operating.commemorativeKindList)
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    zNodes = data.data.root;
                    t = $.fn.zTree.init(t, setting, zNodes);
                    zTree = $.fn.zTree.getZTreeObj("tree");
                }
            });
    }

    //初始化tab页面

    $timeout(function(){
        $scope.initSubscribeCallbackTab();
    },500);











    $scope.pageData = {
        api:app.api.host + app.api.operating.commemorativeGoodsList,
        list:[],
        checkModel:{selectAll:false,datas:[]},
        params:{}
    };


    //页码栏初始化
    $scope.paginationConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 20,
        pagesLength: 15,
        perPageOptions: [10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function(){
            if ($scope.selectMenuNode != null)
                loadPageData();
        }
    };

    //加载分页数据
    var loadPageData = function(){

        var params = {
            'pageSize' : $scope.paginationConf.itemsPerPage,
            'pageNo' : $scope.paginationConf.currentPage
        };

        params = $.extend({},params,$scope.pageData.params);

        $http.get($scope.pageData.api,{params:params})
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $scope.pageData.list = data.data.list;
                    $scope.paginationConf.totalItems = data.data.countAll;
                    $scope.pageData.checkModel.selectAll = false;
                    $scope.pageData.checkModel.datas = [];
                    $.each(data.data.list,function(i,n){
                        $scope.pageData.checkModel.datas.push(false);
                    });
                }
            });
    }

    //删除商品
    $scope.delGoods = function(id){

        $.messager.confirm("提示", "你确定要删除吗", function() {
            $http.post(app.api.host + app.api.operating.commemorativeGoodsDel,{id:id})
                .success(function(data,status,header,config){
                    if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                        $.toaster({priority : 'error', title : '提示', message :data.msg});
                    } else if (data.code == '000000'){
                        $.toaster({priority : 'success', title : '提示', message :'操作成功'});
                        loadPageData();
                    }
                });
        });
    }


    //导向修改权重
    $scope.toUpdateGoodsSequence = function(id){

        $http.get(app.api.host + app.api.operating.commemorativeGoodsUpdate,{params:{id: id}})
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $scope.updateGoodsForm = data.data.mCommemorativeGoods;
                    $("#goodsSequenceWindow").modal('show');
                }
            });
    }

    //修改权重
    $scope.updateGoodsSequence = function(){

        $http.post(app.api.host + app.api.operating.commemorativeGoodsUpdate, $scope.updateGoodsForm)
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $("#goodsSequenceWindow").modal('hide');
                    $.toaster({priority : 'success', title : '提示', message :'操作成功'});
                    loadPageData();
                }
            });
    }


    //批量删除
    $scope.delsGoods = function(){

        var ids = [];
        $.each($scope.pageData.checkModel.datas,function(i,n){
            if (n){
                ids.push($scope.pageData.list[i].id);
            }
        });

        if (ids.length <= 0){
            $.toaster({priority : 'error', title : '提示', message : '当前没有选择数据！'});
            return;
        }

        $.messager.confirm("提示", "你确定要删除吗", function() {
            $http.post(app.api.host + app.api.operating.commemorativeGoodsDels,{ids:ids})
                .success(function(data,status,header,config){
                    if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                        $.toaster({priority : 'error', title : '提示', message :data.msg});
                    } else if (data.code == '000000'){
                        $.toaster({priority : 'success', title : '提示', message :'操作成功'});
                        loadPageData();
                    }
                });
        });
    }



    //全选
    $scope.selectAllGoods = function(){
        $scope.pageData.checkModel.selectAll = true;
        $.each($scope.pageData.checkModel.datas,function(i,n){
            $scope.pageData.checkModel.datas[i] = true;
        });
    }

    //反选
    $scope.selectTurnAllGoods = function(){
        var isSelectAll = true;
        $.each($scope.pageData.checkModel.datas,function(i,n){
            $scope.pageData.checkModel.datas[i] = !n;
            if (n){
                isSelectAll = false;
            }
        });
        $scope.pageData.checkModel.selectAll = isSelectAll;
    }

    //取消选择
    $scope.selectCancelGoods = function(){
        $scope.pageData.checkModel.selectAll = false;
        $.each($scope.pageData.checkModel.datas,function(i,n){
            $scope.pageData.checkModel.datas[i] = false;
        });
    }

    //选择
    $scope.checkBoxSelectAllGoods = function(){
        if ($scope.pageData.checkModel.selectAll){
            $scope.selectAllGoods();
        } else {
            $scope.selectCancelGoods();
        }
    }

    //单选
    $scope.checkBoxSelectGoods = function(i){
        var isSelectAll = true;
        $.each($scope.pageData.checkModel.datas,function(i,n){
            if (!n){
                isSelectAll = false;
                return false;
            }
        });
        $scope.pageData.checkModel.selectAll = isSelectAll;
    }

















    $scope.hotGoodsPageData = {
        api:app.api.host + app.api.operating.goodsFind,
        list:[],
        params:{goodsId: '', goodsName: ''}
    };

    //页码栏初始化
    $scope.hotGoodsPaginationConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 5,
        pagesLength: 15,
        perPageOptions: [5, 10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function(){
            hotGoodsLoadPageData();
        }
    };

    //加载分页数据
    var hotGoodsLoadPageData = function(){

        var params = {
            'pageSize' : $scope.hotGoodsPaginationConf.itemsPerPage,
            'pageNo' : $scope.hotGoodsPaginationConf.currentPage
        };

        params = $.extend({},params,$scope.hotGoodsPageData.params);

        $http.get($scope.hotGoodsPageData.api,{params:params})
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $scope.hotGoodsPageData.list = data.data.list;
                    $scope.hotGoodsPaginationConf.totalItems = data.data.countAll;
                }
            });
    }

    //搜索商品
    $scope.findGoods = function(){
        hotGoodsLoadPageData();
    }



    //去增加商品
    $scope.toAddGoods = function(){

        if ($scope.selectMenuNode == null){
            $.toaster({priority : 'error', title : '提示', message :'请先选择一个系列'});
            return;
        }

        hotGoodsLoadPageData();
        $scope.addGoodsForm={}
        $("#addGoodsWindow").modal('show');
    }

    // 添加商品到右侧显示
    $scope.addGoods = function(esGoods){
        $scope.addGoodsForm={
            goodsTitle: esGoods.goodsName,
            image: esGoods.goodsImg,
            goodsId: esGoods.goodsId,
            kindId: $scope.selectMenuNode.id,
            sequence: 0
        };
    }

    //保存商品
    $scope.saveGoods = function(){
        $http.post(app.api.host + app.api.operating.commemorativeGoodsAdd, $scope.addGoodsForm)
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $.toaster({priority : 'success', title : '提示', message :'操作成功'});
                    $("#addGoodsWindow").modal('hide');
                    loadPageData();
                }
            });
    }

    //上传图片
    $scope.addUploadImg = function(){
        nbFileupload.start({
            url:app.api.host + app.api.upload.uploadcms,
            parentId:'addMenuWindow',
            params:{},
            maxFileSize:500*1024,
            maxFileNum:1,
            success:function(i,data){
                $scope.addMenuForm.image = data.data.imgUrl;
            },
            error:function(i,data){
                alert(data.msg);
            }
        });
    }

    $scope.uploadUploadImg = function(){
        nbFileupload.start({
            url:app.api.host + app.api.upload.uploadcms,
            parentId:'updateMenuWindow',
            params:{},
            maxFileSize:500*1024,
            maxFileNum:1,
            success:function(i,data){
                $scope.updateMenuForm.image = data.data.imgUrl;
            },
            error:function(i,data){
                alert(data.msg);
            }
        });
    }



    //纪念币热销商品管理=============================================================================

    $scope.pageCommemHotGoodsData = {
        api:app.api.host + app.api.operating.commemorativeHotGoodsList,
        list:[],
        checkModel:{selectAll:false,datas:[]},
        params:{}
    };


    //页码栏初始化
    $scope.paginationpageCommemHotGoodsConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 20,
        pagesLength: 15,
        perPageOptions: [10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function(){
            if ($scope.selectMenuNode != null)
                loadCommemHotGoodsPageData();
        }
    };

    //加载分页数据
    var loadCommemHotGoodsPageData = function(){

        var params = {
            'pageSize' : $scope.paginationpageCommemHotGoodsConf.itemsPerPage,
            'pageNo' : $scope.paginationpageCommemHotGoodsConf.currentPage
        };

        params = $.extend({},params,$scope.pageCommemHotGoodsData.params);

        $http.get($scope.pageCommemHotGoodsData.api,{params:params})
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $scope.pageCommemHotGoodsData.list = data.data.list;
                    $scope.paginationpageCommemHotGoodsConf.totalItems = data.data.countAll;
                    $scope.pageCommemHotGoodsData.checkModel.selectAll = false;
                    $scope.pageCommemHotGoodsData.checkModel.datas = [];
                    $.each(data.data.list,function(i,n){
                        $scope.pageCommemHotGoodsData.checkModel.datas.push(false);
                    });
                }
            });
    }

    //加载分页数据
    $scope.initCallbackCommemHotGoodsTab = function (){
       loadCommemHotGoodsPageData();
    }


    //去增加商品
    $scope.toAddCommemHotGoods = function(){
        hotGoodsLoadPageData();
        $scope.addGoodsForm={}
        $("#addCommemHotGoodsWindow").modal('show');
    }

// 添加商品到右侧显示
    $scope.addCommemHotGoods = function(esGoods){
        $scope.addCommemHotGoodsForm={
            goodsTitle: esGoods.goodsName,
            image: esGoods.goodsImg,
            goodsId: esGoods.goodsId,
            sequence: 0
        };
    }
    //保存商品
    $scope.saveCommemHotGoods = function(){
        $http.post(app.api.host + app.api.operating.commemorativeHotGoodsAdd, $scope.addCommemHotGoodsForm)
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $.toaster({priority : 'success', title : '提示', message :'操作成功'});
                    $("#addCommemHotGoodsWindow").modal('hide');
                    loadCommemHotGoodsPageData();
                }
            });
    }


    //删除商品
    $scope.delCommemHotGoods = function(id){

        $.messager.confirm("提示", "你确定要删除吗", function() {
            $http.post(app.api.host + app.api.operating.commemorativeHotGoodsDel,{id:id})
                .success(function(data,status,header,config){
                    if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                        $.toaster({priority : 'error', title : '提示', message :data.msg});
                    } else if (data.code == '000000'){
                        $.toaster({priority : 'success', title : '提示', message :'操作成功'});
                        loadCommemHotGoodsPageData();
                    }
                });
        });
    }


    //导向修改权重
    $scope.toUpdateCommemHotGoodsSequence = function(id){

        $http.get(app.api.host + app.api.operating.commemorativeHotGoodsUpdate,{params:{id: id}})
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $scope.updateCommemHotGoodsForm = data.data.mCommemorativeGoods;
                    $("#commemHotGoodsSequenceWindow").modal('show');
                }
            });
    }

    //修改权重
    $scope.updateCommemHotGoodsSequence = function(){

        $http.post(app.api.host + app.api.operating.commemorativeHotGoodsUpdate, $scope.updateCommemHotGoodsForm)
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $("#commemHotGoodsSequenceWindow").modal('hide');
                    $.toaster({priority : 'success', title : '提示', message :'操作成功'});
                    loadCommemHotGoodsPageData();
                }
            });
    }


    //批量删除
    $scope.delsCommemHotGoods = function(){

        var ids = [];
        $.each($scope.pageCommemHotGoodsData.checkModel.datas,function(i,n){
            if (n){
                ids.push($scope.pageCommemHotGoodsData.list[i].id);
            }
        });

        if (ids.length <= 0){
            $.toaster({priority : 'error', title : '提示', message : '当前没有选择数据！'});
            return;
        }

        $.messager.confirm("提示", "你确定要删除吗", function() {
            $http.post(app.api.host + app.api.operating.commemorativeHotGoodsDels,{ids:ids})
                .success(function(data,status,header,config){
                    if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                        $.toaster({priority : 'error', title : '提示', message :data.msg});
                    } else if (data.code == '000000'){
                        $.toaster({priority : 'success', title : '提示', message :'操作成功'});
                        loadPageData();
                    }
                });
        });
    }



    //全选
    $scope.selectAllCommemHotGoods = function(){
        $scope.pageCommemHotGoodsData.checkModel.selectAll = true;
        $.each($scope.pageCommemHotGoodsData.checkModel.datas,function(i,n){
            $scope.pageCommemHotGoodsData.checkModel.datas[i] = true;
        });
    }

    //反选
    $scope.selectTurnAllCommemHotGoods = function(){
        var isSelectAll = true;
        $.each($scope.pageCommemHotGoodsData.checkModel.datas,function(i,n){
            $scope.pageCommemHotGoodsData.checkModel.datas[i] = !n;
            if (n){
                isSelectAll = false;
            }
        });
        $scope.pageCommemHotGoodsData.checkModel.selectAll = isSelectAll;
    }

    //取消选择
    $scope.selectCancelCommemHotGoods = function(){
        $scope.pageCommemHotGoodsData.checkModel.selectAll = false;
        $.each($scope.pageCommemHotGoodsData.checkModel.datas,function(i,n){
            $scope.pageCommemHotGoodsData.checkModel.datas[i] = false;
        });
    }

    //选择
    $scope.checkBoxSelectAllCommemHotGoods = function(){
        if ($scope.pageCommemHotGoodsData.checkModel.selectAll){
            $scope.selectAllCommemHotGoods();
        } else {
            $scope.selectTurnAllCommemHotGoods();
        }
    }

    //单选
    $scope.checkBoxSelectCommemHotGoods = function(i){
        var isSelectAll = true;
        $.each($scope.pageCommemHotGoodsData.checkModel.datas,function(i,n){
            if (!n){
                isSelectAll = false;
                return false;
            }
        });
        $scope.pageCommemHotGoodsData.checkModel.selectAll = isSelectAll;
    }




}]);