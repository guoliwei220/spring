app.controller('msgCtr', ['$scope','$state','$http','$timeout', function($scope,$state,$http,$timeout) {
	
	$scope.pageData = {
		api:app.api.host + app.api.base.wxMsgList,
		list:[],
		checkModel:{selectAll:false,datas:[]},
		params:{}
	};
	
	
	//页码栏初始化
	$scope.paginationConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 20,
        pagesLength: 15,
        perPageOptions: [10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function(){
        	loadPageData();
        }
    };
	
	//加载分页数据
	var loadPageData = function(){
		
		var params = {
			'pageSize' : $scope.paginationConf.itemsPerPage,
			'pageNo' : $scope.paginationConf.currentPage
		};
		
		params = $.extend({},params,$scope.pageData.params);
		
		$http.get($scope.pageData.api,{params:params})
	        .success(function(data,status,header,config){
	              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
	              } else if (data.code == '000000'){
	            	  console.log(1111111111111);
	            	  	$scope.pageData.list = data.data.list;
	            	  	$scope.paginationConf.totalItems = data.data.countAll;
	            	  	$scope.pageData.checkModel.selectAll = false;
	            	  	$scope.pageData.checkModel.datas = [];
	            	  	$.each(data.data.list,function(i,n){
	            	  		$scope.pageData.checkModel.datas.push(false);
	            	  	});
	              }
	     });
	}
	
	
	//导向回复
	$scope.toCallback = function(id){
		$scope.callbackForm = {
				id:id,
		};
		$("#callbackWindow").modal('show');
	}
	
	
	//回复
	$scope.callback = function(){
		$http.post(app.api.host + app.api.base.wxMsgCallback, $scope.callbackForm)
	        .success(function(data,status,header,config){
	              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
	              } else if (data.code == '000000'){
	            	  $.toaster({priority : 'success', title : '提示', message :'操作成功'});
	            	  $("#callbackWindow").modal('hide');
	            	  loadPageData();
	              }
	     });
	}
	
	
	//删除
	$scope.del = function(id){
		$http.post(app.api.host + app.api.base.wxMsgDel,{id:id})
	        .success(function(data,status,header,config){
	              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
	              } else if (data.code == '000000'){
	            	  $.toaster({priority : 'success', title : '提示', message :'操作成功'});
	            	  loadPageData();
	              }
	     });
	}
	
	
	//批量删除
	$scope.dels = function(){
		
		var ids = [];
		$.each($scope.pageData.checkModel.datas,function(i,n){
			if (n){
				ids.push($scope.pageData.list[i].id);
			}
		});
		
		if (ids.length <= 0){
			$.toaster({priority : 'error', title : '提示', message : '当前没有选择数据！'});
			return;
		}
		
		$http.post(app.api.host + app.api.base.wxMsgDels,{ids:ids})
	        .success(function(data,status,header,config){
	              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
	              } else if (data.code == '000000'){
	            	  $.toaster({priority : 'success', title : '提示', message :'操作成功'});
	            	  loadPageData();
	              }
	     });
	}
	
	
	
	//全选
	$scope.selectAll = function(){
		$scope.pageData.checkModel.selectAll = true;
		$.each($scope.pageData.checkModel.datas,function(i,n){
			$scope.pageData.checkModel.datas[i] = true;
		});
	}
	
	//反选
	$scope.selectTurnAll = function(){
		var isSelectAll = true;
		$.each($scope.pageData.checkModel.datas,function(i,n){
			$scope.pageData.checkModel.datas[i] = !n;
			if (n){
				isSelectAll = false;
			}
		});
		$scope.pageData.checkModel.selectAll = isSelectAll;
	}
	
	//取消选择
	$scope.selectCancel = function(){
		$scope.pageData.checkModel.selectAll = false;
		$.each($scope.pageData.checkModel.datas,function(i,n){
			$scope.pageData.checkModel.datas[i] = false;
		});
	}
	
	//选择
	$scope.checkBoxSelectAll = function(){
		if ($scope.pageData.checkModel.selectAll){
			$scope.selectAll();
		} else {
			$scope.selectCancel();
		}
	}

	//单选
	$scope.checkBoxSelect = function(i){
		var isSelectAll = true;
		$.each($scope.pageData.checkModel.datas,function(i,n){
			if (!n){
				isSelectAll = false;
				return false;
			}
		});
		$scope.pageData.checkModel.selectAll = isSelectAll;
	}
	
	
}]);