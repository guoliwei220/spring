app.controller('loginCtr', ['$scope','$state','$http','$rootScope', function($scope,$state,$http,$rootScope) {
	
	$scope.loginForm = {
            username:"",
            password:"",
            verifyCode:""
         };
        
    $scope.login = function () {
        $http.post("../login",$scope.loginForm)
            .success(function(data,status,header,config){

                if (data.code != '000000'){
                    $scope.verifyCodeRandom = new Date().getTime();
                    $scope.loginForm.verifyCode = '';
                }

                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $.toaster({priority : 'success', title : '提示', message : "登陆成功！"});
                    $rootScope.userLoginSign = data.data.sign;
                    $state.go('app.dashboard');
                }

            });
    };
    
    $scope.enter_login = function (ev) {
		if(ev.keyCode == 13){
			$scope.login();
		}
	
	};
    
    $scope.verifyCodeRandom = new Date().getTime();
    $scope.replaceVerifyCode = function(){
    	$scope.verifyCodeRandom = new Date().getTime();
    }
	
}]);