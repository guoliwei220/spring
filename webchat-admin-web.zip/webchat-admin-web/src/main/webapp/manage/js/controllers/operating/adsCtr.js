app.controller('adsCtr', ['$scope','$state','$http','$timeout','nbFileupload', function($scope,$state,$http,$timeout,nbFileupload) {

    $scope.pageData = {
        api:app.api.host + app.api.operating.mAdsList,
        list:[],
        checkModel:{selectAll:false,datas:[]},
        params:{}
    };


    //页码栏初始化
    $scope.paginationConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 20,
        pagesLength: 15,
        perPageOptions: [10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function(){
            loadPageData();
        }
    };

    //加载分页数据
    var loadPageData = function(){

        var params = {
            'pageSize' : $scope.paginationConf.itemsPerPage,
            'pageNo' : $scope.paginationConf.currentPage
        };

        params = $.extend({},params,$scope.pageData.params);

        $http.get($scope.pageData.api,{params:params})
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $scope.pageData.list = data.data.list;
                    $scope.paginationConf.totalItems = data.data.countAll;
                    $scope.pageData.checkModel.selectAll = false;
                    $scope.pageData.checkModel.datas = [];
                    $.each(data.data.list,function(i,n){
                        $scope.pageData.checkModel.datas.push(false);
                    });
                }
            });
    }


    //去增加广告
    $scope.toAdd = function(){
        $scope.addForm = {};
        $http.get(app.api.host + app.api.operating.mAdsSave)
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $scope.adsPositionList = data.data.mWxAdsPositions;
                }
            });

        $("#addWindow").modal('show');
    }


    //上传图片
    $scope.addUploadImg = function(){
        nbFileupload.start({
            url:app.api.host + app.api.upload.uploadcms,
            parentId:'addWindow',
            params:{},
            maxFileSize:500*1024,
            maxFileNum:1,
            success:function(i,data){
                $scope.addForm.image = data.data.imgUrl;
            },
            error:function(i,data){
                alert(data.msg);
            }
        });
    }


    //上传图片
    $scope.updateUploadImg = function(){
        nbFileupload.start({
            url:app.api.host + app.api.upload.uploadcms,
            parentId:'updateWindow',
            params:{},
            maxFileSize:500*1024,
            maxFileNum:1,
            success:function(i,data){
                $scope.updateForm.image = data.data.imgUrl;
            },
            error:function(i,data){
                alert(data.msg);
            }
        });
    }

    //保存
    $scope.save = function(){
        $http.post(app.api.host + app.api.operating.mAdsSave, $scope.addForm)
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $.toaster({priority : 'success', title : '提示', message :'操作成功'});
                    $("#addWindow").modal('hide');
                    loadPageData();
                }
            });
    }

    //去修改广告
    $scope.toUpdate = function(adsPositionId){

        $http.get(app.api.host + app.api.operating.mAdsUpdate, {params: {id: adsPositionId}})
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $scope.updateForm = data.data.mWxAds;
                    $scope.adsPositionList = data.data.mWxAdsPositions;
                }
            });

        $("#updateWindow").modal('show');
    }

    //修改
    $scope.update = function(){
        $http.post(app.api.host + app.api.operating.mAdsUpdate,$scope.updateForm)
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $.toaster({priority : 'success', title : '提示', message :'操作成功'});
                    $("#updateWindow").modal('hide');
                    loadPageData();
                }
            });
    }
    //删除
    $scope.del = function(adsPositionId){
        $http.get(app.api.host + app.api.operating.mAdsDelete,{params: {id: adsPositionId}})
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $.toaster({priority : 'success', title : '提示', message :'操作成功'});
                    $("#updateWindow").modal('hide');
                    loadPageData();
                }
            });
    }

    //批量删除
    $scope.dels = function(){

        var ids = [];
        $.each($scope.pageData.checkModel.datas,function(i,n){
            if (n){
                ids.push($scope.pageData.list[i].id);
            }
        });

        if (ids.length <= 0){
            $.toaster({priority : 'error', title : '提示', message : '当前没有选择数据！'});
            return;
        }

        $http.post(app.api.host + app.api.operating.mAdsDeletes,{ids:ids})
            .success(function(data,status,header,config){
                if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
                    $.toaster({priority : 'error', title : '提示', message :data.msg});
                } else if (data.code == '000000'){
                    $.toaster({priority : 'success', title : '提示', message :'操作成功'});
                    loadPageData();
                }
            });
    }



    //全选
    $scope.selectAll = function(){
        $scope.pageData.checkModel.selectAll = true;
        $.each($scope.pageData.checkModel.datas,function(i,n){
            $scope.pageData.checkModel.datas[i] = true;
        });
    }

    //反选
    $scope.selectTurnAll = function(){
        var isSelectAll = true;
        $.each($scope.pageData.checkModel.datas,function(i,n){
            $scope.pageData.checkModel.datas[i] = !n;
            if (n){
                isSelectAll = false;
            }
        });
        $scope.pageData.checkModel.selectAll = isSelectAll;
    }

    //取消选择
    $scope.selectCancel = function(){
        $scope.pageData.checkModel.selectAll = false;
        $.each($scope.pageData.checkModel.datas,function(i,n){
            $scope.pageData.checkModel.datas[i] = false;
        });
    }

    //选择
    $scope.checkBoxSelectAll = function(){
        if ($scope.pageData.checkModel.selectAll){
            $scope.selectAll();
        } else {
            $scope.selectCancel();
        }
    }

    //单选
    $scope.checkBoxSelect = function(i){
        var isSelectAll = true;
        $.each($scope.pageData.checkModel.datas,function(i,n){
            if (!n){
                isSelectAll = false;
                return false;
            }
        });
        $scope.pageData.checkModel.selectAll = isSelectAll;
    }


}]);