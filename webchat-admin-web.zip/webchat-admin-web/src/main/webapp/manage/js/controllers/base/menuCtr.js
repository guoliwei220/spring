app.controller('menuCtr', ['$scope','$state','$http','$timeout', function($scope,$state,$http,$timeout) {
	
	//订阅资源
	$scope.callbackResource = {
			type:null,
			val:null
	};
	
	$scope.my_tree = {};
	$scope.my_data = [];
	
    //加载菜单数据
    $scope.loadMenu = function(){
    	$scope.my_data = [];
        $scope.selectMenuNode = null;
        $scope.add_menu_disabled = true;
        $scope.add_link_disabled = true;
        $scope.add_msg_disabled = true;
        $scope.update_menu_disabled = true;
        $scope.del_menu_disabled = true;
        
        /**
         * "init"没有动作
         * "toAddLink"去添加超链接、"showLink"展示超链接
         * "toAddMsg"去添加响应事件、"showMsg"展示响应内容
         */
        $scope.showInitEditScene = 'init';
    	
	    $http.get(app.api.host + app.api.base.wxMenuList)
	    .success(function(data,status,header,config){
	          if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
				 $.toaster({priority : 'error', title : '提示', message :data.msg});
	          } else if (data.code == '000000'){
	        	  $scope.my_data.slice(0,0);
	        	  $.each(data.data.root, function(i,n){
	        		  $scope.my_data.push(n);
	        	  });
	        	  $scope.my_tree.expand_all();
	        	  console.log($scope.my_tree);
	        	  console.log($scope.my_data);
	          }
	    });
    }
    $scope.loadMenu();
    
    
    //树点击事件
    $scope.my_tree_handler = function(branch) {
    	$scope.selectMenuNode = branch;
    	
    	$scope.update_menu_disabled = false;
    	$scope.del_menu_disabled = false;
    	
    	if (!$scope.selectMenuNode.data.type){
    		$scope.showInitEditScene = "init";
    		
    		if (branch.parentId == null){
        		if (branch.children.length == 0) {
        			$scope.add_menu_disabled = false;
        			$scope.add_link_disabled = false;
        			$scope.add_msg_disabled = false;
        		} else if (branch.children.length < 5) {
        			$scope.add_menu_disabled = false;
        			$scope.add_link_disabled = true;
        			$scope.add_msg_disabled = true;
        		} else if (branch.children.length >= 5) {
        			$scope.add_menu_disabled = true;
        			$scope.add_link_disabled = true;
        			$scope.add_msg_disabled = true;
        		}
        	} else {
        		$scope.add_menu_disabled = true;
    	        $scope.add_link_disabled = false;
    	        $scope.add_msg_disabled = false;
        	}
    	} else if ($scope.selectMenuNode.data.type == 'view'){
    		$scope.showInitEditScene = "showLink";
    		$scope.addLinkForm = {
    			url : $scope.selectMenuNode.data.url
    		}
    	} else if ($scope.selectMenuNode.data.type == 'click'){
    		$scope.showInitEditScene = "showMsg";
    		$http.get(app.api.host + app.api.base.wxResourceLoad, {params:{btnKey:$scope.selectMenuNode.data.btnKey}})
		    	.success(function(data,status,header,config){
			          if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
						 $.toaster({priority : 'error', title : '提示', message :data.msg});
			          } else if (data.code == '000000'){
			        	  $scope.callbackResource.type = data.data.type;
			        	  $scope.callbackResource.val = data.data.resource;
			          }
		    	});
    	}
    };
   
    
    //导向添加菜单
    $scope.toAddMenu = function(isSecond){
    	
    	if (!isSecond){
    		
    		$scope.addFormWin = {
				formTitle : "添加一级菜单",
				namePlaceholder : "1-4个字符"
    		};
    		
	    	$scope.addMenuForm = {};
    	} else {
    		
    		$scope.addFormWin = {
				formTitle : "添加二级菜单",
				namePlaceholder : "1-7个字符"
    		};
    		
    		$scope.addMenuForm = {
    			name:"",
    			parentId:$scope.selectMenuNode.id
    		};
    	}
    	
    	$("#addMenuWindow").modal('show');
    }
    
    //添加菜单
    $scope.addMenu = function(){
    	$http.post(app.api.host + app.api.base.wxMenuAdd,$scope.addMenuForm)
        .success(function(data,status,header,config){
              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
				 $.toaster({priority : 'error', title : '提示', message :data.msg});
              } else if (data.code == '000000'){
            	  $.toaster({priority : 'success', title : '提示', message : '操作成功'});
            	  $("#addMenuWindow").modal('hide');
            	  
            	  if ($scope.addMenuForm.parentId == null){
            		  $scope.my_data.push(data.data.node);
            	  } else {
            		  $scope.selectMenuNode.children.push(data.data.node);
            	  }
            	  $scope.my_tree.select_branch(data.data.node);
              }
        });
    }
    
    //导向修改菜单
    $scope.toUpdateMenu = function(){
    	
    	if (!$scope.selectMenuNode.parentId){
    		$scope.updateFormWin = {
				formTitle : "修改一级菜单",
				namePlaceholder : "1-4个字符"
    		};
	    	
    	} else {
    		$scope.updateFormWin = {
				formTitle : "修改二级菜单",
				namePlaceholder : "1-7个字符"
    		};
    	}
    	
    	$scope.updateMenuForm = {
    		id:$scope.selectMenuNode.id,
			name:$scope.selectMenuNode.label,
			parentId:$scope.selectMenuNode.parentId
		};
    	
    	$("#updateMenuWindow").modal('show');
    }
    
    //修改菜单
    $scope.updateMenu = function(){
    	$http.post(app.api.host + app.api.base.wxMenuUpdate,$scope.updateMenuForm)
        .success(function(data,status,header,config){
              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
				 $.toaster({priority : 'error', title : '提示', message :data.msg});
              } else if (data.code == '000000'){
            	  $.toaster({priority : 'success', title : '提示', message : '操作成功'});
            	  $("#updateMenuWindow").modal('hide');
            	  
            	  delete data.data.node.children;
            	  $.extend($scope.selectMenuNode,data.data.node);
            	  $scope.my_tree.select_branch($scope.selectMenuNode);
        		  $scope.my_tree_handler($scope.selectMenuNode);
              }
        });
    }
    
    //删除菜单
    $scope.delMenu = function(){
    	
    	$http.post(app.api.host + app.api.base.wxMenuDel,{id:$scope.selectMenuNode.id})
        .success(function(data,status,header,config){
              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
				 $.toaster({priority : 'error', title : '提示', message :data.msg});
              } else if (data.code == '000000'){
            	  $.toaster({priority : 'success', title : '提示', message : '操作成功'});
            	  
            	  if ($scope.selectMenuNode.data.level == 1){
            		  var pos = $.inArray($scope.selectMenuNode, $scope.my_data);
            		  $scope.my_data.splice(pos,1);
            		  $scope.selectMenuNode = null;
            		  $scope.my_tree.select_first_branch();
            	  } else if ($scope.selectMenuNode.data.level == 2) {
            		  var parent = $scope.my_tree.get_parent_branch($scope.selectMenuNode);
            		  var pos = $.inArray($scope.selectMenuNode, parent.children);
            		  parent.children.splice(pos,1);
            		  $scope.my_tree.select_branch(parent);
            	  }
              }
        });
    }
    
    //重设动作
    $scope.resetAction = function(){
    	$http.post(app.api.host + app.api.base.wxMenuResetAction,{id:$scope.selectMenuNode.id})
        .success(function(data,status,header,config){
              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
				 $.toaster({priority : 'error', title : '提示', message :data.msg});
              } else if (data.code == '000000'){
            	  $.toaster({priority : 'success', title : '提示', message : '操作成功'});
            	  
        		  $scope.selectMenuNode.data.type = null;
        		  $scope.selectMenuNode.data.url = null;
        		  $scope.selectMenuNode.data.btnKey = null;
        		  
        		  $scope.my_tree.select_branch($scope.selectMenuNode);
        		  $scope.my_tree_handler($scope.selectMenuNode);
              }
        });
    }
    
    //导向添加链接
    $scope.toAddLink = function(){
    	$scope.addLinkForm = {
    		id:$scope.selectMenuNode.id,
			url:""
		};
    	$scope.showInitEditScene = "toAddLink";
    }
    
    //添加链接
    $scope.addLink = function(){
    	$http.post(app.api.host + app.api.base.wxMenuAddLink,$scope.addLinkForm)
        .success(function(data,status,header,config){
              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
				 $.toaster({priority : 'error', title : '提示', message :data.msg});
              } else if (data.code == '000000'){
            	  $.toaster({priority : 'success', title : '提示', message : '操作成功'});
            	  
            	  var modObj = {
            			  data:{
            				  type: 'view',
            				  url: $scope.addLinkForm.url
            			  }
            	  };
            	  
        		  $.extend($scope.selectMenuNode,modObj);
        		  
        		  $scope.my_tree.select_branch($scope.selectMenuNode);
        		  $scope.my_tree_handler($scope.selectMenuNode);
              }
        });
    }
    
    //导向发送消息
    $scope.toAddMsg = function(){
    	$scope.callbackResource = {
    			type: null,
    			val: null
    	};
    	$scope.showInitEditScene = "toAddMsg";
    }
    
    //发送消息
    $scope.addMsg = function(){
    	
    	console.log($scope.callbackResource);
    	
    	var params = {
    			id: $scope.selectMenuNode.id,
    			resourceId: $scope.callbackResource.val.id,
    			resourceType: $scope.callbackResource.type
    	};
    	
    	$http.post(app.api.host + app.api.base.wxMenuAddMsg, params)
        .success(function(data,status,header,config){
              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
				 $.toaster({priority : 'error', title : '提示', message :data.msg});
              } else if (data.code == '000000'){
            	  $.toaster({priority : 'success', title : '提示', message : '操作成功'});
            	  
            	  var modObj = {
            			  data:{
            				  type: 'click',
            				  btnKey: data.data.btnKey
            			  }
            	  };
            	  
        		  $.extend($scope.selectMenuNode,modObj);
        		  
        		  $scope.my_tree.select_branch($scope.selectMenuNode);
        		  $scope.my_tree_handler($scope.selectMenuNode);
              }
        });
    }
    
    
    //发布菜单
    $scope.applyMenu = function(){
    	$http.post(app.api.host + app.api.base.wxMenuApply)
	      .success(function(data,status,header,config){
	            if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
	            } else if (data.code == '000000'){
	          	  $.toaster({priority : 'success', title : '提示', message : '操作成功'});
	            }
	      });
    }
    
}]);