app.controller('resourceCtr', ['$scope','$state','$http','$timeout','nbFileupload', function($scope,$state,$http,$timeout,nbFileupload) {
	
	$scope.pageData = {
		api:app.api.host + app.api.base.wxResourceNewsList,
		list:[],
		checkModel:{selectAll:false,datas:[]},
		params:{}
	};
	
	
	//页码栏初始化
	$scope.paginationConf = {
        currentPage: 1,
        totalItems: 0,
        itemsPerPage: 20,
        pagesLength: 7,
        perPageOptions: [10, 20, 30, 40, 50],
        rememberPerPage: 'perPageItems',
        onChange: function(){
        	loadPageData();
        }
    };
	
	//加载分页数据
	var loadPageData = function(){
		
		var params = {
			'pageSize' : $scope.paginationConf.itemsPerPage,
			'pageNo' : $scope.paginationConf.currentPage
		};
		
		params = $.extend({},params,$scope.pageData.params);
		
		$http.get($scope.pageData.api,{params:params})
	        .success(function(data,status,header,config){
	              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
	              } else if (data.code == '000000'){
	            	  	$scope.pageData.list = data.data.list;
	            	  	$scope.paginationConf.totalItems = data.data.countAll;
	            	  	$scope.pageData.checkModel.selectAll = false;
	            	  	$scope.pageData.checkModel.datas = [];
	            	  	$.each(data.data.list,function(i,n){
	            	  		$scope.pageData.checkModel.datas.push(false);
	            	  	});
	              }
	     });
	}
	
	
	//鼠标划入
	$scope.itemMouseenter = function($event){
		$($event.currentTarget).addClass("mouseover");
	}
	
	//鼠标划走
	$scope.itemMouseleave = function($event){
		$($event.currentTarget).removeClass("mouseover");
	}
	
	//鼠标划入预览图片
	$scope.previewImgMouseenter = function($event){
		$($event.currentTarget).addClass("mouseover");
	}
	
	//鼠标划走预览图片
	$scope.previewImgMouseleave = function($event){
		$($event.currentTarget).removeClass("mouseover");
	}
	
	
	//导向添加
	$scope.toAdd = function(){
		$scope.addForm = {
			items:[{
				title: '',
				image: null,
				href: ''
			}]
		};
		$("#addWindow").modal('show');
		
		$scope.editItem(0);
	}
	
	//添加项目
	$scope.addItem = function(){
		$scope.addForm.items.push({
			title: '',
			image: null,
			href: ''
		});
		
		$scope.editItem($scope.addForm.items.length - 1);
	}
	
	//删除项目
	$scope.delItem = function(index){
		$scope.addForm.items.splice(index,1);
	}
	
	//编辑项目
	$scope.editItem = function(index){
		$scope.addEditForm = $scope.addForm.items[index];
	}
	
	//上传图片
	$scope.uploadImg = function(){
		nbFileupload.start({
            url:app.api.host + app.api.upload.uploadcms,
            parentId:'addWindow',
            params:{},
            maxFileSize:500*1024,
            maxFileNum:1,
            success:function(i,data){
            	$scope.addEditForm.image = data.data.imgUrl;
            },
            error:function(i,data){
                alert(data.msg);
            }
        });
	}
	
	$scope.delItemImg = function(){
		$scope.addEditForm.image = null;
	}
	
	
	//添加
	$scope.add = function(){
		$http.post(app.api.host + app.api.base.wxResourceAddNews,$scope.addForm)
	        .success(function(data,status,header,config){
	              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
	              } else if (data.code == '000000'){
	            	  $.toaster({priority : 'success', title : '提示', message :'操作成功'});
	            	  $("#addWindow").modal('hide');
	            	  loadPageData();
	              }
	     });
	}
	
	//导向修改
	$scope.toUpdate = function(id){
		$http.get(app.api.host + app.api.base.wxResourceUpdateNews, {params:{id:id}})
	        .success(function(data,status,header,config){
	              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
	              } else if (data.code == '000000'){
	            	  $scope.updateForm = data.data.resource;
	            	  $scope.editItemForUpdate(0);
	            	  $("#updateWindow").modal('show');
	              }
	     });
	}
	
	//添加项目 更新
	$scope.addItemForUpdate = function(){
		$scope.updateForm.items.push({
			title: '',
			image: null,
			href: ''
		});
		
		$scope.editItem($scope.updateForm.items.length - 1);
	}
	
	//删除项目 更新
	$scope.delItemForUpdate = function(index){
		$scope.updateForm.items.splice(index,1);
	}
	
	//编辑项目 更新
	$scope.editItemForUpdate = function(index){
		$scope.updateEditForm = $scope.updateForm.items[index];
	}
	
	//上传图片 更新
	$scope.uploadImgForUpdate = function(){
		nbFileupload.start({
            url:app.api.host + app.api.upload.uploadcms,
            parentId:'updateWindow',
            params:{},
            maxFileSize:500*1024,
            maxFileNum:1,
            success:function(i,data){
            	$scope.updateEditForm.image = data.data.imgUrl;
            },
            error:function(i,data){
                alert(data.msg);
            }
        });
	}
	
	//删除图片 更新
	$scope.delItemImgForUpdate = function(){
		$scope.updateEditForm.image = null;
	}
	
	
	//修改
	$scope.update = function(){
		$http.post(app.api.host + app.api.base.wxResourceUpdateNews,$scope.updateForm)
	        .success(function(data,status,header,config){
	              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
	              } else if (data.code == '000000'){
	            	  $.toaster({priority : 'success', title : '提示', message :'操作成功'});
	            	  $("#updateWindow").modal('hide');
	            	  loadPageData();
	              }
	     });
	}
	
	//删除
	$scope.del = function(id){
		$http.post(app.api.host + app.api.base.wxResourceDelNews,{id:id})
	        .success(function(data,status,header,config){
	              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
	              } else if (data.code == '000000'){
	            	  $.toaster({priority : 'success', title : '提示', message :'操作成功'});
	            	  loadPageData();
	              }
	     });
	}
	
	
	//批量删除
	$scope.dels = function(){
		
		var ids = [];
		$.each($scope.pageData.checkModel.datas,function(i,n){
			if (n){
				ids.push($scope.pageData.list[i].id);
			}
		});
		
		if (ids.length <= 0){
			$.toaster({priority : 'error', title : '提示', message : '当前没有选择数据！'});
			return;
		}
		
		$http.post(app.api.host + app.api.base.wxResourceDelsNews,{ids:ids})
	        .success(function(data,status,header,config){
	              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
	              } else if (data.code == '000000'){
	            	  $.toaster({priority : 'success', title : '提示', message :'操作成功'});
	            	  loadPageData();
	              }
	     });
	}
	
	
	
	//全选
	$scope.selectAll = function(){
		$scope.pageData.checkModel.selectAll = true;
		$.each($scope.pageData.checkModel.datas,function(i,n){
			$scope.pageData.checkModel.datas[i] = true;
		});
	}
	
	//反选
	$scope.selectTurnAll = function(){
		var isSelectAll = true;
		$.each($scope.pageData.checkModel.datas,function(i,n){
			$scope.pageData.checkModel.datas[i] = !n;
			if (n){
				isSelectAll = false;
			}
		});
		$scope.pageData.checkModel.selectAll = isSelectAll;
	}
	
	//取消选择
	$scope.selectCancel = function(){
		$scope.pageData.checkModel.selectAll = false;
		$.each($scope.pageData.checkModel.datas,function(i,n){
			$scope.pageData.checkModel.datas[i] = false;
		});
	}
	
	//选择
	$scope.checkBoxSelectAll = function(){
		if ($scope.pageData.checkModel.selectAll){
			$scope.selectAll();
		} else {
			$scope.selectCancel();
		}
	}

	//单选
	$scope.checkBoxSelect = function(i){
		var isSelectAll = true;
		$.each($scope.pageData.checkModel.datas,function(i,n){
			if (!n){
				isSelectAll = false;
				return false;
			}
		});
		$scope.pageData.checkModel.selectAll = isSelectAll;
	}
	
	
}]);