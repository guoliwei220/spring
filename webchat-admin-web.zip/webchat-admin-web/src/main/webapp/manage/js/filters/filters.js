app.filter('imgres', [function() {
	return function(imgval) { 
		return app.api.imageServer + imgval;
	}
}]);


app.filter('mobile_imgres', [function() {
	return function(imgval) {
		return app.api.mobileImageServer + imgval;
	}
}]);