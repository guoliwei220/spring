//配置
var app = angular.module('app')
	.run(['$rootScope', '$state', '$stateParams','$location' ,
	    function ($rootScope,   $state,   $stateParams, $location) {
	        $rootScope.$state = $state;
	        $rootScope.$stateParams = $stateParams;
	    }
	 ])
  .config(['$controllerProvider', '$compileProvider', '$filterProvider', '$provide', '$httpProvider',
    function ($controllerProvider,   $compileProvider,   $filterProvider,   $provide,  $httpProvider) {
        
        app.controller = $controllerProvider.register;
        app.directive  = $compileProvider.directive;
        app.filter     = $filterProvider.register;
        app.factory    = $provide.factory;
        app.service    = $provide.service;
        app.constant   = $provide.constant;
        app.value      = $provide.value;
        
        $httpProvider.interceptors.push('loginInterceptor');
    }
]);

app.factory('loginInterceptor', ["$q","$rootScope","$injector",function ($q,$rootScope,$injector) {
	return {
       request: function (config) {
           return config;
       },
       response: function (response) {
           var data = response.data; 
           if (data.code == '000002'){
        	   $.toaster({priority : 'error', title : '提示', message :  data.fieldError.field + data.fieldError.errmsg});
           } else if (data.code == '000003'){
        	   var stateService = $injector.get('$state');
               stateService.go("login");
           }
           return response || $q.when(response);
       }
    };
}]);


app.api =  {
      
    host : "../manager/",
    
    imageServer : "../imgres/",
    mobileImageServer : "http://www.chinagoldcoin.net/",
    
    upload : {
    	uploadcms : "cms/uploadImg",
    	uploadcmsfile : "cms/uploadFile",
    	uploadtvapp: "/tvapp/upload"
    },
    
    login : {
    	login : "../login",
    	logout : "../logout",
    	updatePass : "updatePass"
    },
    
    dashboard : {
    },
    
    base : {
    	
        getWxConfig : 'wxconfig/loadConfig',//加载配置
        setWxConfig : 'wxconfig/setConfig', //设置参数
        
        wxAuthList : 'wxauth/list', 		//加载微信授权列表
        wxAuthAdd : 'wxauth/add', 			//添加微信授权列表
        wxAuthDel : 'wxauth/del', 			//删除微信授权列表
        wxAuthDels : 'wxauth/dels', 		//批量删除微信授权列表
        wxAuthToUpdate : 'wxauth/toUpdate', //初始化修改微信授权列表
        wxAuthUpdate : 'wxauth/update', 	//修改微信授权列表
        
        wxMenuList : 'wxmenu/list', 		        //加载微信菜单列表
        wxMenuAdd : 'wxmenu/add', 			        //添加微信菜单列表
        wxMenuDel : 'wxmenu/del', 			        //删除微信菜单列表
        wxMenuToUpdate : 'wxmenu/toUpdate',         //初始化修改微信菜单列表
        wxMenuUpdate : 'wxmenu/update', 	        //修改微信菜单列表
        wxMenuResetAction : 'wxmenu/resetAction', 	//修改微信菜单重设动作
        wxMenuApply : 'wxmenu/apply', 		        //发布菜单
        wxMenuAddLink : 'wxmenu/addLink', 	        //添加链接
        wxMenuAddMsg : 'wxmenu/addMsg', 	        //添加消息
        
        wxResourceAddText : 'wxresource/addText',        //添加微信文本资源
        wxResourceAddNews : 'wxresource/addNews',        //添加微信图文资源
        wxResourceDelNews : 'wxresource/delNews',        //删除微信图文资源
        wxResourceDelsNews : 'wxresource/delsNews',      //批量删除微信图文资源
        wxResourceUpdateNews : 'wxresource/updateNews',  //修改微信图文资源
        wxResourceNewsList : 'wxresource/newsList',      //分页加载微信图文资源
        wxResourceLoad : 'wxresource/load',              //加载微信回复资源
        
        wxCallbackAdd : 'wxcallback/add',                   //添加微信回复
        wxCallbackDel : 'wxcallback/del',                   //删除微信回复
        wxCallbackListForWords : 'wxcallback/listForWords', //微信关键词回复列表
        
        wxMsgList : 'wxmsg/list',            //微信消息列表
        wxMsgCallback : 'wxmsg/callback',    //微信消息回复
        wxMsgDel : 'wxmsg/del',              //删除微信消息
        wxMsgDels : 'wxmsg/dels',            //批量删除微信消息
        
        wxUserList : 'wxuser/list',            //微信用户列表
        wxUserImport : 'wxuser/import',        //微信用户导入
        wxUserDel : 'wxuser/del',              //删除微信用户
        wxUserDels : 'wxuser/dels',            //批量删除微信用户
        wxUserBind:'wxuser/userbind',
       userDelBind:'wxuser/userdelbind'
     },

    operating : {
        mAdsPositionList : 'mAdsPosition/list',                      //广告位列表
        mAdsList : 'mAds/list' ,                                       //广告列表
        mAdsSave : 'mAds/save' ,                                       //保存广告
        mAdsUpdate : 'mAds/update' ,                                  //修改广告
        mAdsDelete : 'mAds/delete',                                   //删除广告
        mAdsDeletes : 'mAds/deletes',                                 //批量删除广告
        mAdsPositionAdd : 'mAdsPosition/add', 			              //添加广告位
        mAdsPositionDel : 'mAdsPosition/del', 			              //删除广告位
        mAdsPositionDels : 'mAdsPosition/dels', 		              //批量删除广告位
        mAdsPositionUpdate : 'mAdsPosition/update', 	              //修改微信广告位
        hotGoodsList:'hotGoods/hotList',                              //热销商品列表
        hotGoodsSave:'hotGoods/save',                                 //热销商品保存
        hotGoodsDelete:'hotGoods/delete',                            //热销商品删除
        hotGoodsDeletes:'hotGoods/deletes',                          //批量热销商品删除
        hotGoodsUpdate:'hotGoods/update',                            //热销商品修改
        goodsFind:'hotGoods/list',                                    //普通商品查找
        goodsApply:'hotGoods/open',                                   //普通商品启用为热销商品
        hotGoodsSequence:'hotGoods/sequenceUpdate',                 //热销商品保存


        pandaKindList : 'panda/kindList', 		                      //加载熊猫币类别列表
        pandaKindAdd : 'panda/kindAdd', 			                      //添加熊猫币类别菜单
        pandaKindDel : 'panda/kindDel', 			                      //删除熊猫币类别菜单
        pandaKindUpdate : 'panda/kindUpdate', 	                      //修改熊猫币类别菜单

        pandaGoodsList : 'panda/goodsList', 	                      //熊猫币列表
        pandaGoodsDel : 'panda/goodsDel', 			                  //删除熊猫币
        pandaGoodsDels : 'panda/goodsDels', 			              //删除熊猫币列表
        pandaGoodsAdd : 'panda/goodsAdd', 			                  //添加熊猫币
        pandaGoodsUpdate : 'panda/goodsUpdate', 			          //修改熊猫币

        commemorativeKindList : 'commemorative/kindList', 		                      //加载纪念币类别列表
        commemorativeKindAdd : 'commemorative/kindAdd', 			                  //添加纪念币类别菜单
        commemorativeKindDel : 'commemorative/kindDel', 			                  //删除纪念币类别菜单
        commemorativeKindUpdate : 'commemorative/kindUpdate', 	                      //修改纪念币类别菜单

        commemorativeGoodsList : 'commemorative/goodsList', 	                      //纪念币列表
        commemorativeGoodsDel : 'commemorative/goodsDel', 			                  //删除纪念币
        commemorativeGoodsDels : 'commemorative/goodsDels', 			              //删除纪念币列表
        commemorativeGoodsAdd : 'commemorative/goodsAdd', 			                  //添加纪念币
        commemorativeGoodsUpdate : 'commemorative/goodsUpdate', 			          //修改纪念币

        commemorativeHotGoodsList : 'commemorative/hotGoodsList', 	                      //纪念币热销商品列表
        commemorativeHotGoodsDel : 'commemorative/hotGoodsDel', 			                //删除纪念币热销商品
        commemorativeHotGoodsDels : 'commemorative/hotGoodsDels', 			              //删除纪念币热销商品列表
        commemorativeHotGoodsAdd : 'commemorative/hotGoodsAdd', 			                  //添加纪念币热销商品
        commemorativeHotGoodsUpdate : 'commemorative/hotGoodsUpdate', 			          //修改纪念币热销商品

    }
};