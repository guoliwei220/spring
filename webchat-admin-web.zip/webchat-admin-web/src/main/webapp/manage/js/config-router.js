//路由
angular.module('app')
  .run([
        		'$rootScope', '$state', '$stateParams',
      function ($rootScope,   $state,   $stateParams) {
          $rootScope.$state = $state;
          $rootScope.$stateParams = $stateParams;        
      }
    ]
  )
  .config([
           		'$stateProvider', '$urlRouterProvider',
      function ($stateProvider,   $urlRouterProvider) {
          
          $urlRouterProvider
              .otherwise('/login');
          
          $stateProvider
              .state('login', {
                  url: '/login',
                  templateUrl: 'tpl/login.html',
                  controller: 'loginCtr',
	              resolve: {
	                  deps: ['uiLoad',
	                      function( uiLoad ){
	                          return uiLoad.load( ['css/login.css',
	                                               'js/controllers/loginCtr.js'
	                          ]);
	                      }]
	              }
              })
              .state('app', {
                  //abstract: true,
                  url: '/app',
                  templateUrl: 'tpl/main.html',
                  controller: function($scope,$window){
                	  $scope.$on('$viewContentLoaded', function(){
                		  $(window).resize();
                	  });
                  }
              })
              .state('app.dashboard', {
                  url: '/dashboard',
                  templateUrl: 'tpl/dashboard.html',
                  resolve: {
	                  deps: ['uiLoad',
	                      function( uiLoad ){
	                          return uiLoad.load( ['js/controllers/dashboardCtr.js',
	                                               'vendor/jquery/echarts/echarts.js',
	                                               'vendor/socketio/sockjs-0.3.4.js',
	                          ]);
	                      }]
	              }
              })
              .state('app.base', {
                  url: '/base',
                  template: '<div ui-view class="view-frame"></div>'
              })
              .state('app.base.config', {
                  url: '/config',
                  templateUrl: 'tpl/base/wxconfig.html',
                  resolve: {
	                  deps: ['uiLoad',
	                      function( uiLoad ){
	                          return uiLoad.load( ['js/controllers/base/configCtr.js'
	                          ]);
	                      }]
	              }
              })
               .state('app.base.userbind', {
                  url: '/userdelbind',
                  templateUrl: 'tpl/base/userdelbind.html',
                  resolve: {
	                  deps: ['uiLoad',
	                      function( uiLoad ){
	                          return uiLoad.load( ['js/controllers/base/userdelbindCtr.js'
	                          ]);
	                      }]
	              }
              })
              .state('app.base.menu', {
                  url: '/menu',
                  templateUrl: 'tpl/base/wxmenu.html',
	              resolve: {
                      deps: ['$ocLazyLoad',
                        function( $ocLazyLoad ){
                          return $ocLazyLoad.load(['angularPagination','angularBootstrapNavTree']).then(
                              function(){
                                 return $ocLazyLoad.load(['js/controllers/base/menuCtr.js',
                                                          'css/wxmenu.css',
                                                          'js/directives/resourceDirect.js',
	                        	                           'css/resourceDirect.css'
                                        ]);
                              }
                          );
                        }
                      ]
                  }
              })
              .state('app.base.auth', {
                  url: '/auth',
                  templateUrl: 'tpl/base/wxauth.html',
	              resolve: {
	                  deps: ['$ocLazyLoad',
	                    function( $ocLazyLoad ){
	                      return $ocLazyLoad.load('angularPagination').then(
	                          function(){
	                        	  return $ocLazyLoad.load(['js/controllers/base/authCtr.js'
	                     	                          ]);
	                          }
	                      );
	                    }
	                  ]
	              }
              })
              .state('app.base.callback', {
                  url: '/callback',
                  templateUrl: 'tpl/base/wxcallback.html',
	              resolve: {
	                  deps: ['$ocLazyLoad',
	                    function( $ocLazyLoad ){
	                      return $ocLazyLoad.load(['angularPagination','angularNbFileupload']).then(
	                          function(){
	                        	  return $ocLazyLoad.load(['js/controllers/base/callbackCtr.js',
	                        	                           'js/directives/resourceDirect.js',
	                        	                           'css/resourceDirect.css'
	                     	                          ]);
	                          }
	                      );
	                    }
	                  ]
	              }
              })
              .state('app.base.resource', {
                  url: '/resource',
                  templateUrl: 'tpl/base/wxresource.html',
                  controller:'resourceCtr',
	              resolve: {
	                  deps: ['$ocLazyLoad',
	                    function( $ocLazyLoad ){
	                      return $ocLazyLoad.load(['angularPagination','angularNbFileupload']).then(
	                          function(){
	                             return $ocLazyLoad.load(['js/controllers/base/resourceCtr.js',
	                                                      'css/wxresource.css'
	                                    ]);
	                          }
	                      );
	                    }
	                  ]
	              }
              })
              .state('app.base.msg', {
                  url: '/msg',
                  templateUrl: 'tpl/base/wxmsg.html',
	              resolve: {
	                  deps: ['$ocLazyLoad',
	                    function( $ocLazyLoad ){
	                      return $ocLazyLoad.load('angularPagination').then(
	                          function(){
	                        	  return $ocLazyLoad.load(['js/controllers/base/msgCtr.js'
	                     	                          ]);
	                          }
	                      );
	                    }
	                  ]
	              }
              })
			  .state('app.operating', {
				  url: '/operating',
				  template: '<div ui-view class="view-frame"></div>'
			  })
			  .state('app.operating.adsPosition', {
				  url: '/adsPosition',
				  templateUrl: 'tpl/operating/adsPosition.html',
				  controller:'adsPositionCtr',
				  resolve: {
					  deps: ['$ocLazyLoad',
						  function( $ocLazyLoad ){
							  return $ocLazyLoad.load('angularPagination').then(
								  function(){
									  return $ocLazyLoad.load(['js/controllers/operating/adsPositionCtr.js'
									  ]);
								  }
							  );
						  }
					  ]
				  }
			  })

              //广告管理路由
			  .state('app.operating.ads', {
				  url: '/ads',
				  templateUrl: 'tpl/operating/ads.html',
				  controller:'adsCtr',
				  resolve: {
					  deps: ['$ocLazyLoad',
						  function( $ocLazyLoad ){
							  return $ocLazyLoad.load(['angularPagination','angularNbFileupload']).then(
								  function(){
									  return $ocLazyLoad.load([
										  'css/wxads.css',
										  'js/controllers/operating/adsCtr.js'
									  ]);
								  }
							  );
						  }
					  ]
				  }
			  })

			  //热销商品路由
			  .state('app.operating.hotGoods', {
				  url: '/hotGoods',
				  templateUrl: 'tpl/operating/hotGoods.html',
				  controller:'hotGoodsCtr',
				  resolve: {
					  deps: ['$ocLazyLoad',
						  function( $ocLazyLoad ){
							  return $ocLazyLoad.load('angularPagination').then(
								  function(){
									  return $ocLazyLoad.load([
										  'css/wxads.css',
										  'js/controllers/operating/hotGoodsCtr.js'
									  ]);
								  }
							  );
						  }
					  ]
				  }
			  })

			  //熊猫币频道管理
			  .state('app.operating.panda', {
				  url: '/panda',
				  templateUrl: 'tpl/operating/panda.html',
				  controller:'pandaCtr',
				  resolve: {
					  deps: ['$ocLazyLoad',
						  function( $ocLazyLoad ){
							  return $ocLazyLoad.load('angularPagination').then(
								  function(){
									  return $ocLazyLoad.load(['js/controllers/operating/pandaCtr.js',
										  'vendor/jquery/zTree_v3/jquery.ztree.core-3.5.min.js',
										  'css/wxads.css',
										  'vendor/jquery/zTree_v3/css/metroStyle/metroStyle.css'
									  ]);
								  }
							  );
						  }
					  ]
				  }
			  })

			  //纪念币频道管理
			  .state('app.operating.commemorative', {
				  url: '/commemorative',
				  templateUrl: 'tpl/operating/commemorative.html',
				  controller:'commemorativeCtr',
				  resolve: {
					  deps: ['$ocLazyLoad',
						  function( $ocLazyLoad ){
							  return $ocLazyLoad.load(['angularPagination','angularNbFileupload']).then(
								  function(){
									  return $ocLazyLoad.load(['js/controllers/operating/commemorativeCtr.js',
										  'vendor/jquery/zTree_v3/jquery.ztree.core-3.5.min.js',
										  'css/wxads.css',
										  'vendor/jquery/zTree_v3/css/metroStyle/metroStyle.css'
									  ]);
								  }
							  );
						  }
					  ]
				  }
			  })

	  }
    ]
  );