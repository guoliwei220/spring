
Date.prototype.Format = function(fmt) 
{
  var o = { 
    "M+" : this.getMonth()+1,                 //月份 
    "d+" : this.getDate(),                    //日 
    "h+" : this.getHours(),                   //小时 
    "m+" : this.getMinutes(),                 //分 
    "s+" : this.getSeconds(),                 //秒 
    "q+" : Math.floor((this.getMonth()+3)/3), //季度 
    "S"  : this.getMilliseconds()             //毫秒 
  }; 
  if(/(y+)/.test(fmt)) 
    fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length)); 
  for(var k in o) 
    if(new RegExp("("+ k +")").test(fmt)) 
  fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length))); 
  return fmt; 
}

Date.prototype.AddDays = function(d)
{
    this.setDate(this.getDate() + d);
    return this;
};

Date.prototype.AddWeeks = function(w)
{
    this.addDays(w * 7);
    return this;
};

Date.prototype.AddMonths= function(m)
{
    var d = this.getDate();
    this.setMonth(this.getMonth() + m);
    if (this.getDate() < d)
        this.setDate(0);
    return this;
};

Date.prototype.AddYears = function(y)
{
    var m = this.getMonth();
    this.setFullYear(this.getFullYear() + y);
    if (m < this.getMonth())
     {
        this.setDate(0);
     }
    return this;
};


//定义app
angular.module('app', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngSanitize',
    'ngTouch',
    'ngStorage',
    'ui.router',
    'ui.bootstrap',
    'ui.load',
    'oc.lazyLoad',
    'pasvaz.bindonce'
])
.controller('appCtrl', ['$scope','$localStorage','$window','$http','$state',
    function($scope,$localStorage,$window, $http,$state) {
	
		/**
		 * 退出
		 */
		$scope.logout = function(){
			$http.get(app.api.login.logout)
		        .success(function(data,status,header,config){
		        	 $.toaster({priority : 'success', title : '提示', message : "注销成功！"});
                     $state.go('login');
		        })
		}
		
		/**
		 * 导向修改密码
		 */
		$scope.toUpdatePass = function(){
			
			$scope.updatePassForm = {
					oldPassword:'',
					newPassword: '',
					rePassword:''
			};
			
			$("#updatePassWindow").modal('show');
		}
		
		/**
		 * 修改密码
		 */
		$scope.updatePass = function(){
			
			$http.post(app.api.host + app.api.login.updatePass, $scope.updatePassForm)
	        .success(function(data,status,header,config){
	              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
					 $.toaster({priority : 'error', title : '提示', message :data.msg});
	              } else if (data.code == '000000'){
	            	  $.toaster({priority : 'success', title : '提示', message :'操作成功'});
	            	  $("#updatePassWindow").modal('hide');
	              }
	        });
			
		}
	
	}
]);