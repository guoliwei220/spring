app.directive('resourceDirect',['$http',function($http){
    return {
		scope: {
			resource: '='
		},
        restrict: 'EA',
        replace: true,
        templateUrl: 'tpl/base/resourceDirect.html',
        controller : function($scope, $element, $attrs){
        	   $scope.paginationConf =  {
        	        currentPage: 1,
        	        totalItems: 0,
        	        itemsPerPage: 20,
        	        pagesLength: 15,
        	        perPageOptions: [10, 20, 30, 40, 50],
        	        rememberPerPage: 'perPageItems',
        	        onChange: function(){
        	        }
        	    };
        },
        link : function(scope,tElem,attrs){
        	
        	scope.initViewConfig = {
        			winId : new Date().getTime() + (Math.random() * 1000).toFixed(0)
        	}
        	
        	//文本表单对象
        	scope.addResourceTextWindowForm = {
        			content : null
        	};
        	
        	//导向添加文本资源
        	scope.toAddResourceText = function(){
        		$("#addResourceTextWindow" + scope.initViewConfig.winId).modal('show');
        	}
        	
        	//添加文本资源
        	scope.addResourceText = function(){
        		
        		$http.post(app.api.host + app.api.base.wxResourceAddText, scope.addResourceTextWindowForm)
    	        .success(function(data,status,header,config){
    	              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
    					 $.toaster({priority : 'error', title : '提示', message :data.msg});
    	              } else if (data.code == '000000'){
    	            	  $http.get(app.api.host + app.api.base.wxResourceLoad, {params:{id:data.data.resourceId, type:'text'}})
	    	      	        .success(function(data,status,header,config){
	    	      	              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
	    	      					 $.toaster({priority : 'error', title : '提示', message :data.msg});
	    	      	              } else if (data.code == '000000'){
	    	      	            	  scope.resource.type = 'text';
	    	      	            	  scope.resource.val = data.data.resource;
	    	      	            	  $("#addResourceTextWindow"+ scope.initViewConfig.winId).modal('hide');
	    	      	              }
	    	      	        });
    	              }
    	        });
        		
        	}
        	
        	
        	
        	
        	//导向添加新闻资源
        	scope.toAddResourceNews = function(){
      	            
  	            	scope.pageData = {
            			api:app.api.host + app.api.base.wxResourceNewsList,
            			list:[],
            			checkModel:{selectAll:false,datas:[]},
            			params:{},
            			selectIndex:null
            		};
  	            	
  	            	//选择素材
  	            	scope.selectNews = function(index){
  	            		scope.pageData.selectIndex = index;
  	            	}
  	            		
  	            		
            		//页码栏初始化
            		scope.paginationConf =  {
            	        currentPage: 1,
            	        totalItems: 0,
            	        itemsPerPage: 3,
            	        pagesLength: 11,
            	        perPageOptions: [3, 6, 10, 20, 30],
            	        rememberPerPage: 'perPageItems',
            	        onChange: function(){
            	        	loadPageData();
            	        }
            	    };
  	            		
            		//加载分页数据
            		var loadPageData = function(){
            			
            			var params = {
            				'pageSize' : scope.paginationConf.itemsPerPage,
            				'pageNo' : scope.paginationConf.currentPage
            			};
            			
            			params = $.extend({},params,scope.pageData.params);
            			
            			$http.get(scope.pageData.api,{params:params})
            		        .success(function(data,status,header,config){
            		              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
            						 $.toaster({priority : 'error', title : '提示', message :data.msg});
            		              } else if (data.code == '000000'){
            		            	    scope.pageData.selectIndex = null;
            		            	  	scope.pageData.list = data.data.list;
            		            	  	scope.paginationConf.totalItems = data.data.countAll;
            		            	  	scope.pageData.checkModel.selectAll = false;
            		            	  	scope.pageData.checkModel.datas = [];
            		            	  	$.each(data.data.list,function(i,n){
            		            	  		scope.pageData.checkModel.datas.push(false);
            		            	  	});
            		              }
            		    });
            	}
  	            
  	            $("#addResourceNewsWindow"+ scope.initViewConfig.winId).modal('show');
        	}
        	
        	//添加新闻资源
        	scope.addResourceNews = function(){
        		
        		if (scope.pageData.selectIndex == null){
        			$.toaster({priority : 'warning', title : '提示', message :'当前没有选择素材!'});
        			return;
        		}
        		
        		$http.get(app.api.host + app.api.base.wxResourceLoad, {params:{id:scope.pageData.list[scope.pageData.selectIndex].id, type:'news'}})
      	        .success(function(data,status,header,config){
      	              if(data.code != '000002' && data.code != '000003' && data.code != '000000'){
      					 $.toaster({priority : 'error', title : '提示', message :data.msg});
      	              } else if (data.code == '000000'){
      	            	  scope.resource.type = 'news';
      	            	  scope.resource.val = data.data.resource;
      	            	  $("#addResourceNewsWindow"+ scope.initViewConfig.winId).modal('hide');
      	              }
      	        });
        	}
        	
        }
    }
}])