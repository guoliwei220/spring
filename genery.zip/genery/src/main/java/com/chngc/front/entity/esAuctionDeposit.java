package com.chngc.front.entity;

import java.io.Serializable;
import java.util.Date;

public class esAuctionDeposit implements Serializable {
    private Long id;

    private Long memberId;

    private Long auctionId;

    private Byte isUnfrozen;

    private String unfrozenPerson;

    private Date reserveDate;

    private Date unfrozenDate;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMemberId() {
        return memberId;
    }

    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    public Long getAuctionId() {
        return auctionId;
    }

    public void setAuctionId(Long auctionId) {
        this.auctionId = auctionId;
    }

    public Byte getIsUnfrozen() {
        return isUnfrozen;
    }

    public void setIsUnfrozen(Byte isUnfrozen) {
        this.isUnfrozen = isUnfrozen;
    }

    public String getUnfrozenPerson() {
        return unfrozenPerson;
    }

    public void setUnfrozenPerson(String unfrozenPerson) {
        this.unfrozenPerson = unfrozenPerson == null ? null : unfrozenPerson.trim();
    }

    public Date getReserveDate() {
        return reserveDate;
    }

    public void setReserveDate(Date reserveDate) {
        this.reserveDate = reserveDate;
    }

    public Date getUnfrozenDate() {
        return unfrozenDate;
    }

    public void setUnfrozenDate(Date unfrozenDate) {
        this.unfrozenDate = unfrozenDate;
    }
}