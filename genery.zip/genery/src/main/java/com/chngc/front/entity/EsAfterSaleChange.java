package com.chngc.front.entity;

import java.io.Serializable;
import java.util.Date;

public class EsAfterSaleChange implements Serializable {
    private Integer id;

    private String servNum;

    private Integer orderId;

    private Integer memberId;

    private String memberAccount;

    private String servType;

    private String servReason;

    private String buyerDeliveryCompany;

    private String buyerDeliveryBillno;

    private String salerDeliveryCompany;

    private String salerDeliveryBillno;

    private String status;

    private String receiveName;

    private String receiveMobile;

    private String departmentId;

    private String receiveAddress;

    private String receiveEmail;

    private String isSendSms;

    private String createUser;

    private Date createTime;

    private String modifyUser;

    private Date modifyTime;

    private String createUserAccount;

    private String storehouseAdscription;

    private Integer materialNum;

    private String isHaveInvoice;

    private String isHaveShoppinginfo;

    private String isHaveCertificate;

    private String isHaveGuarantee;

    private String questionDesc;

    private String questionImg;

    private String materialInfo;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getServNum() {
        return servNum;
    }

    public void setServNum(String servNum) {
        this.servNum = servNum == null ? null : servNum.trim();
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getMemberId() {
        return memberId;
    }

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public String getMemberAccount() {
        return memberAccount;
    }

    public void setMemberAccount(String memberAccount) {
        this.memberAccount = memberAccount == null ? null : memberAccount.trim();
    }

    public String getServType() {
        return servType;
    }

    public void setServType(String servType) {
        this.servType = servType == null ? null : servType.trim();
    }

    public String getServReason() {
        return servReason;
    }

    public void setServReason(String servReason) {
        this.servReason = servReason == null ? null : servReason.trim();
    }

    public String getBuyerDeliveryCompany() {
        return buyerDeliveryCompany;
    }

    public void setBuyerDeliveryCompany(String buyerDeliveryCompany) {
        this.buyerDeliveryCompany = buyerDeliveryCompany == null ? null : buyerDeliveryCompany.trim();
    }

    public String getBuyerDeliveryBillno() {
        return buyerDeliveryBillno;
    }

    public void setBuyerDeliveryBillno(String buyerDeliveryBillno) {
        this.buyerDeliveryBillno = buyerDeliveryBillno == null ? null : buyerDeliveryBillno.trim();
    }

    public String getSalerDeliveryCompany() {
        return salerDeliveryCompany;
    }

    public void setSalerDeliveryCompany(String salerDeliveryCompany) {
        this.salerDeliveryCompany = salerDeliveryCompany == null ? null : salerDeliveryCompany.trim();
    }

    public String getSalerDeliveryBillno() {
        return salerDeliveryBillno;
    }

    public void setSalerDeliveryBillno(String salerDeliveryBillno) {
        this.salerDeliveryBillno = salerDeliveryBillno == null ? null : salerDeliveryBillno.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public String getReceiveName() {
        return receiveName;
    }

    public void setReceiveName(String receiveName) {
        this.receiveName = receiveName == null ? null : receiveName.trim();
    }

    public String getReceiveMobile() {
        return receiveMobile;
    }

    public void setReceiveMobile(String receiveMobile) {
        this.receiveMobile = receiveMobile == null ? null : receiveMobile.trim();
    }

    public String getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId == null ? null : departmentId.trim();
    }

    public String getReceiveAddress() {
        return receiveAddress;
    }

    public void setReceiveAddress(String receiveAddress) {
        this.receiveAddress = receiveAddress == null ? null : receiveAddress.trim();
    }

    public String getReceiveEmail() {
        return receiveEmail;
    }

    public void setReceiveEmail(String receiveEmail) {
        this.receiveEmail = receiveEmail == null ? null : receiveEmail.trim();
    }

    public String getIsSendSms() {
        return isSendSms;
    }

    public void setIsSendSms(String isSendSms) {
        this.isSendSms = isSendSms == null ? null : isSendSms.trim();
    }

    public String getCreateUser() {
        return createUser;
    }

    public void setCreateUser(String createUser) {
        this.createUser = createUser == null ? null : createUser.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getModifyUser() {
        return modifyUser;
    }

    public void setModifyUser(String modifyUser) {
        this.modifyUser = modifyUser == null ? null : modifyUser.trim();
    }

    public Date getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Date modifyTime) {
        this.modifyTime = modifyTime;
    }

    public String getCreateUserAccount() {
        return createUserAccount;
    }

    public void setCreateUserAccount(String createUserAccount) {
        this.createUserAccount = createUserAccount == null ? null : createUserAccount.trim();
    }

    public String getStorehouseAdscription() {
        return storehouseAdscription;
    }

    public void setStorehouseAdscription(String storehouseAdscription) {
        this.storehouseAdscription = storehouseAdscription == null ? null : storehouseAdscription.trim();
    }

    public Integer getMaterialNum() {
        return materialNum;
    }

    public void setMaterialNum(Integer materialNum) {
        this.materialNum = materialNum;
    }

    public String getIsHaveInvoice() {
        return isHaveInvoice;
    }

    public void setIsHaveInvoice(String isHaveInvoice) {
        this.isHaveInvoice = isHaveInvoice == null ? null : isHaveInvoice.trim();
    }

    public String getIsHaveShoppinginfo() {
        return isHaveShoppinginfo;
    }

    public void setIsHaveShoppinginfo(String isHaveShoppinginfo) {
        this.isHaveShoppinginfo = isHaveShoppinginfo == null ? null : isHaveShoppinginfo.trim();
    }

    public String getIsHaveCertificate() {
        return isHaveCertificate;
    }

    public void setIsHaveCertificate(String isHaveCertificate) {
        this.isHaveCertificate = isHaveCertificate == null ? null : isHaveCertificate.trim();
    }

    public String getIsHaveGuarantee() {
        return isHaveGuarantee;
    }

    public void setIsHaveGuarantee(String isHaveGuarantee) {
        this.isHaveGuarantee = isHaveGuarantee == null ? null : isHaveGuarantee.trim();
    }

    public String getQuestionDesc() {
        return questionDesc;
    }

    public void setQuestionDesc(String questionDesc) {
        this.questionDesc = questionDesc == null ? null : questionDesc.trim();
    }

    public String getQuestionImg() {
        return questionImg;
    }

    public void setQuestionImg(String questionImg) {
        this.questionImg = questionImg == null ? null : questionImg.trim();
    }

    public String getMaterialInfo() {
        return materialInfo;
    }

    public void setMaterialInfo(String materialInfo) {
        this.materialInfo = materialInfo == null ? null : materialInfo.trim();
    }
}