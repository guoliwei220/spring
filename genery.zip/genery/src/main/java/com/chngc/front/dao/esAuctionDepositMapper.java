package com.chngc.front.dao;

import com.chngc.front.entity.esAuctionDeposit;
import java.util.List;

public interface esAuctionDepositMapper {
    int deleteByPrimaryKey(Long id);

    int insert(esAuctionDeposit record);

    esAuctionDeposit selectByPrimaryKey(Long id);

    List<esAuctionDeposit> selectAll();

    int updateByPrimaryKey(esAuctionDeposit record);
}