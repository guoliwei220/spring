package com.chngc.front.dao;

import com.chngc.front.entity.EsAfterSaleChange;
import java.util.List;

public interface EsAfterSaleChangeMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(EsAfterSaleChange record);

    EsAfterSaleChange selectByPrimaryKey(Integer id);

    List<EsAfterSaleChange> selectAll();

    int updateByPrimaryKey(EsAfterSaleChange record);
}