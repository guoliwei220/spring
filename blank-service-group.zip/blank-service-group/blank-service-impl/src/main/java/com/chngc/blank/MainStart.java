package com.chngc.blank;

import org.apache.log4j.xml.DOMConfigurator;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;

public class MainStart {

    public static void main(String[] args) {
        DOMConfigurator.configure(MainStart.class.getResource("/").getPath().substring(1) + "conf/log4j.xml");//加载.xml文件
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {
                "blank-service-config.xml",
                "conf/datasources.xml",
                "conf/service-deploy.xml"
        });
        context.start();

        System.out.println("dubbo-server服务正在监听，按任意键退出");

        try {
            System.in.read();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
