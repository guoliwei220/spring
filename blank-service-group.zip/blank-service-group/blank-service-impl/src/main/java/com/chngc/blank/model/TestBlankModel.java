package com.chngc.blank.model;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @FileName: TestBlankModel
 * @Version: 1.0
 * @Author: yanpeng
 * @Date: 2016/6/24 9:16
 */
@Component
public class TestBlankModel {

    public List<String> getTestData(String arg) {

        // do something
        List rlt = new ArrayList<String>();

        rlt.add("Hi, this is first dubbo project, It works!");
        rlt.add("Input :" + arg);

        return rlt;
    }
}
