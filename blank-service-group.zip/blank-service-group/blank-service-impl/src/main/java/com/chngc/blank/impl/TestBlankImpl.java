package com.chngc.blank.impl;

import com.chngc.blank.model.TestBlankModel;
import com.chngc.blank.service.ITestBlankService;
import com.chngc.core.common.ServiceResult;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @FileName: TestBlankImpl
 * @Version: 1.0
 * @Author: yanpeng
 * @Date: 2016/6/24 9:15
 */
public class TestBlankImpl implements ITestBlankService {

    @Autowired
    private TestBlankModel testBlankModel;

    public ServiceResult<List<String>> getTestData(String arg) {

        ServiceResult<List<String>> result = new ServiceResult<List<String>>();

        List<String> rlt = null;
        try {
            rlt = testBlankModel.getTestData(arg);
            result.setResult(rlt);
            result.setSuccess(true);
        } catch (Exception e) {
            // do something
            result.setSuccess(false);
        }
        return result;
    }

}
