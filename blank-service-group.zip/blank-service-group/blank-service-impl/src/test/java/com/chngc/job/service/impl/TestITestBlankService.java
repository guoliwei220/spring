package com.chngc.job.service.impl;

import com.chngc.blank.service.ITestBlankService;
import com.chngc.core.common.ServiceResult;
import com.chngc.job.test.TestBase;
import junit.framework.Assert;

import java.util.List;


public class TestITestBlankService extends TestBase {

    ITestBlankService testBlankService;

    @Override
    protected void init() {
        testBlankService = context.getBean(ITestBlankService.class);
        Assert.assertNotNull(testBlankService);
    }

    public void testGetTestData () {

        String arg = "Hello, world";
        ServiceResult<List<String>> result = testBlankService.getTestData(arg);
        print(result);
    }

    public void testGetTestData1 () {

        String arg = "Hello, world";
        ServiceResult<List<String>> result = testBlankService.getTestData(arg);
        print(result);
    }
}
