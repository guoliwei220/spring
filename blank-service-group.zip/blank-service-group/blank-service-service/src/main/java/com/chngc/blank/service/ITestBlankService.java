package com.chngc.blank.service;

import com.chngc.core.common.ServiceResult;

import java.util.List;

/**
 * @FileName: ITestBlankService
 * @Version: 1.0
 * @Author: yanpeng
 * @Date: 2016/6/24 9:13
 */
public interface ITestBlankService {

    ServiceResult<List<String>> getTestData(String arg);

}
